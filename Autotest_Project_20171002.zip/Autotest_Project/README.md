# Autotest_Project
一、WEB自动化框架
基于python2.7,通过selenium+unittest  实现的WEB自动化测试框架

1、线性框架
2、模块化框架
3、数据驱动框架
4、关键字驱动框架
5、page object 框架

我们采用：
1、模块化框架
2、数据驱动框架
3、page object 框架


二、Interface 接口自动化测试框架
python2.7
requests
py.test
数据驱动

