# -*- coding: utf-8 -*-

# from suds.client import Client

# c = Client('http://ws.webxml.com.cn/WebServices/MobileCodeWS.asmx?WSDL')
#
#
# print c
# print c.service.getMobileCodeInfo('1560205', '')

# BLOG = ['https://huilansame.github.io/huilansame.github.io/archivers/file-upload-all-ways',
#         'https://huilansame.github.io/huilansame.github.io/archivers/exceptions-StaleElementReferenceException',
#         'https://huilansame.github.io/huilansame.github.io/archivers/input-textarea-editor',
#         'https://huilansame.github.io/huilansame.github.io/archivers/time-date-widget',
#         'https://huilansame.github.io/huilansame.github.io/archivers/mouse-and-keyboard-actionchains',
#         'https://huilansame.github.io/huilansame.github.io/archivers/switch-to-alert-window-div',
#         'https://huilansame.github.io/huilansame.github.io/archivers/drop-down-select',
#         'https://huilansame.github.io/huilansame.github.io/archivers/switch-to-frame',
#         'https://huilansame.github.io/huilansame.github.io/archivers/radio-button-checkbox',
#         'https://huilansame.github.io/huilansame.github.io/archivers/browser-scroll-bar',
#         'https://huilansame.github.io/huilansame.github.io/archivers/forward-back-refresh',
#         'https://huilansame.github.io/huilansame.github.io/archivers/switch-to-active-element',
#         'https://huilansame.github.io/huilansame.github.io/archivers/close-and-quit',
#         'https://huilansame.github.io/huilansame.github.io/archivers/useful-keys',
#         'https://huilansame.github.io/huilansame.github.io/archivers/cmd-params-to-autoit-exe',
#         'https://huilansame.github.io/huilansame.github.io/archivers/chromedriver-to-chrome-version',
#         'https://huilansame.github.io/huilansame.github.io/archivers/light-auto-test-framework-directory',
#         'https://huilansame.github.io/', 'https://huilansame.github.io/huilansame.github.io/',
#         'https://huilansame.github.io/huilansame.github.io/about/',
#         'https://huilansame.github.io/huilansame.github.io/category/']
import requests
import random
import time

# for i in range(500):
#
#     res = requests.get(random.choice(BLOG2))
#
#     print res.status_code
#
#     time.sleep(random.randint(1, 5))
