#!/usr/bin/env python
#coding:utf-8

#Created on 2017年5月31日
__author__ = 'Jason'


from unittest.util import safe_repr

def assertDictContainsSubset(expected, actual, msg=None):
    """Checks whether actual is a superset of expected."""
    missing = []
    mismatched = []
    for key, value in expected.iteritems():
        if key not in actual:
            missing.append(key)
        elif value != actual[key]:
            mismatched.append('%s, expected: %s,type_expected: %s, But actual: %s,type_actual:%s' % (key, value,type(value),actual[key],type(actual[key])))

    if not (missing or mismatched):
        return

    standardMsg = ''
    if missing:
        standardMsg = 'Missing: %s' % ','.join(m for m in missing)
    if mismatched:
        if standardMsg:
            standardMsg += '; '
        standardMsg += 'Mismatched values: %s' % ','.join(mismatched)

    if msg is None:
        raise Exception(standardMsg)
    else:
        try:
        # don't switch to '{}' formatting in Python 2.X
        # it changes the way unicode input is handled
            raise Exception('%s : %s' % (msg, standardMsg))
        except UnicodeDecodeError:
            raise  Exception('%s : %s' % (safe_repr(msg), safe_repr(standardMsg)))

def assertEqual(expected, actual, msg=None):
    """Checks whether actual is equal  expected. ignore type """
    if isinstance(expected, unicode):
        expected = expected.encode("utf-8")   #unicode to string
    if isinstance(actual, unicode):
        actual = actual.encode("utf-8")

    assert expected == actual , ('' if msg is None else str(msg)) + "\nExpect:\t%s\nActual:\t%s" % (expected, actual)

    # mismatched = []
    # if expected != actual:
    #     mismatched.append("\nExpect:\t%s\nActual:\t%s" % (expected, actual))
    #
    # if not mismatched:
    #     return
    #
    # standardMsg = ''
    # if mismatched:
    #     if standardMsg:
    #         standardMsg += '; '
    #     standardMsg += 'Mismatched values: %s' % ','.join(mismatched)
    #
    # if msg is None:
    #     raise Exception(standardMsg)
    # else:
    #     try:
    #     # don't switch to '{}' formatting in Python 2.X
    #     # it changes the way unicode input is handled
    #         raise Exception('%s : %s' % (msg, standardMsg))
    #     except UnicodeDecodeError:
    #         raise  Exception('%s : %s' % (safe_repr(msg), safe_repr(standardMsg)))



def assertContain(expected, actual, msg=None):
    """Checks whether actual is contain the expected. ignore type """
    if isinstance(expected, unicode):
        expected = expected.encode("utf-8")
    if isinstance(actual, unicode):
        actual = actual.encode("utf-8")

    assert expected in actual , ('' if msg is None else str(msg)) + "\nExpect:\t%s\nActual:\t%s" % (expected, actual)

