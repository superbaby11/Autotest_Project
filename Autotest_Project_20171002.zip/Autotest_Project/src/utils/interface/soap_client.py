# -*- coding: utf-8 -*-

from suds.client import Client

c = Client('http://ws.webxml.com.cn/WebServices/MobileCodeWS.asmx?WSDL')


print c
print c.service.getMobileCodeInfo('1560205', '')
