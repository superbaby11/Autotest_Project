#!/usr/bin/env python
# -*- coding:utf-8 -*-

__author__ = 'Jason'

import sys

import json
import configparser
import pymysql
import pymssql
import ast
import decimal
import datetime
import simplejson

from config import Config_Project,DefaultConfig

class GetDB(object):
    '''配置数据库IP，端口等信息，获取数据库连接'''
    def __init__(self, config_file, db):
        config = configparser.ConfigParser()

        # 从配置文件中读取数据库服务器IP、域名，端口
        config.read(config_file)
        self.driver = config[db]['driver']
        self.host = config[db]['host']
        self.port = config[db]['port']
        self.user = config[db]['user']
        self.passwd = config[db]['passwd']
        self.db = config[db]['db_name']
        self.charset = config[db]['charset']

    def get_conn(self):
        if self.driver == 'mysql':
            try:
#                 conn = pymysql.connect(host='10.10.15.135', port=3306, user='interface_test', password='interface_test', database='interface', charset='utf8', cursorclass=pymysql.cursors.DictCursor)
                conn = pymysql.connect(host=self.host, port=int(self.port), user=self.user, password=self.passwd, database=self.db, charset=self.charset)
                return conn
            except Exception as e:
                print('%s', e)
                sys.exit()
        elif self.driver == 'sqlserver':
            try:
#                 conn = pymssql.connect(server='119.9.124.151', port=3344, user='Lottery01', password='adjIUEd8&D817dpA', database='CAT01', charset='utf8', as_dict=True)
                conn = pymssql.connect(server=self.host, port=self.port, user=self.user, password=self.passwd, database=self.db, charset= self.charset)
                return conn
            except Exception as e:
                print('%s', e)
                sys.exit()


# 返回测试数据库连接
def db_mysql_connect(config_file=None, db='db'):
    if config_file == None:
        config_file = DefaultConfig().path
    return GetDB(config_file, db).get_conn()

# 返回应用数据库连接
def db_sqlserver_connect(config_file=None, db='db'):
    if config_file == None:
        config_file = Config_Project().path    
    return GetDB(config_file, db).get_conn()

def json_encode_decimal(obj):
    if isinstance(obj, decimal.Decimal):
        return str(obj)
    if isinstance(obj, datetime.datetime):
        return str(obj).split('.')[0]    #转化为时间字符串    '2016-12-02 15:33:41'
    raise TypeError(repr(obj) + " is not JSON serializable")


# sql 查询 ；
def sql_query(conn, sql):
	cursor = conn.cursor()
	cursor.execute(sql.decode('utf8'))
	sql_result = cursor.fetchall()
	cursor.close()
	return sql_result

def sql_query_dict(conn,sql):
    cursor = conn.cursor()
    cursor.execute(sql.decode('utf8'))      #支持where 条件下有中文
    columns = [column[0] for column in cursor.description]
    sql_result = []
    for row in cursor.fetchall():
        sql_result.append(dict(zip(columns, row)))
    aaaa = simplejson.dumps(sql_result, default=json_encode_decimal)     #支持decimal 转化为数字       转化为字符串
    bbbb = json.loads(aaaa)        #转化为json
    cursor.close()
    return bbbb


# 查询sql 是列表形式
def sql_query_list(conn,sql_list):
    '''
    sql_old=[[],[],[]]
    sql_old=[[insert],[delete],[update]]    #增加、删除、修改  如果有多条sql 就用逗号隔开；  操作前要查询的结果
    sql_new=[[insert],[delete],[update]]    #增加、删除、修改  如果有多条sql 就用逗号隔开；  操作后要查询的结果

    原始语句：
    select iUserKey,fBalance from tuser where sUserid='jtest';
    select fBalance from tuser where sUserid='jtest';
    select count(*) from tbet a  , tuser b where  a.iGameId=18 and a.iUserKey= b.iUserKey and b.sUserid='jtest' and a.fAmount=41 ;

    转化后的语句：
    "select iUserKey,fBalance from tuser where sUserid='"+str(GUserNameA)+"';"
    "select count(*) from tbet a  , tuser b where  a.iGameId="+ str(game_id)+" and a.iUserKey= b.iUserKey and b.sUserid='jtest' and a.fAmount="+str(each_money)+" ;"

    '''
    cursor = conn.cursor()
    #sql_list=["select * from trebateset ;","select * from tbank ;"]
    sql_result=[[] for i in range(len(sql_list))]
    for j in range(len(sql_list)):
        sql=sql_list[j]
        cursor.execute(sql.decode('utf8'))
        sql_result[j] = cursor.fetchall()
    cursor.close()
    return sql_result


def sql_query_dict_list(conn,sql_list):
    #sql_list=["select * from trebateset ;","select * from tbank ;"]
    cursor = conn.cursor()
    sql_result=[[] for i in range(len(sql_list))]

    for j in range(len(sql_list)):
        sql=sql_list[j]
        cursor.execute(sql.decode('utf8'))      #支持where 条件下有中文
        columns = [column[0] for column in cursor.description]
        for row in cursor.fetchall():
            sql_result[j].append(dict(zip(columns, row)))
    aaaa = simplejson.dumps(sql_result, default=json_encode_decimal)     #支持decimal 转化为数字       转化为字符串
    bbbb = json.loads(aaaa)        #转化为json
    cursor.close()
    return bbbb

# update delete 操作
def sql_update(conn,sql):
    """
    执行单条语句的UPDATE或者DELETE操作。
    :param conn: 已有的数据库连接。
    :param sql_one: 字符串类型的sql语句。
    :return: 无返回值
    """
    cursor = conn.cursor()
    cursor.execute(sql.decode('utf8'))
    cursor.execute('commit')
    cursor.close()
    conn.close()


def unicode_dict(data):
    return ast.literal_eval(data)   #unicode dict to dict

def clear(db_conn):
    # 关闭数据库连接
    db_conn.close()



if __name__ == '__main__':
    # db1 = db_mysql_connect()
    # sql1 = "select * from interface_case  where caseID='User_CanLogin_1';"
    # cc = sql_query(db1,sql1)
    # print cc
    db2_conn = db_sqlserver_connect()
    sql2 = "select iUserKey,fBalance from tuser where iUserKey='52235';"
    dd = sql_query_dict(db2_conn, sql2)
    print 'ddd--->>>>>',dd
