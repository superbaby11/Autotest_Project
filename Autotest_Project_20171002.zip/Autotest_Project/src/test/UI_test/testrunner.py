#!/usr/bin/env python
#coding:utf-8

#Created on 2017年4月24日
import os

__author__ = 'Jason'


import time
import pytest
from src.utils.config import DefaultConfig
from src.utils.mail import Email


if __name__ == '__main__':
    now_time = time.strftime("%Y%m%d", time.localtime(time.time()))
    file_name = DefaultConfig().report_path + "web_autotest_report_%s.html" % now_time
    test_dir = DefaultConfig().web_test_dir
    AHKS = os.path.join(test_dir, 'AHKS/')
    CQSSC = os.path.join(test_dir, 'CQSSC/')
    GLHT = os.path.join(test_dir, 'GLHT/')
    Manage = os.path.join(test_dir, 'Manage/')
    PK10 = os.path.join(test_dir, 'PK10/')
    PLS = os.path.join(test_dir, 'PLS/')
    XYNC = os.path.join(test_dir, 'XYNC/')
    GcdtPageLogin = os.path.join(test_dir, 'test_gcdtpage_login.py')
    HomePageLogin = os.path.join(test_dir, 'test_homepage_login.py')
    LoginPageLogin = os.path.join(test_dir, 'test_loginpage_login.py')
    RegistPageRegist = os.path.join(test_dir, 'test_registpage_regist.py')
    args = [
        '--html=%s' % file_name,
        '--force-flaky',
        '--max-runs=2',
        '--min-passes=1',
        '-sq',
        '--alluredir=%s' % DefaultConfig().report_path,
        GcdtPageLogin,
        HomePageLogin,
        LoginPageLogin,
        RegistPageRegist,
        Manage,
        GLHT,
        PLS,
        AHKS,
        PK10,
        CQSSC
    ]
    pytest.main(args)
    print("\nTest Path: %s" % test_dir)
    print("\nTest Report: %s" % file_name)
    print("\nTest Args: %s" % str(args))
    Email(title=u"WEB自动化测试报告_%s" % file_name.split(".html")[0].split("web_autotest_report_")[1], path=file_name).send()