#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/6/24 10:41
# @Author  : Terry
import pytest

from src.test.UI_test.case.TestBase import TestBase
from src.test.UI_test.page.HomePage import HomePage
from src.utils.config import DefaultConfig_Project
from src.utils.getdb import sql_query, db_mysql_connect


class Test_PLS_SX_ZXFS_Page(TestBase):
    # @classmethod
    # def setup_class(cls):
    #     cls.page_home = HomePage()
    #     cls.page_gcdt = cls.page_home.gotoGcdtPage()
    #     # 用户登录
    #     str_username = DefaultConfig_Project().user_name
    #     str_password = DefaultConfig_Project().pass_word
    #     str_authnum = DefaultConfig_Project().auth_num
    #     cls.page_gcdt.loginNormal(str_username, str_password, str_authnum)
    #
    # @classmethod
    # def teardown_class(cls):
    #     cls.page_gcdt.quit()
    def setup_method(self):
        self.page_home = HomePage()
        self.page_gcdt = self.page_home.gotoGcdtPage()
        # 用户登录
        str_username = DefaultConfig_Project().user_name
        str_password = DefaultConfig_Project().pass_word
        str_authnum = DefaultConfig_Project().auth_num
        self.page_gcdt.loginNormal(str_username, str_password, str_authnum)

    def teardown_method(self):
        self.page_gcdt.quit()

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_PLS_SX_ZXFS_%' and normal = 'Y' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_pls_sx_zxfs_normal(self, model, model1, model2, caseID, caseData):
        """
        测试正常投注流程。
        :return: 
        """
        self.normal(model, model1, model2, caseID, caseData)

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_PLS_SX_ZXFS_9' and normal = 'N' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_pls_sx_zxfs_insufficient(self, model, model1, model2, caseID, caseData):
        """
        测试场景：用户投注时余额不足。
        :return: 
        """
        self.insufficient(model, model1, model2, caseID, caseData)

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_PLS_SX_ZXFS_10' and normal = 'N' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_pls_sx_zxfs_clean_all(self, model, model1, model2, caseID, caseData):
        """
        测试场景：添加注单后，删除全部注单。
        :return: 
        """
        self.clean_all(model, model1, model2, caseID, caseData)

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_PLS_SX_ZXFS_11' and normal = 'N' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_pls_sx_zxfs_change_normal_to_random(self, model, model1, model2, caseID, caseData):
        """
        测试场景：选择投注号码后，不点击‘添加注单’，点击随机一注。
        :return: 
        """
        self.change_normal_to_random(model, model1, model2, caseID, caseData)

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_PLS_SX_ZXFS_12' and normal = 'N' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_pls_sx_zxfs_wrong_codes(self, model, model1, model2, caseID, caseData):
        """
        测试场景：投注号码不完整。
        :return: 
        """
        self.wrong_codes(model, model1, model2, caseID, caseData)

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_PLS_SX_ZXFS_13' and normal = 'N' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_pls_sx_zxfs_add_empty(self, model, model1, model2, caseID, caseData):
        """
        测试场景：没有选择投注号码，点击‘添加注单’。
        :return: 
        """
        self.add_empty(model, model1, model2, caseID, caseData)

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_PLS_SX_ZXFS_14' and normal = 'N' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_pls_sx_zxfs_buy_empty(self, model, model1, model2, caseID, caseData):
        """
        测试场景：没有选择投注号码，点击‘确认投注’。
        :return: 
        """
        self.buy_empty(model, model1, model2, caseID, caseData)

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_PLS_SX_ZXFS_15' and normal = 'N' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_pls_sx_zxfs_wrong_money(self, model, model1, model2, caseID, caseData):
        """
        测试场景：投注时，输入错误的金额，例如0元。
        :return: 
        """
        self.wrong_money(model, model1, model2, caseID, caseData)

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_PLS_SX_ZXFS_18' and normal = 'N' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_pls_sx_zxfs_wrong_term(self, model, model1, model2, caseID, caseData):
        """
        测试场景：追号时，输入超大的追号期数，例如81。
        :return: 
        """
        self.wrong_term(model, model1, model2, caseID, caseData)


if __name__ == '__main__':
    # args = ['test_pls_sx_zxfs_page.py::Test_PLS_SX_ZXFS_Page::test_pls_sx_zxfs_normal']
    # args = ['test_pls_sx_zxfs_page.py::Test_PLS_SX_ZXFS_Page::test_pls_sx_zxfs_insufficient']
    # args = ['test_pls_sx_zxfs_page.py::Test_PLS_SX_ZXFS_Page::test_pls_sx_zxfs_clean_all']
    # args = ['test_pls_sx_zxfs_page.py::Test_PLS_SX_ZXFS_Page::test_pls_sx_zxfs_change_normal_to_random']
    # args = ['test_pls_sx_zxfs_page.py::Test_PLS_SX_ZXFS_Page::test_pls_sx_zxfs_wrong_codes']
    # args = ['test_pls_sx_zxfs_page.py::Test_PLS_SX_ZXFS_Page::test_pls_sx_zxfs_add_empty']
    # args = ['test_pls_sx_zxfs_page.py::Test_PLS_SX_ZXFS_Page::test_pls_sx_zxfs_buy_empty']
    # args = ['test_pls_sx_zxfs_page.py::Test_PLS_SX_ZXFS_Page::test_pls_sx_zxfs_wrong_money']
    # args = ['test_pls_sx_zxfs_page.py::Test_PLS_SX_ZXFS_Page::test_pls_sx_zxfs_wrong_term']
    args = ['test_pls_sx_zxfs_page.py::Test_PLS_SX_ZXFS_Page']
    pytest.main(args)
