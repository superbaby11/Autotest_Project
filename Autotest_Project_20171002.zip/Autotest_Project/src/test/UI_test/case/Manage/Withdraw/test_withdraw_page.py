#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/7/13 13:39
# @Author  : Terry
import pytest

from src.test.UI_test.common.common import TestData, DataBase
from src.test.UI_test.page.GLHT.GlhtLoginPage import GlhtLoginPage
from src.test.UI_test.page.HomePage import HomePage
from src.utils.assert_extra import assertEqual
from src.utils.config import DefaultConfig_Project
from src.utils.getdb import sql_query, db_mysql_connect


class Test_Withdraw_Page(object):
    page_home = None

    def setup_method(self):
        # 前台账户
        self.str_username = DefaultConfig_Project().user_name
        self.str_password = DefaultConfig_Project().pass_word
        self.str_authnum = DefaultConfig_Project().auth_num
        self.str_password_withdraw = DefaultConfig_Project().get("users", "pass_word_withdraw")
        # 后台账户
        self.url_back = DefaultConfig_Project().get("url", "back_url")
        self.str_username_back = DefaultConfig_Project().get("users", "username_back")
        self.str_password_back = DefaultConfig_Project().get("users", "password_back")

        # 前台账户的出款的所需投注量清零
        DataBase().zero_bet_need(self.str_username)

        # 登录前台
        self.page_home = HomePage()
        self.page_home.open()
        self.page_home.loginNormal(self.str_username, self.str_password, auth_num=self.str_authnum)
        self.page_withdraw = self.page_home.gotoWithdrawPage()

    def teardown_method(self):
        try:
            self.page_glht_home.glhtLogout()
        except:
            pass
        self.page_home.quit()

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_WITHDRAW_1' and normal = 'Y' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_withdraw_no_lock(self, model, model1, model2, caseID, caseData):
        """
        测试场景：正常的出款流程,未在管理后台对出款进行确认。
        """
        dic_original_data = {
            "model": model,
            "model1": model1,
            "model2": model2,
            "caseID": caseID,
            "caseData": caseData
        }
        testdata = TestData(dic_original_data)
        testdata.password_withdraw = self.str_password_withdraw

        # 申请出款
        result = self.page_withdraw.withdraw(testdata)
        assertEqual(testdata.popupwindow1, result.message_withdraw_commit)
        self.page_withdraw.close_current_window()
        self.page_home.switch_to_window(0)

        #  出款记录
        self.page_deal_record = self.page_home.gotoDealRecordPage()
        self.page_withdraw_record = self.page_deal_record.gotoWithdraw()
        result = self.page_withdraw_record.search()
        assertEqual(float(testdata.wmoney), float(result.deal_money))
        assertEqual(testdata.withdraw_status, result.withdraw_status)

        # 交易明细
        self.page_deal_detail = self.page_deal_record.gotoDealDetail()
        result = self.page_deal_detail.search()
        assertEqual(float(testdata.wmoney), float(result.deal_money))
        assertEqual(testdata.income_and_expenses, result.income_and_expense)
        assertEqual(testdata.deal_type, result.deal_type)

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_WITHDRAW_2' and normal = 'Y' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_withdraw_cancel(self, model, model1, model2, caseID, caseData):
        """
        测试场景：申请出款，管理后台点击取消。
        """
        dic_original_data = {
            "model": model,
            "model1": model1,
            "model2": model2,
            "caseID": caseID,
            "caseData": caseData
        }
        testdata = TestData(dic_original_data)
        testdata.password_withdraw = self.str_password_withdraw
        testdata.username = self.str_username

        # 申请出款
        result = self.page_withdraw.withdraw(testdata)
        assertEqual(testdata.popupwindow1, result.message_withdraw_commit)
        self.page_withdraw.close_current_window()
        self.page_home.switch_to_window(0)
        self.page_home.logout()

        # 管理后台-->出款管理
        self.page_home.open(self.url_back)
        self.page_glht_login = GlhtLoginPage(self.page_home.getDriver())
        self.page_glht_home = self.page_glht_login.loginNormal(self.str_username_back, self.str_password_back)
        self.page_glht_withdraw = self.page_glht_home.gotoWithdrawPage()
        self.page_glht_withdraw.cancel_withdraw(testdata)
        self.page_glht_withdraw.glhtLogout()

        #  出款记录
        self.page_home.open()
        self.page_home.loginNormal(self.str_username, self.str_password, auth_num=self.str_authnum)
        self.page_deal_record = self.page_home.gotoDealRecordPage()
        self.page_withdraw_record = self.page_deal_record.gotoWithdraw()
        result = self.page_withdraw_record.search()
        assertEqual(float(testdata.wmoney), float(result.deal_money))
        assertEqual(testdata.withdraw_status, result.withdraw_status)

        # 交易明细
        self.page_deal_detail = self.page_deal_record.gotoDealDetail()
        result = self.page_deal_detail.search()
        assertEqual(float(testdata.wmoney), float(result.deal_money))
        assertEqual(testdata.income_and_expenses, result.income_and_expense)
        assertEqual(testdata.deal_type, result.deal_type)

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_WITHDRAW_3' and normal = 'Y' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_withdraw_confirm(self, model, model1, model2, caseID, caseData):
        """
        测试场景：申请出款，管理后台确认通过。
        """
        dic_original_data = {
            "model": model,
            "model1": model1,
            "model2": model2,
            "caseID": caseID,
            "caseData": caseData
        }
        testdata = TestData(dic_original_data)
        testdata.password_withdraw = self.str_password_withdraw
        testdata.username = self.str_username

        # 申请出款
        result = self.page_withdraw.withdraw(testdata)
        assertEqual(testdata.popupwindow1, result.message_withdraw_commit)
        self.page_withdraw.close_current_window()
        self.page_home.switch_to_window(0)
        self.page_home.logout()

        # 管理后台-->出款管理
        self.page_home.open(self.url_back)
        self.page_glht_login = GlhtLoginPage(self.page_home.getDriver())
        self.page_glht_home = self.page_glht_login.loginNormal(self.str_username_back, self.str_password_back)
        self.page_glht_withdraw = self.page_glht_home.gotoWithdrawPage()
        self.page_glht_withdraw.confirm_withdraw(testdata)
        self.page_glht_withdraw.glhtLogout()

        #  出款记录
        self.page_home.open()
        self.page_home.loginNormal(self.str_username, self.str_password, auth_num=self.str_authnum)
        self.page_deal_record = self.page_home.gotoDealRecordPage()
        self.page_withdraw_record = self.page_deal_record.gotoWithdraw()
        result = self.page_withdraw_record.search()
        assertEqual(float(testdata.wmoney), float(result.deal_money))
        assertEqual(testdata.withdraw_status, result.withdraw_status)

        # 交易明细
        self.page_deal_detail = self.page_deal_record.gotoDealDetail()
        result = self.page_deal_detail.search()
        assertEqual(float(testdata.wmoney), float(result.deal_money))
        assertEqual(testdata.income_and_expenses, result.income_and_expense)
        assertEqual(testdata.deal_type, result.deal_type)

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_WITHDRAW_%' and normal = 'wrong_money' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_withdraw_wrong_money(self, model, model1, model2, caseID, caseData):
        """
        测试场景：提现金额错误。
        """
        dic_original_data = {
            "model": model,
            "model1": model1,
            "model2": model2,
            "caseID": caseID,
            "caseData": caseData
        }
        testdata = TestData(dic_original_data)
        testdata.password_withdraw = self.str_password_withdraw

        # 申请出款
        result = self.page_withdraw.withdraw(testdata)
        assertEqual(testdata.popupwindow1, result.message_withdraw_commit)
        self.page_withdraw.close_current_window()
        self.page_home.switch_to_window(0)

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_WITHDRAW_%' and normal = 'wrong_password' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_withdraw_wrong_password(self, model, model1, model2, caseID, caseData):
        """
        测试场景：提现金额错误。
        """
        dic_original_data = {
            "model": model,
            "model1": model1,
            "model2": model2,
            "caseID": caseID,
            "caseData": caseData
        }
        testdata = TestData(dic_original_data)

        # 申请出款
        result = self.page_withdraw.withdraw(testdata)
        assertEqual(testdata.popupwindow1, result.message_withdraw_commit)
        self.page_withdraw.close_current_window()
        self.page_home.switch_to_window(0)


if __name__ == '__main__':
    # args = ["test_withdraw_page.py::Test_Withdraw_Page::test_withdraw_no_lock"]
    # args = ["test_withdraw_page.py::Test_Withdraw_Page::test_withdraw_cancel"]
    # args = ["test_withdraw_page.py::Test_Withdraw_Page::test_withdraw_confirm"]
    # args = ["test_withdraw_page.py::Test_Withdraw_Page::test_withdraw_wrong_money"]
    # args = ["test_withdraw_page.py::Test_Withdraw_Page::test_withdraw_wrong_password"]
    args = ["test_withdraw_page.py::Test_Withdraw_Page"]
    pytest.main(args)
