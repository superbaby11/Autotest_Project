#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/7/18 9:19
# @Author  : Terry
from src.test.UI_test.page.HomePage import HomePage


class Deposit_Base(object):
    def setup_class(cls):
        """
        在运行充值的测试脚本前，首先在管理后台设定充值优惠金额及优惠标准。
        :return: 
        """
        page_home = HomePage()
        page_home.open()
        page_glht = page_home.gotoGlhtPage()
        page_glht_home = page_glht.loginNormal()
        page_every = page_glht_home.gotoFundsSettingPage()
        page_every.type(page_every.tup_min_reload2, '1010')
        page_every.type(page_every.tup_bonus_pct2, '50')
        page_every.type(page_every.tup_bonus_max2, '150')
        page_every.click(page_every.tup_commit_btn)
        if page_every.getDisplay(page_every.tup_close_btn):
            page_every.click(page_every.tup_close_btn)
        page_every.glhtLogout()
        page_every.quit()
