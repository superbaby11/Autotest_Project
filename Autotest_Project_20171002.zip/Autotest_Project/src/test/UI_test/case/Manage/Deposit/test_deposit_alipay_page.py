#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/7/7 10:41
# @Author  : Terry
import pytest

from src.test.UI_test.case.Manage.Deposit.deposit_base import Deposit_Base
from src.test.UI_test.common.common import TestData
from src.test.UI_test.page.HomePage import HomePage
from src.utils.assert_extra import assertEqual
from src.utils.config import DefaultConfig_Project
from src.utils.getdb import sql_query, db_mysql_connect


class Test_Deposit_Alipay_Page(Deposit_Base):
    page_home = None
    page_deposit = None

    def setup_method(self):
        self.page_home = HomePage()
        self.page_home.open()
        self.str_username = DefaultConfig_Project().user_name
        self.str_password = DefaultConfig_Project().pass_word
        self.str_authnum = DefaultConfig_Project().auth_num
        self.page_home.loginNormal(self.str_username, self.str_password, auth_num=self.str_authnum)
        self.page_deposit = self.page_home.gotoDepositPage().alipay()

    def teardown_method(self):
        try:
            self.page_glht_home.glhtLogout()
        except:
            pass
        self.page_home.quit()

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_DEPOSIT_ALIPAY_%' and normal = 'add_friend' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_deposit_alipay_add_friend(self, model, model1, model2, caseID, caseData):
        """
        测试场景：支付宝入款，需要加好友。
        :return: 
        """
        dic_original_data = {
            "model": model,
            "model1": model1,
            "model2": model2,
            "caseID": caseID,
            "caseData": caseData
        }
        testdata = TestData(dic_original_data)
        result = self.page_deposit.deposit(testdata)
        self.page_deposit.close_current_window()
        self.page_deposit.switch_to_window(0)
        self.page_home.logout()
        assertEqual(testdata.message1, result.message_deposit_info)

        # 管理后台页面，确认充值
        self.page_glht = self.page_home.gotoGlhtPage()
        self.page_glht_home = self.page_glht.loginNormal()
        self.page_glht_deposit = self.page_glht_home.gotoDepositPage().alipay()
        result = self.page_glht_deposit.search(self.str_username)
        self.page_glht_deposit.glhtLogout()
        self.page_glht_deposit.close_current_window()
        self.page_home.switch_to_window(0)
        str_order_number = result.order_number
        str_deal_time = result.deal_time
        assertEqual(testdata.dmoney, result.dmoney)
        if testdata.has_reward:
            assertEqual(testdata.reward, result.reward)
        assertEqual(testdata.popupwindow1, result.message_deposit_lock)
        assertEqual(testdata.popupwindow2, result.message_deposit_confirm)

        # 前台充值记录页面，验证充值信息
        self.page_home.open()
        self.page_home.loginNormal(self.str_username, self.str_password, auth_num=self.str_authnum)
        self.page_deal_record = self.page_home.gotoDealRecordPage()
        self.page_deposit_record = self.page_deal_record.gotoRepositRecord()
        result = self.page_deposit_record.search(str_order_number)
        assertEqual(testdata.deal_type, result.deal_type)
        assertEqual(float(testdata.deal_money), float(result.deal_money))
        assertEqual(testdata.deposit_status, result.deposit_status)

        # 前台交易记录页面
        self.page_deal_detail = self.page_deal_record.gotoDealDetail()
        result = self.page_deal_detail.search(str_deal_time)
        assertEqual(float(testdata.deal_money), float(result.deal_money))
        assertEqual(testdata.deal_type, result.deal_type)
        if testdata.has_reward and int(testdata.reward) > 0:  # 验证优惠信息
            assertEqual(float(testdata.reward), float(result.reward))

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_DEPOSIT_ALIPAY_2' and normal = 'scan_code' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_deposit_alipay_scan_code(self, model, model1, model2, caseID, caseData):
        """
        测试场景：支付宝入款，需要扫码。
        :return: 
        """
        dic_original_data = {
            "model": model,
            "model1": model1,
            "model2": model2,
            "caseID": caseID,
            "caseData": caseData
        }
        testdata = TestData(dic_original_data)
        result = self.page_deposit.deposit(testdata)
        self.page_deposit.close_current_window()
        self.page_deposit.switch_to_window(0)
        self.page_home.logout()
        assertEqual(testdata.message1, result.message_deposit_info)

        # 管理后台页面，确认充值
        self.page_glht = self.page_home.gotoGlhtPage()
        self.page_glht_home = self.page_glht.loginNormal()
        self.page_glht_deposit = self.page_glht_home.gotoDepositPage().third()
        str_order_number = result.order_number
        result = self.page_glht_deposit.search(str_order_number)
        self.page_glht_deposit.glhtLogout()
        self.page_glht_deposit.close_current_window()
        self.page_home.switch_to_window(0)
        str_deal_time = result.deal_time
        assertEqual(float(testdata.dmoney), float(result.dmoney))
        if testdata.has_reward:
            assertEqual(float(testdata.reward), float(result.reward))

        # 前台充值记录页面，验证充值信息
        self.page_home.open()
        self.page_home.loginNormal(self.str_username, self.str_password, auth_num=self.str_authnum)
        self.page_deal_record = self.page_home.gotoDealRecordPage()
        self.page_deposit_record = self.page_deal_record.gotoRepositRecord()
        result = self.page_deposit_record.search(str_order_number)
        assertEqual(testdata.deal_type, result.deal_type)
        assertEqual(float(testdata.deal_money), float(result.deal_money))
        assertEqual(testdata.deposit_status, result.deposit_status)

        # 前台交易记录页面
        self.page_deal_detail = self.page_deal_record.gotoDealDetail()
        result = self.page_deal_detail.search(str_deal_time)
        assertEqual(float(testdata.deal_money), float(result.deal_money))
        assertEqual(testdata.deal_type, result.deal_type)
        if testdata.has_reward and int(testdata.reward) > 0:  # 验证优惠信息
            assertEqual(float(testdata.reward), float(result.reward))

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_DEPOSIT_ALIPAY_%' and normal = 'wrong_money' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_deposit_alipay_wrong_money(self, model, model1, model2, caseID, caseData):
        """
        测试场景：充值金额错误。
        :return: 
        """
        dic_original_data = {
            "model": model,
            "model1": model1,
            "model2": model2,
            "caseID": caseID,
            "caseData": caseData
        }
        testdata = TestData(dic_original_data)
        result = self.page_deposit.wrong_money(testdata)
        self.page_deposit.close_current_window()
        self.page_deposit.switch_to_window(0)
        self.page_home.logout()
        assertEqual(testdata.popupwindow1, result.message_deposit_wrong_money)


if __name__ == '__main__':
    # args = ["test_deposit_alipay_page.py::Test_Deposit_Alipay_Page::test_deposit_alipay_add_friend"]
    # args = ["test_deposit_alipay_page.py::Test_Deposit_Alipay_Page::test_deposit_alipay_scan_code"]
    # args = ["test_deposit_alipay_page.py::Test_Deposit_Alipay_Page::test_deposit_alipay_wrong_money"]
    args = ["test_deposit_alipay_page.py::Test_Deposit_Alipay_Page"]
    pytest.main(args)
