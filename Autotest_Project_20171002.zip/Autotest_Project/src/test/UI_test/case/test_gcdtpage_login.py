#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/5/25 14:08
# @Author  : Terry

import pytest

from src.test.UI_test.common.common import DataBase
from src.test.UI_test.page.HomePage import HomePage
from src.utils.assert_extra import assertEqual
from src.utils.getdb import  db_mysql_connect, unicode_dict,sql_query


class TestGcdtPageLogin(object):
    # @classmethod
    # def setup_class(cls):
    #     DataBase.reset_wrong_count('jtest')
    #     cls.page_home = HomePage()
    #     cls.page_gcdt = cls.page_home.gotoGcdtPage()
    #
    # @classmethod
    # def teardown_class(cls):
    #     cls.page_gcdt.quit()
    #     DataBase.reset_wrong_count('jtest')
    def setup_method(self):
        DataBase.reset_wrong_count('jtest')
        self.page_home = HomePage()
        self.page_gcdt = self.page_home.gotoGcdtPage()

    def teardown_method(self):
        self.page_gcdt.quit()
        DataBase.reset_wrong_count('jtest')

    str_sql = "select caseID, caseData from web_autotest_case where " \
              "caseID like 'CP_WEB_PGHEADER_LOGIN%' and normal = 'Y' ;"

    @pytest.mark.parametrize("caseID,caseData", sql_query(db_mysql_connect(), str_sql))
    def test_gcdtpage_normal_login(self, caseID, caseData):
        """
        测试购彩大厅页面【正常】登陆流程
        :return: 
        """
        dic_test_data = unicode_dict(caseData)
        str_username = unicode(dic_test_data["lg_username"])
        str_password = unicode(dic_test_data["lg_pwd"])
        str_expected_acc = unicode(dic_test_data["acc"])
        str_actual_acc = self.page_gcdt.loginNormal(str_username, str_password)
        assertEqual(str_expected_acc, str_actual_acc)
        self.page_gcdt.logoutAndClose()
        self.page_home.gotoGcdtPage()

    str_sql = "select caseID, caseData from web_autotest_case where caseID " \
              "like 'CP_WEB_PGHEADER_LOGIN%' and normal = 'N' ;"

    @pytest.mark.parametrize("caseID,caseData", sql_query(db_mysql_connect(), str_sql))
    def test_gcdtpage_abnormal_login(self, caseID, caseData):
        """
        测试购彩大厅页面【异常】登陆流程
        :return: 
        """
        dic_test_data = unicode_dict(caseData)
        str_username = unicode(dic_test_data["lg_username"], "utf-8")
        str_password = unicode(dic_test_data["lg_pwd"])
        str_expected_pop = unicode(dic_test_data["popupmessage"], "utf-8")
        str_actual_pop = self.page_gcdt.loginAbnormal(str_username, str_password)
        assertEqual(str_expected_pop, str_actual_pop)

if __name__ == "__main__":
    args = ['test_gcdtpage_login.py']
    pytest.main(args)
