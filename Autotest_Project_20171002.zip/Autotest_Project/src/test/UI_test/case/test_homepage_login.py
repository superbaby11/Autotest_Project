# -*- coding: utf-8 -*-
import unittest
import time
import pytest

from src.test.UI_test.common.common import DataBase
from src.test.UI_test.page.HomePage import HomePage
from src.utils.assert_extra import assertEqual
from src.utils.getdb import db_mysql_connect, unicode_dict, sql_query


class TestHomePageLogin(object):
    page_home = None
    # @classmethod
    # def setup_class(cls):
    #     DataBase.reset_wrong_count('jtest')
    #     cls.page_home = HomePage()
    #     cls.page_home.open()
    #
    # @classmethod
    # def teardown_class(cls):
    #     cls.page_home.quit()
    #     DataBase.reset_wrong_count('jtest')
    def setup_method(self):
        DataBase.reset_wrong_count('jtest')
        self.page_home = HomePage()
        self.page_home.open()

    def teardown_method(self):
        self.page_home.quit()
        DataBase.reset_wrong_count('jtest')

    sql = "select caseID, caseData from web_autotest_case " \
          "where caseID like 'CP_WEB_MASTERPG_LOGIN_%' and normal = 'Y'  ;"

    @pytest.mark.parametrize("caseID,caseData", sql_query(db_mysql_connect(), sql))
    def test_homepage_login_by_db(self, caseID, caseData):
        u"正常登录"
        result = -1
        caseData = unicode_dict(caseData)
        lg_username = caseData["lg_username"]
        lg_pwd = caseData["lg_pwd"]
        acc = caseData["acc"]
        result = self.page_home.loginNormal(lg_username, lg_pwd, acc=acc)
        if result == 0:
            self.page_home.logout()

    sql = "select caseID, caseData from web_autotest_case " \
          "where caseID like 'CP_WEB_MASTERPG_LOGIN_%' and normal = 'N'  ;"

    @pytest.mark.parametrize("caseID,caseData", sql_query(db_mysql_connect(), sql))
    def test_homepage_login_abnormal_by_db(self, caseID, caseData):
        u"异常登录"
        caseData = unicode_dict(caseData)
        lg_username = caseData["lg_username"]
        lg_username = unicode(lg_username, "utf-8")
        lg_pwd = caseData["lg_pwd"]
        popupmessage = caseData["popupmessage"]
        popupmessage = unicode(popupmessage, "utf-8")
        actual_result = self.page_home.loginAbnormal(lg_username, lg_pwd)
        assertEqual(popupmessage, actual_result)


if __name__ == '__main__':
    # args = ['test_homepage_login.py::TestHomePageLogin::test_homepage_login_by_db']
    # args = ['test_homepage_login.py::TestHomePageLogin::test_homepage_login_abnormal_by_db']
    args = ['test_homepage_login.py']
    pytest.main(args)
