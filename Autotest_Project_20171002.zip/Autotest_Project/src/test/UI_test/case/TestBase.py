#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/6/14 8:55
# @Author  : Terry
import os

import time

from src.test.UI_test.common.common import TestData, update
from src.test.UI_test.page.AHKS.AHKSBase import AHKSBase
from src.test.UI_test.page.AHKS.AHKS_HZ_Page import AHKS_HZ_Page
from src.test.UI_test.page.AHKS.AHKS_SBTH_BZ_Page import AHKS_SBTH_BZ_Page
from src.test.UI_test.page.AHKS.AHKS_SBTH_DT_Page import AHKS_SBTH_DT_Page
from src.test.UI_test.page.AHKS.AHKS_SLH_TX_Page import AHKS_SLH_TX_Page
from src.test.UI_test.page.AHKS.AHKS_STH_DX_Page import AHKS_STH_DX_Page
from src.test.UI_test.page.AHKS.AHKS_STH_TX_Page import AHKS_STH_TX_Page
from src.test.UI_test.page.CQSSC.CQSSCBase import CQSSCBase
from src.test.UI_test.page.CQSSC.CQSSC_4X_ZXDS_Page import CQSSC_4X_ZXDS_Page
from src.test.UI_test.page.CQSSC.CQSSC_4X_ZXFS_Page import CQSSC_4X_ZXFS_Page
from src.test.UI_test.page.CQSSC.CQSSC_BDW_H42M_Page import CQSSC_BDW_H42M_Page
from src.test.UI_test.page.CQSSC.CQSSC_BDW_H4YM_Page import CQSSC_BDW_H4YM_Page
from src.test.UI_test.page.CQSSC.CQSSC_BDW_HS2M_Page import CQSSC_BDW_HS2M_Page
from src.test.UI_test.page.CQSSC.CQSSC_BDW_HSYM_Page import CQSSC_BDW_HSYM_Page
from src.test.UI_test.page.CQSSC.CQSSC_BDW_Q42M_Page import CQSSC_BDW_Q42M_Page
from src.test.UI_test.page.CQSSC.CQSSC_BDW_Q4YM_Page import CQSSC_BDW_Q4YM_Page
from src.test.UI_test.page.CQSSC.CQSSC_BDW_QS2M_Page import CQSSC_BDW_QS2M_Page
from src.test.UI_test.page.CQSSC.CQSSC_BDW_QSYM_Page import CQSSC_BDW_QSYM_Page
from src.test.UI_test.page.CQSSC.CQSSC_BDW_WX2M_Page import CQSSC_BDW_WX2M_Page
from src.test.UI_test.page.CQSSC.CQSSC_BDW_WX3M_Page import CQSSC_BDW_WX3M_Page
from src.test.UI_test.page.CQSSC.CQSSC_BDW_WXYM_Page import CQSSC_BDW_WXYM_Page
from src.test.UI_test.page.CQSSC.CQSSC_DWD_Page import CQSSC_DWD_Page
from src.test.UI_test.page.CQSSC.CQSSC_H2_DXDS_Page import CQSSC_H2_DXDS_Page
from src.test.UI_test.page.CQSSC.CQSSC_H3_DXDS_Page import CQSSC_H3_DXDS_Page
from src.test.UI_test.page.CQSSC.CQSSC_H3_H3ZH_Page import CQSSC_H3_H3ZH_Page
from src.test.UI_test.page.CQSSC.CQSSC_H3_HHZX_Page import CQSSC_H3_HHZX_Page
from src.test.UI_test.page.CQSSC.CQSSC_H3_HZWS_Page import CQSSC_H3_HZWS_Page
from src.test.UI_test.page.CQSSC.CQSSC_H3_TSH_Page import CQSSC_H3_TSH_Page
from src.test.UI_test.page.CQSSC.CQSSC_H3_Z3DS_Page import CQSSC_H3_Z3DS_Page
from src.test.UI_test.page.CQSSC.CQSSC_H3_Z3FS_Page import CQSSC_H3_Z3FS_Page
from src.test.UI_test.page.CQSSC.CQSSC_H3_Z6DS_Page import CQSSC_H3_Z6DS_Page
from src.test.UI_test.page.CQSSC.CQSSC_H3_Z6FS_Page import CQSSC_H3_Z6FS_Page
from src.test.UI_test.page.CQSSC.CQSSC_H3_ZUXHZ_Page import CQSSC_H3_ZUXHZ_Page
from src.test.UI_test.page.CQSSC.CQSSC_H3_ZXBD_Page import CQSSC_H3_ZXBD_Page
from src.test.UI_test.page.CQSSC.CQSSC_H3_ZXDS_Page import CQSSC_H3_ZXDS_Page
from src.test.UI_test.page.CQSSC.CQSSC_H3_ZXFS_Page import CQSSC_H3_ZXFS_Page
from src.test.UI_test.page.CQSSC.CQSSC_H3_ZXHZ_Page import CQSSC_H3_ZXHZ_Page
from src.test.UI_test.page.CQSSC.CQSSC_H3_ZXKD_Page import CQSSC_H3_ZXKD_Page
from src.test.UI_test.page.CQSSC.CQSSC_Q2_DXDS_Page import CQSSC_Q2_DXDS_Page
from src.test.UI_test.page.CQSSC.CQSSC_Q2_ZUXDS_Page import CQSSC_Q2_ZUXDS_Page
from src.test.UI_test.page.CQSSC.CQSSC_Q2_ZUXFS_Page import CQSSC_Q2_ZUXFS_Page
from src.test.UI_test.page.CQSSC.CQSSC_Q2_ZUXHZ_Page import CQSSC_Q2_ZUXHZ_Page
from src.test.UI_test.page.CQSSC.CQSSC_Q2_ZXBD_Page import CQSSC_Q2_ZXBD_Page
from src.test.UI_test.page.CQSSC.CQSSC_Q2_ZXDS_Page import CQSSC_Q2_ZXDS_Page
from src.test.UI_test.page.CQSSC.CQSSC_Q2_ZXFS_Page import CQSSC_Q2_ZXFS_Page
from src.test.UI_test.page.CQSSC.CQSSC_Q2_ZXHZ_Page import CQSSC_Q2_ZXHZ_Page
from src.test.UI_test.page.CQSSC.CQSSC_Q2_ZXKD_Page import CQSSC_Q2_ZXKD_Page
from src.test.UI_test.page.CQSSC.CQSSC_Q3_DXDS_Page import CQSSC_Q3_DXDS_Page
from src.test.UI_test.page.CQSSC.CQSSC_Q3_HHZX_Page import CQSSC_Q3_HHZX_Page
from src.test.UI_test.page.CQSSC.CQSSC_Q3_HZWS_Page import CQSSC_Q3_HZWS_Page
from src.test.UI_test.page.CQSSC.CQSSC_Q3_Q3ZH_Page import CQSSC_Q3_Q3ZH_Page
from src.test.UI_test.page.CQSSC.CQSSC_Q3_TSH_Page import CQSSC_Q3_TSH_Page
from src.test.UI_test.page.CQSSC.CQSSC_Q3_Z3DS_Page import CQSSC_Q3_Z3DS_Page
from src.test.UI_test.page.CQSSC.CQSSC_Q3_Z3FS_Page import CQSSC_Q3_Z3FS_Page
from src.test.UI_test.page.CQSSC.CQSSC_Q3_Z6DS_Page import CQSSC_Q3_Z6DS_Page
from src.test.UI_test.page.CQSSC.CQSSC_Q3_Z6FS_Page import CQSSC_Q3_Z6FS_Page
from src.test.UI_test.page.CQSSC.CQSSC_Q3_ZUXHZ_Page import CQSSC_Q3_ZUXHZ_Page
from src.test.UI_test.page.CQSSC.CQSSC_Q3_ZXBD_Page import CQSSC_Q3_ZXBD_Page
from src.test.UI_test.page.CQSSC.CQSSC_Q3_ZXDS_Page import CQSSC_Q3_ZXDS_Page
from src.test.UI_test.page.CQSSC.CQSSC_Q3_ZXFS_Page import CQSSC_Q3_ZXFS_Page
from src.test.UI_test.page.CQSSC.CQSSC_Q3_ZXHZ_Page import CQSSC_Q3_ZXHZ_Page
from src.test.UI_test.page.CQSSC.CQSSC_Q3_ZXKD_Page import CQSSC_Q3_ZXKD_Page
from src.test.UI_test.page.CQSSC.CQSSC_RX2_ZUXDS_Page import CQSSC_RX2_ZUXDS_Page
from src.test.UI_test.page.CQSSC.CQSSC_RX2_ZUXFS_Page import CQSSC_RX2_ZUXFS_Page
from src.test.UI_test.page.CQSSC.CQSSC_RX2_ZUXHZ_Page import CQSSC_RX2_ZUXHZ_Page
from src.test.UI_test.page.CQSSC.CQSSC_RX2_ZXDS_Page import CQSSC_RX2_ZXDS_Page
from src.test.UI_test.page.CQSSC.CQSSC_RX2_ZXFS_Page import CQSSC_RX2_ZXFS_Page
from src.test.UI_test.page.CQSSC.CQSSC_RX2_ZXHZ_Page import CQSSC_RX2_ZXHZ_Page
from src.test.UI_test.page.CQSSC.CQSSC_RX3_HHZX_Page import CQSSC_RX3_HHZX_Page
from src.test.UI_test.page.CQSSC.CQSSC_RX3_Z3DS_Page import CQSSC_RX3_Z3DS_Page
from src.test.UI_test.page.CQSSC.CQSSC_RX3_Z3FS_Page import CQSSC_RX3_Z3FS_Page
from src.test.UI_test.page.CQSSC.CQSSC_RX3_Z6DS_Page import CQSSC_RX3_Z6DS_Page
from src.test.UI_test.page.CQSSC.CQSSC_RX3_Z6FS_Page import CQSSC_RX3_Z6FS_Page
from src.test.UI_test.page.CQSSC.CQSSC_RX3_ZUXHZ_Page import CQSSC_RX3_ZUXHZ_Page
from src.test.UI_test.page.CQSSC.CQSSC_RX3_ZXDS_Page import CQSSC_RX3_ZXDS_Page
from src.test.UI_test.page.CQSSC.CQSSC_RX3_ZXFS_Page import CQSSC_RX3_ZXFS_Page
from src.test.UI_test.page.CQSSC.CQSSC_RX3_ZXHZ_Page import CQSSC_RX3_ZXHZ_Page
from src.test.UI_test.page.CQSSC.CQSSC_RX4_ZX12_Page import CQSSC_RX4_ZX12_Page
from src.test.UI_test.page.CQSSC.CQSSC_RX4_ZX24_Page import CQSSC_RX4_ZX24_Page
from src.test.UI_test.page.CQSSC.CQSSC_RX4_ZX4_Page import CQSSC_RX4_ZX4_Page
from src.test.UI_test.page.CQSSC.CQSSC_RX4_ZX6_Page import CQSSC_RX4_ZX6_Page
from src.test.UI_test.page.CQSSC.CQSSC_RX4_ZXDS_Page import CQSSC_RX4_ZXDS_Page
from src.test.UI_test.page.CQSSC.CQSSC_RX4_ZXFS_Page import CQSSC_RX4_ZXFS_Page
from src.test.UI_test.page.CQSSC.CQSSC_WX_ZXDS_Page import CQSSC_WX_ZXDS_Page
from src.test.UI_test.page.CQSSC.CQSSC_WX_ZXFS_Page import CQSSC_WX_ZXFS_Page
from src.test.UI_test.page.KLPK.KLPKBase import KLPKBase
from src.test.UI_test.page.KLPK.KLPK_RXFS_RX1_Page import KLPK_RXFS_RX1_Page
from src.test.UI_test.page.KLPK.KLPK_TH_BX_Page import KLPK_TH_BX_Page
from src.test.UI_test.page.KLPK.KLPK_TH_DX_Page import KLPK_TH_DX_Page
from src.test.UI_test.page.Manage.DealRecord.DealDetailPage import DealDetailPage
from src.test.UI_test.page.PK10.PK10Base import PK10Base
from src.test.UI_test.page.PK10.PK10_DWD_Page import PK10_DWD_Page
from src.test.UI_test.page.PK10.PK10_Q1_ZXFS_Page import PK10_Q1_ZXFS_Page
from src.test.UI_test.page.PK10.PK10_Q2_ZXDS_Page import PK10_Q2_ZXDS_Page
from src.test.UI_test.page.PK10.PK10_Q2_ZXFS_Page import PK10_Q2_ZXFS_Page
from src.test.UI_test.page.PK10.PK10_Q3_ZXDS_Page import PK10_Q3_ZXDS_Page
from src.test.UI_test.page.PK10.PK10_Q3_ZXFS_Page import PK10_Q3_ZXFS_Page
from src.test.UI_test.page.PLS.PLSBase import PLSBase
from src.test.UI_test.page.PLS.PLS_SX_ZLFS_Page import PLS_SX_ZLFS_Page
from src.test.UI_test.page.PLS.PLS_SX_ZLHZ_Page import PLS_SX_ZLHZ_Page
from src.test.UI_test.page.PLS.PLS_SX_ZSFS_Page import PLS_SX_ZSFS_Page
from src.test.UI_test.page.PLS.PLS_SX_ZSHZ_Page import PLS_SX_ZSHZ_Page
from src.test.UI_test.page.PLS.PLS_SX_ZXDS_Page import PLS_SX_ZXDS_Page
from src.test.UI_test.page.PLS.PLS_SX_ZXFS_Page import PLS_SX_ZXFS_Page
from src.test.UI_test.page.PLS.PLS_SX_ZXHZ_Page import PLS_SX_ZXHZ_Page
from src.test.UI_test.page.XYNC.XYNCBase import XYNCBase
from src.test.UI_test.page.XYNC.XYNC_X1_HT_Page import XYNC_X1_HT_Page
from src.test.UI_test.page.XYNC.XYNC_X1_ST_Page import XYNC_X1_ST_Page
from src.test.UI_test.page.XYNC.XYNC_X2_LZDT_Page import XYNC_X2_LZDT_Page
from src.test.UI_test.page.XYNC.XYNC_X2_LZH_Page import XYNC_X2_LZH_Page
from src.test.UI_test.page.XYNC.XYNC_X2_LZ_Page import XYNC_X2_LZ_Page
from src.test.UI_test.page.XYNC.XYNC_X2_RX2_Page import XYNC_X2_RX2_Page
from src.test.UI_test.page.XYNC.XYNC_X2_RXDT_Page import XYNC_X2_RXDT_Page
from src.test.UI_test.page.XYNC.XYNC_X3_QZDT_Page import XYNC_X3_QZDT_Page
from src.test.UI_test.page.XYNC.XYNC_X3_QZH_Page import XYNC_X3_QZH_Page
from src.test.UI_test.page.XYNC.XYNC_X3_QZ_Page import XYNC_X3_QZ_Page
from src.test.UI_test.page.XYNC.XYNC_X3_RXDT_Page import XYNC_X3_RXDT_Page
from src.test.UI_test.page.XYNC.XYNC_X3_RX_Page import XYNC_X3_RX_Page
from src.test.UI_test.page.XYNC.XYNC_X4_RXDT_Page import XYNC_X4_RXDT_Page
from src.test.UI_test.page.XYNC.XYNC_X4_RX_Page import XYNC_X4_RX_Page
from src.test.UI_test.page.XYNC.XYNC_X5_RXDT_Page import XYNC_X5_RXDT_Page
from src.test.UI_test.page.XYNC.XYNC_X5_RX_Page import XYNC_X5_RX_Page
from src.utils.assert_extra import assertEqual
from src.utils.config import DefaultConfig_Project, DefaultConfig


class TestBase(object):
    # 执行测试方法时，生成对应的彩种页面类
    dic_lottery = {
        u"PK10": PK10Base,
        u"重庆时时彩": CQSSCBase,
        u"安徽快三": AHKSBase,
        u"排列三": PLSBase,
        u"幸运农场": XYNCBase,
        u"快乐扑克": KLPKBase,
    }
    # 执行测试方法时，生成对应的玩法页面类
    dic_mothod = {
        u"PK10_前一_直选复式": PK10_Q1_ZXFS_Page,
        u"PK10_前二_直选复式": PK10_Q2_ZXFS_Page,
        u"PK10_前二_直选单式": PK10_Q2_ZXDS_Page,
        u"PK10_前三_直选复式": PK10_Q3_ZXFS_Page,
        u"PK10_前三_直选单式": PK10_Q3_ZXDS_Page,
        u"PK10_定位胆_直选复式": PK10_DWD_Page,
        u"重庆时时彩_五星_直选复式": CQSSC_WX_ZXFS_Page,
        u"重庆时时彩_五星_直选单式": CQSSC_WX_ZXDS_Page,
        u"重庆时时彩_四星_直选复式": CQSSC_4X_ZXFS_Page,
        u"重庆时时彩_四星_直选单式": CQSSC_4X_ZXDS_Page,
        u"重庆时时彩_后三_直选复式": CQSSC_H3_ZXFS_Page,
        u"重庆时时彩_后三_直选单式": CQSSC_H3_ZXDS_Page,
        u"重庆时时彩_后三_后三组合": CQSSC_H3_H3ZH_Page,
        u"重庆时时彩_后三_直选和值": CQSSC_H3_ZXHZ_Page,
        u"重庆时时彩_后三_直选跨度": CQSSC_H3_ZXKD_Page,
        u"重庆时时彩_后三_组三复式": CQSSC_H3_Z3FS_Page,
        u"重庆时时彩_后三_组三单式": CQSSC_H3_Z3DS_Page,
        u"重庆时时彩_后三_组六复式": CQSSC_H3_Z6FS_Page,
        u"重庆时时彩_后三_组六单式": CQSSC_H3_Z6DS_Page,
        u"重庆时时彩_后三_混合组选": CQSSC_H3_HHZX_Page,
        u"重庆时时彩_后三_组选和值": CQSSC_H3_ZUXHZ_Page,
        u"重庆时时彩_后三_组选包胆": CQSSC_H3_ZXBD_Page,
        u"重庆时时彩_后三_和值尾数": CQSSC_H3_HZWS_Page,
        u"重庆时时彩_后三_特殊号": CQSSC_H3_TSH_Page,
        u"重庆时时彩_前三_直选复式": CQSSC_Q3_ZXFS_Page,
        u"重庆时时彩_前三_直选单式": CQSSC_Q3_ZXDS_Page,
        u"重庆时时彩_前三_前三组合": CQSSC_Q3_Q3ZH_Page,
        u"重庆时时彩_前三_直选和值": CQSSC_Q3_ZXHZ_Page,
        u"重庆时时彩_前三_直选跨度": CQSSC_Q3_ZXKD_Page,
        u"重庆时时彩_前三_组三复式": CQSSC_Q3_Z3FS_Page,
        u"重庆时时彩_前三_组三单式": CQSSC_Q3_Z3DS_Page,
        u"重庆时时彩_前三_组六复式": CQSSC_Q3_Z6FS_Page,
        u"重庆时时彩_前三_组六单式": CQSSC_Q3_Z6DS_Page,
        u"重庆时时彩_前三_混合组选": CQSSC_Q3_HHZX_Page,
        u"重庆时时彩_前三_组选和值": CQSSC_Q3_ZUXHZ_Page,
        u"重庆时时彩_前三_组选包胆": CQSSC_Q3_ZXBD_Page,
        u"重庆时时彩_前三_和值尾数": CQSSC_Q3_HZWS_Page,
        u"重庆时时彩_前三_特殊号": CQSSC_Q3_TSH_Page,
        u"重庆时时彩_前二_直选复式": CQSSC_Q2_ZXFS_Page,
        u"重庆时时彩_前二_直选单式": CQSSC_Q2_ZXDS_Page,
        u"重庆时时彩_前二_直选和值": CQSSC_Q2_ZXHZ_Page,
        u"重庆时时彩_前二_直选跨度": CQSSC_Q2_ZXKD_Page,
        u"重庆时时彩_前二_组选复式": CQSSC_Q2_ZUXFS_Page,
        u"重庆时时彩_前二_组选单式": CQSSC_Q2_ZUXDS_Page,
        u"重庆时时彩_前二_组选和值": CQSSC_Q2_ZUXHZ_Page,
        u"重庆时时彩_前二_组选包胆": CQSSC_Q2_ZXBD_Page,
        u"重庆时时彩_定位胆_定位胆": CQSSC_DWD_Page,
        u"重庆时时彩_不定位_前三一码": CQSSC_BDW_QSYM_Page,
        u"重庆时时彩_不定位_前三二码": CQSSC_BDW_QS2M_Page,
        u"重庆时时彩_不定位_后三一码": CQSSC_BDW_HSYM_Page,
        u"重庆时时彩_不定位_后三二码": CQSSC_BDW_HS2M_Page,
        u"重庆时时彩_不定位_前四一码": CQSSC_BDW_Q4YM_Page,
        u"重庆时时彩_不定位_前四二码": CQSSC_BDW_Q42M_Page,
        u"重庆时时彩_不定位_后四一码": CQSSC_BDW_H4YM_Page,
        u"重庆时时彩_不定位_后四二码": CQSSC_BDW_H42M_Page,
        u"重庆时时彩_不定位_五星一码": CQSSC_BDW_WXYM_Page,
        u"重庆时时彩_不定位_五星二码": CQSSC_BDW_WX2M_Page,
        u"重庆时时彩_不定位_五星三码": CQSSC_BDW_WX3M_Page,
        u"重庆时时彩_大小单双_前二大小单双": CQSSC_Q2_DXDS_Page,
        u"重庆时时彩_大小单双_后二大小单双": CQSSC_H2_DXDS_Page,
        u"重庆时时彩_大小单双_前三大小单双": CQSSC_Q3_DXDS_Page,
        u"重庆时时彩_大小单双_后三大小单双": CQSSC_H3_DXDS_Page,
        u"重庆时时彩_任选二_直选复式": CQSSC_RX2_ZXFS_Page,
        u"重庆时时彩_任选二_直选单式": CQSSC_RX2_ZXDS_Page,
        u"重庆时时彩_任选二_直选和值": CQSSC_RX2_ZXHZ_Page,
        u"重庆时时彩_任选二_组选复式": CQSSC_RX2_ZUXFS_Page,
        u"重庆时时彩_任选二_组选单式": CQSSC_RX2_ZUXDS_Page,
        u"重庆时时彩_任选二_组选和值": CQSSC_RX2_ZUXHZ_Page,
        u"重庆时时彩_任选三_直选复式": CQSSC_RX3_ZXFS_Page,
        u"重庆时时彩_任选三_直选单式": CQSSC_RX3_ZXDS_Page,
        u"重庆时时彩_任选三_直选和值": CQSSC_RX3_ZXHZ_Page,
        u"重庆时时彩_任选三_组三复式": CQSSC_RX3_Z3FS_Page,
        u"重庆时时彩_任选三_组三单式": CQSSC_RX3_Z3DS_Page,
        u"重庆时时彩_任选三_组六复式": CQSSC_RX3_Z6FS_Page,
        u"重庆时时彩_任选三_组六单式": CQSSC_RX3_Z6DS_Page,
        u"重庆时时彩_任选三_混合组选": CQSSC_RX3_HHZX_Page,
        u"重庆时时彩_任选三_组选和值": CQSSC_RX3_ZUXHZ_Page,
        u"重庆时时彩_任选四_直选复式": CQSSC_RX4_ZXFS_Page,
        u"重庆时时彩_任选四_直选单式": CQSSC_RX4_ZXDS_Page,
        u"重庆时时彩_任选四_组选24": CQSSC_RX4_ZX24_Page,
        u"重庆时时彩_任选四_组选12": CQSSC_RX4_ZX12_Page,
        u"重庆时时彩_任选四_组选6": CQSSC_RX4_ZX6_Page,
        u"重庆时时彩_任选四_组选4": CQSSC_RX4_ZX4_Page,
        u"安徽快三_和值_和值": AHKS_HZ_Page,
        u"安徽快三_三同号_通选": AHKS_STH_TX_Page,
        u"安徽快三_三同号_单选": AHKS_STH_DX_Page,
        u"安徽快三_三不同号_标准": AHKS_SBTH_BZ_Page,
        u"安徽快三_三不同号_胆拖": AHKS_SBTH_DT_Page,
        u"安徽快三_三连号_通选": AHKS_SLH_TX_Page,
        u"排列三_三星_直选复式": PLS_SX_ZXFS_Page,
        u"排列三_三星_直选单式": PLS_SX_ZXDS_Page,
        u"排列三_三星_直选和值": PLS_SX_ZXHZ_Page,
        u"排列三_三星_组三复式": PLS_SX_ZSFS_Page,
        u"排列三_三星_组六复式": PLS_SX_ZLFS_Page,
        u"排列三_三星_组三和值": PLS_SX_ZSHZ_Page,
        u"排列三_三星_组六和值": PLS_SX_ZLHZ_Page,
        u"幸运农场_选一_数投": XYNC_X1_ST_Page,
        u"幸运农场_选一_红投": XYNC_X1_HT_Page,
        u"幸运农场_选二_任选二": XYNC_X2_RX2_Page,
        u"幸运农场_选二_任选胆拖": XYNC_X2_RXDT_Page,
        u"幸运农场_选二_连组": XYNC_X2_LZ_Page,
        u"幸运农场_选二_连组胆拖": XYNC_X2_LZDT_Page,
        u"幸运农场_选二_连直": XYNC_X2_LZH_Page,
        u"幸运农场_选三_任选": XYNC_X3_RX_Page,
        u"幸运农场_选三_任选胆拖": XYNC_X3_RXDT_Page,
        u"幸运农场_选三_前组": XYNC_X3_QZ_Page,
        u"幸运农场_选三_前组胆拖": XYNC_X3_QZDT_Page,
        u"幸运农场_选三_前直": XYNC_X3_QZH_Page,
        u"幸运农场_选四_任选": XYNC_X4_RX_Page,
        u"幸运农场_选四_任选胆拖": XYNC_X4_RXDT_Page,
        u"幸运农场_选五_任选": XYNC_X5_RX_Page,
        u"幸运农场_选五_任选胆拖": XYNC_X5_RXDT_Page,
        u"快乐扑克_同花_包选": KLPK_TH_BX_Page,
        u"快乐扑克_同花_单选": KLPK_TH_DX_Page,
        u"快乐扑克_任选复式_任选一": KLPK_RXFS_RX1_Page,
    }

    # 声明页面实例变量，变量赋值在子类的setup里完成。
    page_home = None
    page_gcdt = None

    def _goto_method_page(self, model, model1, model2):
        """
        从购彩大厅页面跳转到某个彩种的玩法页面。
        :param model: 彩种，北京PK拾。
        :param model1: 大玩法，前一。
        :param model2: 小玩法，直选复式。
        :return: 
        """
        self.page_gcdt.gotoLottery(model)
        if model in self.dic_lottery.keys():
            self.page_lottery = (self.dic_lottery[model])(self.page_gcdt.getDriver())
            try:
                self.page_lottery.gotoGameMethod(model1, model2)
            except:
                # 如果失败就再试一次
                time.sleep(10)
                self.page_lottery.gotoGameMethod(model1, model2)
            str_key = "_".join([model, model1, model2])
            if str_key in self.dic_mothod.keys():
                self.page_method = (self.dic_mothod[str_key])(self.page_lottery.getDriver())  # 创建页面类实例
            else:
                raise KeyError("\nInvalid model1: %s or model2: %s.\nShould be one of %s."
                               % (model1, model2, ", ".join(self.dic_mothod.keys())))
        else:
            raise KeyError("\nInvalid model: %s.\nShould be one of %s." % (model, ", ".join(self.dic_lottery.keys())))

        return self.page_method

    def normal(self, model, model1, model2, caseID, caseData):
        """
        测试正常投注流程。
        :param model: 彩种，例如北京pk拾。
        :param model1: 大玩法，例如前一。
        :param model2: 小玩法，例如直选复式。
        :param caseID: 测试数据ID，在Excel中。
        :param caseData: 测试数据，在Excel中。
        :return: 
        """
        dic_original_data = {
            "model": model,
            "model1": model1,
            "model2": model2,
            "caseID": caseID,
            "caseData": caseData
        }
        testdata = TestData(dic_original_data)

        # part1: 投注
        self.page_method = self._goto_method_page(testdata.model, testdata.model1, testdata.model2)
        if testdata.has_upload:  # 若测试数据含有upload，则从文件中读取投注号码。
            str_file_path = DefaultConfig().data_web_path
            str_file = os.path.abspath(os.path.join(str_file_path, testdata.codes))
            if not os.path.isfile(str_file):
                raise IOError("\nFile: %s not exist!" % str_file)
            else:
                testdata.codes = str_file
        result = self.page_method.bet_normal(testdata)
        str_bet_time = result.bet_time

        if testdata.has_times or testdata.has_term:  # 追号时，在此断言金额。
            assertEqual(float(testdata.bet_money), float(result.total_money))
        else:
            # 更新期待的弹窗信息
            testdata.popupwindow1 = update(testdata.popupwindow1, self.page_method.get_issue())

        # 弹窗消息断言
        assertEqual(testdata.popupwindow1, result.message_confirm_bet)
        assertEqual(testdata.popupwindow2, result.message_bet_success)

        # part2: 检查投注记录
        self.page_bet_record = self.page_method.gotoBetRecordPage()

        # 投注记录断言
        if testdata.has_term:  # 追号
            result = self.page_bet_record.search(str_bet_time, str_record_num=10)
            assertEqual(int(testdata.term), int(result.bet_item))
        elif testdata.has_random:  # 或者随机投注
            result = self.page_bet_record.search(str_bet_time, str_record_num=5)
            assertEqual(int(testdata.random), int(result.bet_item))
        else:
            result = self.page_bet_record.search(str_bet_time)
            assertEqual(float(testdata.each_money), float(result.each_money))
            assertEqual(float(testdata.bet_money), float(result.bet_money))
        if not ((u"快三" in testdata.model) and (u"和值" in testdata.model1)):
            assertEqual(testdata.methodid, result.method)

        # part3: 检查交易记录
        self.page_bet_record.gotoDealDetail()
        self.page_deal_detail = DealDetailPage(self.page_bet_record.getDriver())

        # 交易记录断言
        if testdata.has_term:  # 追号
            result = self.page_deal_detail.search(str_bet_time, str_record_num=10)
        elif testdata.has_random:  # 随机投注
            result = self.page_deal_detail.search(str_bet_time)
        else:
            result = self.page_deal_detail.search(str_bet_time)
            assertEqual(float(testdata.deal_money), float(result.deal_money))

        assertEqual(testdata.income_and_expenses, result.income_and_expense)
        assertEqual(testdata.deal_type, result.deal_type)

        # 回到购彩大厅页面
        self.page_deal_detail.close_current_window()
        self.page_method.switch_to_window(1)
        self.page_method.close_current_window()
        self.page_home.switch_to_window(0)
        self.page_gcdt = self.page_home.gotoGcdtPage()

    def insufficient(self, model, model1, model2, caseID, caseData):
        """
        测试场景：玩家投注时余额不足。
        :param model: 彩种，例如北京pk拾。
        :param model1: 大玩法，例如前一。
        :param model2: 小玩法，例如直选复式。
        :param caseID: 测试数据ID，在Excel中。
        :param caseData: 测试数据，在Excel中。
        :return: 
        """
        dic_original_data = {
            "model": model,
            "model1": model1,
            "model2": model2,
            "caseID": caseID,
            "caseData": caseData
        }
        testdata = TestData(dic_original_data)

        # 退出当前余额充足的用户，登录余额不足的用户
        self.page_gcdt.logoutAndClose()
        self.page_gcdt = self.page_home.gotoGcdtPage()
        str_username = DefaultConfig_Project().get("users", "username_no_money")
        str_password = DefaultConfig_Project().get("users", "password_no_money")
        str_authnum = DefaultConfig_Project().get("users", "auth_num_no_money")
        self.page_gcdt.loginNormal(str_username, str_password, str_authnum)

        # part1: 投注
        self.page_method = self._goto_method_page(testdata.model, testdata.model1, testdata.model2)
        result = self.page_method.insufficient(testdata)

        # 更新期待的弹窗信息
        str_popup_message1 = update(testdata.popupwindow1, self.page_method.get_issue())

        # 弹窗消息断言
        assertEqual(str_popup_message1, result.message_confirm_bet)
        assertEqual(testdata.popupwindow2, result.message_bet_success)

        # 回到购彩大厅页面
        self.page_method.close_current_window()
        self.page_home.switch_to_window(0)
        self.page_home.logout()
        self.page_gcdt = self.page_home.gotoGcdtPage()
        str_username = DefaultConfig_Project().user_name
        str_password = DefaultConfig_Project().pass_word
        str_authnum = DefaultConfig_Project().auth_num
        self.page_gcdt.loginNormal(str_username, str_password, str_authnum)

    def clean_all(self, model, model1, model2, caseID, caseData):
        """
        测试场景：玩家投注后，清除全部注单。
        :param model: 彩种，例如北京pk拾。
        :param model1: 大玩法，例如前一。
        :param model2: 小玩法，例如直选复式。
        :param caseID: 测试数据ID，在Excel中。
        :param caseData: 测试数据，在Excel中。
        :return: 
        """
        dic_original_data = {
            "model": model,
            "model1": model1,
            "model2": model2,
            "caseID": caseID,
            "caseData": caseData
        }
        testdata = TestData(dic_original_data)
        # part1: 投注
        self.page_method = self._goto_method_page(testdata.model, testdata.model1, testdata.model2)
        result = self.page_method.bet_clean_all(testdata)
        assertEqual(testdata.popupwindow1, result.message_clean_all)

        # 回到购彩大厅页面
        self.page_method.close_current_window()
        self.page_home.switch_to_window(0)
        self.page_gcdt = self.page_home.gotoGcdtPage()

    def clean_one(self, model, model1, model2, caseID, caseData):
        """
        测试场景：添加注单后，删除一个注单。
        :param model: 彩种，例如北京pk拾。
        :param model1: 大玩法，例如前一。
        :param model2: 小玩法，例如直选复式。
        :param caseID: 测试数据ID，在Excel中。
        :param caseData: 测试数据，在Excel中。
        :return: 
        """
        dic_original_data = {
            "model": model,
            "model1": model1,
            "model2": model2,
            "caseID": caseID,
            "caseData": caseData
        }
        testdata = TestData(dic_original_data)
        # part1: 投注
        self.page_method = self._goto_method_page(testdata.model, testdata.model1, testdata.model2)
        str_actual_popup_message = self.page_method.clean_one(testdata.codes)
        assertEqual(testdata.popupwindow1, str_actual_popup_message)

        # 回到购彩大厅页面
        self.page_method.close_current_window()
        self.page_home.switch_to_window(0)
        self.page_gcdt = self.page_home.gotoGcdtPage()

    def change_normal_to_random(self, model, model1, model2, caseID, caseData):
        """
        选择一个号码，不点击‘添加注单’，点击‘随机一注’。
        :param model: 彩种，例如北京pk拾。
        :param model1: 大玩法，例如前一。
        :param model2: 小玩法，例如直选复式。
        :param caseID: 测试数据ID，在Excel中。
        :param caseData: 测试数据，在Excel中。
        :return: 
        """
        dic_original_data = {
            "model": model,
            "model1": model1,
            "model2": model2,
            "caseID": caseID,
            "caseData": caseData
        }
        testdata = TestData(dic_original_data)
        # part1: 投注
        self.page_method = self._goto_method_page(testdata.model, testdata.model1, testdata.model2)
        str_actual_popup_message = self.page_method.change_normal_to_random(testdata.codes, testdata.random)
        assertEqual(testdata.popupwindow1, str_actual_popup_message)

        # 回到购彩大厅页面
        self.page_method.close_current_window()
        self.page_home.switch_to_window(0)
        self.page_gcdt = self.page_home.gotoGcdtPage()

    def add_empty(self, model, model1, model2, caseID, caseData):
        """
        测试场景：没有选择投注号码，添加注单。
        :param model: 彩种，例如北京pk拾。
        :param model1: 大玩法，例如前一。
        :param model2: 小玩法，例如直选复式。
        :param caseID: 测试数据ID，在Excel中。
        :param caseData: 测试数据，在Excel中。
        :return: 
        """
        dic_original_data = {
            "model": model,
            "model1": model1,
            "model2": model2,
            "caseID": caseID,
            "caseData": caseData
        }
        testdata = TestData(dic_original_data)
        # part1: 投注
        self.page_method = self._goto_method_page(testdata.model, testdata.model1, testdata.model2)
        str_actual_popup_message = self.page_method.add_empty()
        assertEqual(testdata.popupwindow1, str_actual_popup_message)

        # 回到购彩大厅页面
        self.page_method.close_current_window()
        self.page_home.switch_to_window(0)
        self.page_gcdt = self.page_home.gotoGcdtPage()

    def buy_empty(self, model, model1, model2, caseID, caseData):
        """
        测试场景：没有选择投注号码，确认投注。
        :param model: 彩种，例如北京pk拾。
        :param model1: 大玩法，例如前一。
        :param model2: 小玩法，例如直选复式。
        :param caseID: 测试数据ID，在Excel中。
        :param caseData: 测试数据，在Excel中。
        :return: 
        """
        dic_original_data = {
            "model": model,
            "model1": model1,
            "model2": model2,
            "caseID": caseID,
            "caseData": caseData
        }
        testdata = TestData(dic_original_data)
        # part1: 投注
        self.page_method = self._goto_method_page(testdata.model, testdata.model1, testdata.model2)
        str_actual_popup_message = self.page_method.buy_empty()
        assertEqual(testdata.popupwindow1, str_actual_popup_message)

        # 回到购彩大厅页面
        self.page_method.close_current_window()
        self.page_home.switch_to_window(0)
        self.page_gcdt = self.page_home.gotoGcdtPage()

    def wrong_money(self, model, model1, model2, caseID, caseData):
        """
        测试场景：投注时，输入错误的单注额，比如0元每注。
        :param model: 彩种，例如北京pk拾。
        :param model1: 大玩法，例如前一。
        :param model2: 小玩法，例如直选复式。
        :param caseID: 测试数据ID，在Excel中。
        :param caseData: 测试数据，在Excel中。
        :return: 
        """
        dic_original_data = {
            "model": model,
            "model1": model1,
            "model2": model2,
            "caseID": caseID,
            "caseData": caseData
        }
        testdata = TestData(dic_original_data)
        # part1: 投注
        self.page_method = self._goto_method_page(testdata.model, testdata.model1, testdata.model2)
        str_actual_popup_message = \
            self.page_method.wrong_money(testdata.codes, str_each_money=testdata.money)
        assertEqual(testdata.popupwindow1, str_actual_popup_message)

        # 回到购彩大厅页面
        self.page_method.close_current_window()
        self.page_home.switch_to_window(0)
        self.page_gcdt = self.page_home.gotoGcdtPage()

    def wrong_codes(self, model, model1, model2, caseID, caseData):
        """
        测试场景：玩家输入错误的投注号码。
        :param model: 彩种，例如北京pk拾。
        :param model1: 大玩法，例如前一。
        :param model2: 小玩法，例如直选复式。
        :param caseID: 测试数据ID，在Excel中。
        :param caseData: 测试数据，在Excel中。
        :return: 
        """
        dic_original_data = {
            "model": model,
            "model1": model1,
            "model2": model2,
            "caseID": caseID,
            "caseData": caseData
        }
        testdata = TestData(dic_original_data)
        # part1: 投注
        self.page_method = self._goto_method_page(testdata.model, testdata.model1, testdata.model2)
        result = self.page_method.wrong_codes(testdata)
        assertEqual(testdata.popupwindow1, result.message_wrong_codes)

        # 回到购彩大厅页面
        self.page_method.close_current_window()
        self.page_home.switch_to_window(0)
        self.page_gcdt = self.page_home.gotoGcdtPage()

    def wrong_term(self, model, model1, model2, caseID, caseData):
        """
        测试场景：玩家输入超大的追号期数。
        :param model: 彩种，例如北京pk拾。
        :param model1: 大玩法，例如前一。
        :param model2: 小玩法，例如直选复式。
        :param caseID: 测试数据ID，在Excel中。
        :param caseData: 测试数据，在Excel中。
        :return: 
        """
        dic_original_data = {
            "model": model,
            "model1": model1,
            "model2": model2,
            "caseID": caseID,
            "caseData": caseData
        }
        testdata = TestData(dic_original_data)
        # part1: 投注
        self.page_method = self._goto_method_page(testdata.model, testdata.model1, testdata.model2)
        result = self.page_method.wrong_term(testdata)
        assertEqual(testdata.popupwindow1, result.message_wrong_term)

        # 回到购彩大厅页面
        self.page_method.close_current_window()
        self.page_home.switch_to_window(0)
        self.page_gcdt = self.page_home.gotoGcdtPage()

    def remove_duplication(self, model, model1, model2, caseID, caseData):
        """
        测试场景：删除重复的投注号码。
        :param model: 彩种，例如北京pk拾。
        :param model1: 大玩法，例如前一。
        :param model2: 小玩法，例如直选复式。
        :param caseID: 测试数据ID，在Excel中。
        :param caseData: 测试数据，在Excel中。
        :return: 
        """
        dic_original_data = {
            "model": model,
            "model1": model1,
            "model2": model2,
            "caseID": caseID,
            "caseData": caseData
        }
        testdata = TestData(dic_original_data)

        # part1: 投注
        self.page_method = self._goto_method_page(testdata.model, testdata.model1, testdata.model2)
        result = self.page_method.remove_duplication(testdata)
        str_bet_time = self.page_method.getBetTime()

        # 更新期待的弹窗信息
        str_popup_message2 = update(testdata.popupwindow2, self.page_method.get_issue())

        # 弹窗消息断言
        assertEqual(testdata.popupwindow1, result.message_remove_duplication)
        assertEqual(str_popup_message2, result.message_confirm_bet)
        assertEqual(testdata.popupwindow3, result.message_bet_success)

        # part2: 检查投注记录
        self.page_bet_record = self.page_method.gotoBetRecordPage()
        result = self.page_bet_record.search(str_bet_time)
        # 投注记录断言
        assertEqual(testdata.methodid, result.method)
        assertEqual(float(testdata.each_money), float(result.each_money))
        assertEqual(float(testdata.bet_money), float(result.bet_money))

        # part3: 检查交易记录
        self.page_bet_record.gotoDealDetail()
        self.page_deal_detail = DealDetailPage(self.page_bet_record.getDriver())
        result = self.page_deal_detail.search(str_bet_time)
        # 交易记录断言
        assertEqual(testdata.income_and_expenses, result.income_and_expense)
        assertEqual(testdata.deal_type, result.deal_type)
        assertEqual(float(testdata.deal_money), float(result.deal_money))

        # 回到购彩大厅页面
        self.page_deal_detail.close_current_window()
        self.page_method.switch_to_window(1)
        self.page_method.close_current_window()
        self.page_home.switch_to_window(0)
        self.page_gcdt = self.page_home.gotoGcdtPage()

    def filt(self, model, model1, model2, caseID, caseData):
        """
        测试场景：自动过滤重复的投注号码。
        :param model: 彩种，例如北京pk拾。
        :param model1: 大玩法，例如前一。
        :param model2: 小玩法，例如直选复式。
        :param caseID: 测试数据ID，在Excel中。
        :param caseData: 测试数据，在Excel中。
        :return: 
        """
        dic_original_data = {
            "model": model,
            "model1": model1,
            "model2": model2,
            "caseID": caseID,
            "caseData": caseData
        }
        testdata = TestData(dic_original_data)

        # part1: 投注
        self.page_method = self._goto_method_page(testdata.model, testdata.model1, testdata.model2)
        result = self.page_method.filt(testdata)
        str_bet_time = self.page_method.getBetTime()

        # 更新期待的弹窗信息
        str_popup_message2 = update(testdata.popupwindow2, self.page_method.get_issue())

        # 弹窗消息断言
        assertEqual(testdata.popupwindow1, result.message_auto_filer)
        assertEqual(str_popup_message2, result.message_confirm_bet)
        assertEqual(testdata.popupwindow3, result.message_bet_success)

        # part2: 检查投注记录
        self.page_bet_record = self.page_method.gotoBetRecordPage()
        result = self.page_bet_record.search(str_bet_time)
        # 投注记录断言
        assertEqual(testdata.methodid, result.method)
        assertEqual(float(testdata.each_money), float(result.each_money))
        assertEqual(float(testdata.bet_money), float(result.bet_money))

        # part3: 检查交易记录
        self.page_bet_record.gotoDealDetail()
        self.page_deal_detail = DealDetailPage(self.page_bet_record.getDriver())
        result = self.page_deal_detail.search(str_bet_time)
        # 交易记录断言
        assertEqual(testdata.income_and_expenses, result.income_and_expense)
        assertEqual(testdata.deal_type, result.deal_type)
        assertEqual(float(testdata.deal_money), float(result.deal_money))

        # 回到购彩大厅页面
        self.page_deal_detail.close_current_window()
        self.page_method.switch_to_window(1)
        self.page_method.close_current_window()
        self.page_home.switch_to_window(0)
        self.page_gcdt = self.page_home.gotoGcdtPage()

    def upload_then_empty(self, model, model1, model2, caseID, caseData):
        """
        测试场景：上传文件，然后清空投注号码。
        :param model: 彩种，例如北京pk拾。
        :param model1: 大玩法，例如前一。
        :param model2: 小玩法，例如直选复式。
        :param caseID: 测试数据ID，在Excel中。
        :param caseData: 测试数据，在Excel中。
        :return: 
        """
        dic_original_data = {
            "model": model,
            "model1": model1,
            "model2": model2,
            "caseID": caseID,
            "caseData": caseData
        }
        testdata = TestData(dic_original_data)

        # part1: 投注
        self.page_method = self._goto_method_page(testdata.model, testdata.model1, testdata.model2)
        str_file_path = DefaultConfig().data_web_path
        str_file = os.path.abspath(os.path.join(str_file_path, testdata.codes))
        if os.path.isfile(str_file):
            str_actual_popup_message = self.page_method.upload_then_empty(str_file)
        else:
            raise IOError("\nFile: %s not exist!" % str_file)
        assertEqual(testdata.popupwindow3, str_actual_popup_message)

        # 回到购彩大厅页面
        self.page_method.close_current_window()
        self.page_home.switch_to_window(0)
        self.page_gcdt = self.page_home.gotoGcdtPage()

    def upload_wrong_codes(self, model, model1, model2, caseID, caseData):
        """
        测试场景：通过上传文件进行下注，但文件中的号码错误。
        :param model: 彩种，例如北京pk拾。
        :param model1: 大玩法，例如前一。
        :param model2: 小玩法，例如直选复式。
        :param caseID: 测试数据ID，在Excel中。
        :param caseData: 测试数据，在Excel中。
        :return: 
        """
        dic_original_data = {
            "model": model,
            "model1": model1,
            "model2": model2,
            "caseID": caseID,
            "caseData": caseData
        }
        testdata = TestData(dic_original_data)

        # part1: 投注
        self.page_method = self._goto_method_page(testdata.model, testdata.model1, testdata.model2)
        str_file_path = DefaultConfig().data_web_path
        str_file = os.path.abspath(os.path.join(str_file_path, testdata.codes))
        if os.path.isfile(str_file):
            dic_result = self.page_method.upload_wrong_codes(str_file)
        else:
            raise IOError("\nFile: %s not exist!" % str_file)
        assertEqual(testdata.popupwindow2, dic_result["popup_message1"])
        assertEqual(testdata.popupwindow3, dic_result["popup_message2"])

        # 回到购彩大厅页面
        self.page_method.close_current_window()
        self.page_home.switch_to_window(0)
        self.page_gcdt = self.page_home.gotoGcdtPage()

