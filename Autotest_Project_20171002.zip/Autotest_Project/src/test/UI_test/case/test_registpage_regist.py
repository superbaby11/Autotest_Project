#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/5/27 13:32
# @Author  : Terry

import pytest

from src.test.UI_test.page.HomePage import HomePage
from src.utils.getdb import db_sqlserver_connect, sql_query_dict, sql_update, db_mysql_connect, unicode_dict,sql_query


class TestRegistPageRegist(object):
    # @classmethod
    # def setup_class(cls):
    #     cls.page_home = HomePage()
    #     cls.page_regist = cls.page_home.gotoRegistPage()
    #
    # @classmethod
    # def teardown_class(cls):
    #     cls.page_regist.quit()
    def setup_method(self):
        self.page_home = HomePage()
        self.page_regist = self.page_home.gotoRegistPage()

    def teardown_method(self):
        self.page_regist.quit()

    @staticmethod
    def check_user_exist(str_acc):
        """
        检查数据库中是否存在参数str_acc指定的用户。
        :param str_acc: 登录后，页面显示的用户名。
        :return: 若用户存在，则返回True；否则返回False。
        """
        str_sql_check_exist = u"SELECT * from tuser WHERE sUserid = '%s'" % str_acc
        lis_res = sql_query_dict(db_sqlserver_connect(), str_sql_check_exist)
        if 0 == len(lis_res):
            return False
        else:
            return True

    def clean_user(self, str_acc):
        """
        若用户已存在，则从数据库中删除该用户。
        :param str_acc: 登录后，显示的用户名。
        :return: 无返回值。
        """
        if self.check_user_exist(str_acc):
            str_sql_clean = u"DELETE from tuser WHERE sUserid = '%s'" % str_acc
            sql_update(db_sqlserver_connect(), str_sql_clean)

    str_sql = "select caseID, caseData from web_autotest_case where" \
              " caseID like 'CP_WEB_USER_REGISTER%' AND normal = 'Y';"

    @pytest.mark.parametrize("caseID,caseData", sql_query(db_mysql_connect(), str_sql))
    def test_registpage_normal_regist(self, caseID, caseData):
        """
        测试注册页面【正常】注册流程
        :return: 无返回值。
        """
        dic_test_data = unicode_dict(caseData)
        str_username = unicode(dic_test_data["reg_username"])
        str_password = unicode(dic_test_data["reg_pwd"])
        str_confirmed_password = unicode(dic_test_data["cfm_pwd"])
        str_expected_acc = unicode(dic_test_data["acc"])
        self.clean_user(str_expected_acc)
        str_actual_acc = self.page_regist.registNormal(str_username, str_password, str_confirmed_password)
        assert str_expected_acc == str_actual_acc
        self.clean_user(str_expected_acc)
        self.page_regist.logout()
        self.page_regist = self.page_home.gotoRegistPage()

    str_sql = "select caseID, caseData from web_autotest_case where" \
              " caseID like 'CP_WEB_USER_REGISTER%' AND normal = 'N';"

    @pytest.mark.parametrize("caseID,caseData", sql_query(db_mysql_connect(), str_sql))
    def test_registpage_abnormal_regist(self, caseID, caseData):
        """
        测试注册页面【异常】注册流程
        :param caseID: 
        :param caseData: 
        :return: 
        """
        dic_test_data = unicode_dict(caseData)
        str_username = unicode(dic_test_data["reg_username"])
        str_password = unicode(dic_test_data["reg_pwd"])
        str_confirmed_password = unicode(dic_test_data["cfm_pwd"])
        str_expected_pop_message = unicode(dic_test_data["popupmessage"], "utf-8")
        str_actual_pop_message = self.page_regist.registAbnormal(str_username, str_password, str_confirmed_password)
        assert str_expected_pop_message == str_actual_pop_message

if __name__ == '__main__':
    args = ['test_registpage_regist.py']
    pytest.main(args)
