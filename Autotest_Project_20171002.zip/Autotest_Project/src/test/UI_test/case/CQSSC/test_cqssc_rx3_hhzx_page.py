#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/6/22 11:48
# @Author  : Terry
import pytest

from src.test.UI_test.case.TestBase import TestBase
from src.test.UI_test.page.HomePage import HomePage
from src.utils.config import DefaultConfig_Project
from src.utils.getdb import sql_query, db_mysql_connect


class Test_CQSSC_RX3_HHZX_Page(TestBase):
    # @classmethod
    # def setup_class(cls):
    #     cls.page_home = HomePage()
    #     cls.page_gcdt = cls.page_home.gotoGcdtPage()
    #     # 用户登录
    #     str_username = DefaultConfig_Project().user_name
    #     str_password = DefaultConfig_Project().pass_word
    #     str_authnum = DefaultConfig_Project().auth_num
    #     cls.page_gcdt.loginNormal(str_username, str_password, str_authnum)
    #
    # @classmethod
    # def teardown_class(cls):
    #     cls.page_gcdt.quit()
    def setup_method(self):
        self.page_home = HomePage()
        self.page_gcdt = self.page_home.gotoGcdtPage()
        # 用户登录
        str_username = DefaultConfig_Project().user_name
        str_password = DefaultConfig_Project().pass_word
        str_authnum = DefaultConfig_Project().auth_num
        self.page_gcdt.loginNormal(str_username, str_password, str_authnum)

    def teardown_method(self):
        self.page_gcdt.quit()

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_CQSSC_RX3_HHZX_%' and normal = 'Y' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_cqssc_rx3_hhzx_normal(self, model, model1, model2, caseID, caseData):
        """
        测试正常投注流程。
        :return:
        """
        self.normal(model, model1, model2, caseID, caseData)

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_CQSSC_RX3_HHZX_6' and normal = 'N' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_cqssc_rx3_hhzx_clean_all(self, model, model1, model2, caseID, caseData):
        """
        投注后，不点击'确认投注'，点击'删除全部'。
        """
        self.clean_all(model, model1, model2, caseID, caseData)

if __name__ == '__main__':
    # args = ['test_cqssc_rx3_hhzx_page.py::Test_CQSSC_RX3_HHZX_Page::test_cqssc_rx3_hhzx_normal']
    # args = ['test_cqssc_rx3_hhzx_page.py::Test_CQSSC_RX3_HHZX_Page::test_cqssc_rx3_hhzx_clean_all']
    args = ['test_cqssc_rx3_hhzx_page.py::Test_CQSSC_RX3_HHZX_Page']
    pytest.main(args)
