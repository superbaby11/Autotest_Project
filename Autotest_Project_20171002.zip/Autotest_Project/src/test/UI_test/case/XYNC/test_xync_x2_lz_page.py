#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/8/18 14:29
# @Author  : Terry
import pytest

from src.test.UI_test.case.TestBase import TestBase
from src.test.UI_test.page.HomePage import HomePage
from src.utils.config import DefaultConfig_Project
from src.utils.getdb import sql_query, db_mysql_connect


class Test_XYNC_X2_LZ_Page(TestBase):
    def setup_method(self):
        self.page_home = HomePage()
        self.page_gcdt = self.page_home.gotoGcdtPage()
        # 用户登录
        str_username = DefaultConfig_Project().user_name
        str_password = DefaultConfig_Project().pass_word
        str_authnum = DefaultConfig_Project().auth_num
        self.page_gcdt.loginNormal(str_username, str_password, str_authnum)

    def teardown_method(self):
        self.page_gcdt.quit()

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_XYNC_X2_LZ\_%' and normal = 'Y' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_xync_x2_lz_normal(self, model, model1, model2, caseID, caseData):
        """
        测试正常投注流程。
        :return: 
        """
        self.normal(model, model1, model2, caseID, caseData)

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_XYNC_X2_LZ\_8' and normal = 'N' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_xync_x2_lz_insufficient(self, model, model1, model2, caseID, caseData):
        """
        玩家投注时，余额不足。
        :param model: 彩种，例如北京pk拾。
        :param model1: 大玩法，例如前一。
        :param model2: 小玩法，例如直选复式。
        :param caseID: 测试数据ID，在Excel中。
        :param caseData: 测试数据，在Excel中。
        :return: 
        """
        self.insufficient(model, model1, model2, caseID, caseData)

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_XYNC_X2_LZ\_9' and normal = 'N' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_xync_x2_lz_clean_all(self, model, model1, model2, caseID, caseData):
        """
        玩家投注后，清除号码。
        :param model: 彩种，例如北京pk拾。
        :param model1: 大玩法，例如前一。
        :param model2: 小玩法，例如直选复式。
        :param caseID: 测试数据ID，在Excel中。
        :param caseData: 测试数据，在Excel中。
        :return: 
        """
        self.clean_all(model, model1, model2, caseID, caseData)

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_XYNC_X2_LZ\_10' and normal = 'N' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_xync_x2_lz_change_normal_to_random(self, model, model1, model2, caseID, caseData):
        """
        选择一个号码，不点击‘添加注单’，点击‘随机一注’。
        :param model: 
        :param model1: 
        :param model2: 
        :param caseID: 
        :param caseData: 
        :return: 
        """
        self.change_normal_to_random(model, model1, model2, caseID, caseData)

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_XYNC_X2_LZ\_11' and normal = 'N' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_xync_x2_lz_add_empty(self, model, model1, model2, caseID, caseData):
        """
        没有选择投注号码，添加注单。
        :param model: 彩种，例如北京pk拾。
        :param model1: 大玩法，例如前一。
        :param model2: 小玩法，例如直选复式。
        :param caseID: 测试数据ID，在Excel中。
        :param caseData: 测试数据，在Excel中。
        :return: 
        """
        self.add_empty(model, model1, model2, caseID, caseData)

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_XYNC_X2_LZ\_12' and normal = 'N' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_xync_x2_lz_buy_empty(self, model, model1, model2, caseID, caseData):
        """
        没有选择投注号码，确认投注。
        :param model: 彩种，例如北京pk拾。
        :param model1: 大玩法，例如前一。
        :param model2: 小玩法，例如直选复式。
        :param caseID: 测试数据ID，在Excel中。
        :param caseData: 测试数据，在Excel中。
        :return: 
        """
        self.buy_empty(model, model1, model2, caseID, caseData)

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_XYNC_X2_LZ\_13' and normal = 'N' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_xync_x2_lz_wrong_money(self, model, model1, model2, caseID, caseData):
        """
        投注时，输入错误的单注额，比如0元每注。
        :param model: 彩种，例如北京pk拾。
        :param model1: 大玩法，例如前一。
        :param model2: 小玩法，例如直选复式。
        :param caseID: 测试数据ID，在Excel中。
        :param caseData: 测试数据，在Excel中。
        :return: 
        """
        self.wrong_money(model, model1, model2, caseID, caseData)


if __name__ == "__main__":
    # args = ['test_xync_x2_lz_page.py::Test_XYNC_X2_LZ_Page::test_xync_x2_lz_normal']
    # args = ['test_xync_x2_lz_page.py::Test_XYNC_X2_LZ_Page::test_xync_x2_lz_insufficient']
    # args = ['test_xync_x2_lz_page.py::Test_XYNC_X2_LZ_Page::test_xync_x2_lz_clean_all']
    # args = ['test_xync_x2_lz_page.py::Test_XYNC_X2_LZ_Page::test_xync_x2_lz_change_normal_to_random']
    # args = ['test_xync_x2_lz_page.py::Test_XYNC_X2_LZ_Page::test_xync_x2_lz_add_empty']
    # args = ['test_xync_x2_lz_page.py::Test_XYNC_X2_LZ_Page::test_xync_x2_lz_buy_empty']
    # args = ['test_xync_x2_lz_page.py::Test_XYNC_X2_LZ_Page::test_xync_x2_lz_wrong_money']
    args = ['test_xync_x2_lz_page.py']
    pytest.main(args)
