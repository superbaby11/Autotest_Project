#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/6/10 9:31
# @Author  : Terry
import pytest

from src.test.UI_test.case.TestBase import TestBase
from src.test.UI_test.page.HomePage import HomePage
from src.utils.config import DefaultConfig_Project
from src.utils.getdb import sql_query, db_mysql_connect


class Test_PK10_Q2_ZXDS_Page(TestBase):
    # @classmethod
    # def setup_class(cls):
    #     cls.page_home = HomePage()
    #     cls.page_gcdt = cls.page_home.gotoGcdtPage()
    #     # 用户登录
    #     str_username = DefaultConfig_Project().user_name
    #     str_password = DefaultConfig_Project().pass_word
    #     str_authnum = DefaultConfig_Project().auth_num
    #     cls.page_gcdt.loginNormal(str_username, str_password, str_authnum)
    #
    # @classmethod
    # def teardown_class(cls):
    #     cls.page_gcdt.quit()

    def setup_method(self):
        self.page_home = HomePage()
        self.page_gcdt = self.page_home.gotoGcdtPage()
        # 用户登录
        str_username = DefaultConfig_Project().user_name
        str_password = DefaultConfig_Project().pass_word
        str_authnum = DefaultConfig_Project().auth_num
        self.page_gcdt.loginNormal(str_username, str_password, str_authnum)

    def teardown_method(self):
        self.page_gcdt.quit()

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_PK10_Q2_ZXDS_%' and normal = 'Y' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_pk10_q2_zxds_normal(self, model, model1, model2, caseID, caseData):
        """
        测试直选单式的正常投注流程。
        """
        self.normal(model, model1, model2, caseID, caseData)

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_PK10_Q2_ZXDS_2' and normal = 'duplication' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_pk10_q2_zxds_remove_duplication(self, model, model1, model2, caseID, caseData):
        """
        测试删除重复号的流程。
        """
        self.remove_duplication(model, model1, model2, caseID, caseData)

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_PK10_Q2_ZXDS_3' and normal = 'filter' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_pk10_q2_zxds_auto_filter(self, model, model1, model2, caseID, caseData):
        """
        测试自动过滤重复号码的流程。
        :return: 
        """
        self.filt(model, model1, model2, caseID, caseData)

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_PK10_Q2_ZXDS_9' and normal = 'N' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_pk10_q2_zxds_upload_then_empty(self, model, model1, model2, caseID, caseData):
        """
        测试上传文件然后清空投注号码的流程。
        """
        self.upload_then_empty(model, model1, model2, caseID, caseData)

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_PK10_Q2_ZXDS_10' and normal = 'N' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_pk10_q2_zxds_insufficient(self, model, model1, model2, caseID, caseData):
        """
        测试玩家投注时余额不足的场景。
        """
        self.insufficient(model, model1, model2, caseID, caseData)

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_PK10_Q2_ZXDS_12' and normal = 'N' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_pk10_q2_zxds_clean_all(self, model, model1, model2, caseID, caseData):
        """
        测试情景：添加注单后，删除全部注单。
        """
        self.clean_all(model, model1, model2, caseID, caseData)

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_PK10_Q2_ZXDS_13' and normal = 'N' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_pk10_q2_zxds_clean_one(self, model, model1, model2, caseID, caseData):
        """
        测试情景：添加注单后，删除一个注单。
        """
        self.clean_one(model, model1, model2, caseID, caseData)

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_PK10_Q2_ZXDS_14' and normal = 'N' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_pk10_q2_zxds_change_normal_to_random(self, model, model1, model2, caseID, caseData):
        """
        直选单式，选择一个号码，不点击‘添加注单’，点击‘随机一注’。
        """
        self.change_normal_to_random(model, model1, model2, caseID, caseData)

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_PK10_Q2_ZXDS_%' and normal = 'wrong_codes' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_pk10_q2_zxds_wrong_codes(self, model, model1, model2, caseID, caseData):
        """
        测试情景：玩家输入错误的投注号码。
        """
        self.wrong_codes(model, model1, model2, caseID, caseData)

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_PK10_Q2_ZXDS_18' and normal = 'N' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_pk10_q2_zxds_buy_empty(self, model, model1, model2, caseID, caseData):
        """
        测试情景：没有选择投注号码，添加注单。
        """
        self.buy_empty(model, model1, model2, caseID, caseData)

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_PK10_Q2_ZXDS_19' and normal = 'N' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_pk10_q2_zxds_wrong_money(self, model, model1, model2, caseID, caseData):
        """
        测试情景：单注金额错误.
        """
        self.wrong_money(model, model1, model2, caseID, caseData)

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_PK10_Q2_ZXDS_20' and normal = 'N' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_pk10_q2_zxds_upload_wrong_codes(self, model, model1, model2, caseID, caseData):
        """
        测试情景：通过上传文件进行下注，但文件中的号码错误。
        """
        self.upload_wrong_codes(model, model1, model2, caseID, caseData)


if __name__ == '__main__':
    # args = ['test_pk10_q2_zxds_page.py::Test_PK10_Q2_ZXDS_Page::test_pk10_q2_zxds_normal', '-qs']
    # args = ['test_pk10_q2_zxds_page.py::Test_PK10_Q2_ZXDS_Page::test_pk10_q2_zxds_remove_duplication', '-qs']
    # args = ['test_pk10_q2_zxds_page.py::Test_PK10_Q2_ZXDS_Page::test_pk10_q2_zxds_auto_filter', '-qs']
    # args = ['test_pk10_q2_zxds_page.py::Test_PK10_Q2_ZXDS_Page::test_pk10_q2_zxds_upload_then_empty', '-qs']
    # args = ['test_pk10_q2_zxds_page.py::Test_PK10_Q2_ZXDS_Page::test_pk10_q2_zxds_insufficient', '-qs']
    # args = ['test_pk10_q2_zxds_page.py::Test_PK10_Q2_ZXDS_Page::test_pk10_q2_zxds_change_normal_to_random', '-qs']
    # args = ['test_pk10_q2_zxds_page.py::Test_PK10_Q2_ZXDS_Page::test_pk10_q2_zxds_clean_all', '-qs']
    # args = ['test_pk10_q2_zxds_page.py::Test_PK10_Q2_ZXDS_Page::test_pk10_q2_zxds_clean_one', '-qs']
    # args = ['test_pk10_q2_zxds_page.py::Test_PK10_Q2_ZXDS_Page::test_pk10_q2_zxds_wrong_codes', '-qs']
    # args = ['test_pk10_q2_zxds_page.py::Test_PK10_Q2_ZXDS_Page::test_pk10_q2_zxds_buy_empty', '-qs']
    # args = ['test_pk10_q2_zxds_page.py::Test_PK10_Q2_ZXDS_Page::test_pk10_q2_zxds_wrong_money', '-qs']
    # args = ['test_pk10_q2_zxds_page.py::Test_PK10_Q2_ZXDS_Page::test_pk10_q2_zxds_upload_wrong_codes', '-qs']
    args = ['-k Test_PK10_Q2_ZXDS_Page and not test_pk10_q2_zxds_auto_filter', '-qs']
    pytest.main(args)
