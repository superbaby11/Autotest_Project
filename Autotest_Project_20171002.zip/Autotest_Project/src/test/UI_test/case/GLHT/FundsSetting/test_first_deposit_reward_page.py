#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/7/15 11:57
# @Author  : Terry
import pytest

from src.test.UI_test.case.Manage.Deposit.deposit_base import Deposit_Base
from src.test.UI_test.common.common import TestData, DataBase
from src.test.UI_test.page.GLHT.GlhtLoginPage import GlhtLoginPage
from src.test.UI_test.page.HomePage import HomePage
from src.utils.assert_extra import assertEqual
from src.utils.config import DefaultConfig_Project
from src.utils.getdb import sql_query, db_mysql_connect


class Test_First_Deposit_Reward_Page(Deposit_Base):
    """
    充值时，首先判断是否满足首存优惠条件，若满足，则执行首存优惠；
    若不满足首存优惠条件，则判断是否满足每次充值优惠条件，若满足，则执行每次充值优惠；
    若不满足，则不再进行判断。
    因此，首存优惠的测试脚本要继承Deposit_Base类，该类中的setup_class用于设置每次充值优惠。
    """
    page_home = None
    page_rgct_deposit = None

    def setup_method(self):
        # 前台的地址、用户名和密码
        self.url = DefaultConfig_Project().base_url
        self.str_username = DefaultConfig_Project().user_name
        self.str_password = DefaultConfig_Project().pass_word

        # 清除玩家的充值数据，用于测试首存优惠
        DataBase().delete_deposit_data(self.str_username)

        # 登录管理后台，并跳转到出入款设定页面
        back_url = DefaultConfig_Project().get("url", "back_url")
        self.page_glht_login = GlhtLoginPage()
        self.page_glht_login.open(back_url)
        self.page_glht_home = self.page_glht_login.loginNormal()

    def teardown_method(self):
        try:
            self.page_glht_home.glhtLogout()
        except:
            pass
        self.page_glht_home.quit()

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_FUNDS_SETTING_FIRST_%' and normal = 'bank' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_first_deposit_reward_bank(self, model, model1, model2, caseID, caseData):
        """
        测试场景：出入款设定-->首存优惠设定后，进行银行入款。
        :return: 
        """
        dic_original_data = {
            "model": model,
            "model1": model1,
            "model2": model2,
            "caseID": caseID,
            "caseData": caseData
        }
        testdata = TestData(dic_original_data)
        testdata.username = self.str_username

        # 管理后台的出入款设定-->首存优惠设定
        self.page_funds_setting = self.page_glht_home.gotoFundsSettingPage()
        result = self.page_funds_setting.first_deposit_setting(testdata)
        self.page_funds_setting.glhtLogout()
        assertEqual(testdata.popupwindow1, result.message_funds_setting_commit)

        # 前台银行入款充值页面
        self.page_funds_setting.open(self.url)
        self.page_home = HomePage(self.page_funds_setting.getDriver())
        self.page_home.loginNormal(self.str_username, self.str_password)
        self.page_deposit = self.page_home.gotoDepositPage().bank()
        result = self.page_deposit.deposit(testdata)
        self.page_deposit.close_current_window()
        self.page_deposit.switch_to_window(0)
        self.page_home.logout()
        assertEqual(testdata.popupwindow2, result.message_deposit_info)

        # 管理后台，入款审核
        self.page_glht_login = self.page_home.gotoGlhtPage()
        self.page_glht_home = self.page_glht_login.loginNormal()
        self.page_glht_deposit = self.page_glht_home.gotoDepositPage().company()
        str_order_number = result.order_number
        result = self.page_glht_deposit.search(str_order_number)
        self.page_glht_deposit.glhtLogout()
        self.page_glht_deposit.close_current_window()
        self.page_glht_deposit.switch_to_window(0)
        str_deal_time = result.deal_time
        assertEqual(testdata.dmoney, result.dmoney)
        if testdata.has_reward:
            assertEqual(testdata.reward, result.first_reward)
        else:
            assertEqual(None, result.first_reward)
        assertEqual(testdata.popupwindow3, result.message_deposit_lock)
        assertEqual(testdata.popupwindow4, result.message_deposit_confirm)

        # 充值记录页面
        self.page_glht_deposit.open(self.url)
        self.page_home = HomePage(self.page_glht_deposit.getDriver())
        self.page_home.loginNormal(self.str_username, self.str_password)
        self.page_deal_record = self.page_home.gotoDealRecordPage()
        self.page_deposit_record = self.page_deal_record.gotoRepositRecord()
        result = self.page_deposit_record.search()
        assertEqual(testdata.deal_type, result.deal_type)
        assertEqual(float(testdata.dmoney), float(result.deal_money))
        assertEqual(testdata.deposit_status, result.deposit_status)

        # 交易记录页面
        self.page_deal_detail = self.page_deal_record.gotoDealDetail()
        result = self.page_deal_detail.search(str_deal_time)
        assertEqual(testdata.deal_type, result.deal_type)
        assertEqual(float(testdata.dmoney), float(result.deal_money))
        assertEqual(testdata.income_and_expenses, result.income_and_expense)
        if testdata.has_reward:  # 验证优惠信息
            assertEqual(float(testdata.reward), float(result.reward))
        else:
            assertEqual(None, result.reward)

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_FUNDS_SETTING_FIRST_%' and normal = 'wechat' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_first_deposit_reward_wechat(self, model, model1, model2, caseID, caseData):
        """
        测试场景：出入款设定-->首存优惠设定后，进行微信入款。
        """
        dic_original_data = {
            "model": model,
            "model1": model1,
            "model2": model2,
            "caseID": caseID,
            "caseData": caseData
        }
        testdata = TestData(dic_original_data)
        testdata.username = self.str_username

        # 管理后台的出入款设定-->首存优惠设定
        self.page_funds_setting = self.page_glht_home.gotoFundsSettingPage()
        result = self.page_funds_setting.first_deposit_setting(testdata)
        self.page_funds_setting.glhtLogout()
        assertEqual(testdata.popupwindow1, result.message_funds_setting_commit)

        # 前台微信入款
        self.page_funds_setting.open(self.url)
        self.page_home = HomePage(self.page_funds_setting.getDriver())
        self.page_home.loginNormal(self.str_username, self.str_password)
        self.page_deposit = self.page_home.gotoDepositPage().wechat()
        result = self.page_deposit.deposit(testdata)
        self.page_deposit.close_current_window()
        self.page_deposit.switch_to_window(0)
        self.page_home.logout()
        assertEqual(testdata.popupwindow2, result.message_deposit_info)

        # 管理后台，入款管理
        self.page_glht = self.page_home.gotoGlhtPage()
        self.page_glht_home = self.page_glht.loginNormal()
        self.page_glht_deposit = self.page_glht_home.gotoDepositPage().wechat()
        result = self.page_glht_deposit.search(self.str_username)
        self.page_glht_deposit.glhtLogout()
        self.page_glht_deposit.close_current_window()
        self.page_home.switch_to_window(0)
        str_order_number = result.order_number
        str_deal_time = result.deal_time
        assertEqual(testdata.dmoney, result.dmoney)
        if testdata.has_reward:
            assertEqual(testdata.reward, result.first_reward)
        else:
            assertEqual(None, result.first_reward)
        assertEqual(testdata.popupwindow3, result.message_deposit_lock)
        assertEqual(testdata.popupwindow4, result.message_deposit_confirm)

        # 前台充值记录页面，验证充值信息
        self.page_home.open()
        self.page_home.loginNormal(self.str_username, self.str_password)
        self.page_deal_record = self.page_home.gotoDealRecordPage()
        self.page_deposit_record = self.page_deal_record.gotoRepositRecord()
        result = self.page_deposit_record.search(str_order_number)
        assertEqual(testdata.deal_type, result.deal_type)
        assertEqual(float(testdata.deal_money), float(result.deal_money))
        assertEqual(testdata.deposit_status, result.deposit_status)

        # 前台交易记录页面
        self.page_deal_detail = self.page_deal_record.gotoDealDetail()
        result = self.page_deal_detail.search(str_deal_time)
        assertEqual(float(testdata.deal_money), float(result.deal_money))
        assertEqual(testdata.deal_type, result.deal_type)
        if testdata.has_reward:  # 验证优惠信息
            assertEqual(float(testdata.reward), float(result.reward))
        else:
            assertEqual(None, result.reward)

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_FUNDS_SETTING_FIRST_%' and normal = 'alipay' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_first_deposit_reward_alipay(self, model, model1, model2, caseID, caseData):
        """
        测试场景：出入款设定-->首存优惠设定后，进行支付宝入款。
        """
        dic_original_data = {
            "model": model,
            "model1": model1,
            "model2": model2,
            "caseID": caseID,
            "caseData": caseData
        }
        testdata = TestData(dic_original_data)
        testdata.username = self.str_username

        # 管理后台的出入款设定-->首存优惠设定
        self.page_funds_setting = self.page_glht_home.gotoFundsSettingPage()
        result = self.page_funds_setting.first_deposit_setting(testdata)
        self.page_funds_setting.glhtLogout()
        assertEqual(testdata.popupwindow1, result.message_funds_setting_commit)

        # 前台支付宝入款
        self.page_funds_setting.open(self.url)
        self.page_home = HomePage(self.page_funds_setting.getDriver())
        self.page_home.loginNormal(self.str_username, self.str_password)
        self.page_deposit = self.page_home.gotoDepositPage().alipay()
        result = self.page_deposit.deposit(testdata)
        self.page_deposit.close_current_window()
        self.page_deposit.switch_to_window(0)
        self.page_home.logout()
        assertEqual(testdata.popupwindow2, result.message_deposit_info)

        # 管理后台页面，确认充值
        self.page_glht = self.page_home.gotoGlhtPage()
        self.page_glht_home = self.page_glht.loginNormal()
        self.page_glht_deposit = self.page_glht_home.gotoDepositPage().alipay()
        result = self.page_glht_deposit.search(self.str_username)
        self.page_glht_deposit.glhtLogout()
        self.page_glht_deposit.close_current_window()
        self.page_home.switch_to_window(0)
        str_order_number = result.order_number
        str_deal_time = result.deal_time
        assertEqual(testdata.dmoney, result.dmoney)
        if testdata.has_reward:
            assertEqual(testdata.reward, result.first_reward)
        else:
            assertEqual(None, result.first_reward)
        assertEqual(testdata.popupwindow3, result.message_deposit_lock)
        assertEqual(testdata.popupwindow4, result.message_deposit_confirm)

        # 前台充值记录页面，验证充值信息
        self.page_home.open()
        self.page_home.loginNormal(self.str_username, self.str_password)
        self.page_deal_record = self.page_home.gotoDealRecordPage()
        self.page_deposit_record = self.page_deal_record.gotoRepositRecord()
        result = self.page_deposit_record.search(str_order_number)
        assertEqual(testdata.deal_type, result.deal_type)
        assertEqual(float(testdata.deal_money), float(result.deal_money))
        assertEqual(testdata.deposit_status, result.deposit_status)

        # 前台交易记录页面
        self.page_deal_detail = self.page_deal_record.gotoDealDetail()
        result = self.page_deal_detail.search(str_deal_time)
        assertEqual(float(testdata.deal_money), float(result.deal_money))
        assertEqual(testdata.deal_type, result.deal_type)
        if testdata.has_reward:  # 验证优惠信息
            assertEqual(float(testdata.reward), float(result.reward))
        else:
            assertEqual(None, result.reward)

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_FUNDS_SETTING_FIRST_%' and normal = 'wrong_money' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_first_deposit_wrong_money(self, model, model1, model2, caseID, caseData):
        """
        测试场景：出入款设定-->首存优惠设定,输入优惠标准小数点大于3位数。
        """
        dic_original_data = {
            "model": model,
            "model1": model1,
            "model2": model2,
            "caseID": caseID,
            "caseData": caseData
        }
        testdata = TestData(dic_original_data)
        testdata.username = self.str_username

        # 管理后台的出入款设定-->首存优惠设定
        self.page_funds_setting = self.page_glht_home.gotoFundsSettingPage()
        result = self.page_funds_setting.first_deposit_setting(testdata)
        self.page_funds_setting.glhtLogout()
        assertEqual(testdata.popupwindow1, result.message_funds_setting_commit)


if __name__ == '__main__':
    # args = ["test_first_deposit_reward_page.py::Test_First_Deposit_Reward_Page::test_first_deposit_reward_bank"]
    # args = ["test_first_deposit_reward_page.py::Test_First_Deposit_Reward_Page::test_first_deposit_reward_wechat"]
    # args = ["test_first_deposit_reward_page.py::Test_First_Deposit_Reward_Page::test_first_deposit_reward_alipay"]
    # args = ["test_first_deposit_reward_page.py::Test_First_Deposit_Reward_Page::test_first_deposit_wrong_money"]
    args = ["test_first_deposit_reward_page.py::Test_First_Deposit_Reward_Page"]
    pytest.main(args)
