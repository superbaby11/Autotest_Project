#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/7/11 11:25
# @Author  : Terry
import pytest

from src.test.UI_test.common.common import TestData
from src.test.UI_test.page.GLHT.GlhtLoginPage import GlhtLoginPage
from src.test.UI_test.page.HomePage import HomePage
from src.utils.assert_extra import assertEqual
from src.utils.config import DefaultConfig_Project
from src.utils.getdb import sql_query, db_mysql_connect


class TestRgctWithdrawPage(object):
    page_home = None
    page_rgct_deposit = None

    def setup_method(self):
        # 前台的地址、用户名和密码
        self.url = DefaultConfig_Project().base_url
        self.str_username = DefaultConfig_Project().user_name
        self.str_password = DefaultConfig_Project().pass_word
        self.str_authnum = DefaultConfig_Project().auth_num
        # 登录管理后台，并跳转到人工存提页面
        back_url = DefaultConfig_Project().get("url", "back_url")
        str_username_back = DefaultConfig_Project().get("users", "username_back")
        str_password_back = DefaultConfig_Project().get("users", "password_back")
        self.page_glht_login = GlhtLoginPage()
        self.page_glht_login.open(back_url)
        self.page_glht_home = self.page_glht_login.loginNormal(str_username_back, str_password_back)

    def teardown_method(self):
        try:
            self.page_glht_home.glhtLogout()
        except:
            pass
        self.page_glht_home.quit()

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_RGCT_WITHDRAW_%' and normal = 'Y' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_rgct_withdraw_normal(self, model, model1, model2, caseID, caseData):
        """
        测试场景：人工线上存提-->人工提出，正常提出流程。
        :return: 
        """
        dic_original_data = {
            "model": model,
            "model1": model1,
            "model2": model2,
            "caseID": caseID,
            "caseData": caseData
        }
        testdata = TestData(dic_original_data)
        testdata.username = self.str_username

        # 管理后台的人工线上存提-->人工提出
        self.page_rgct_withdraw = self.page_glht_home.gotoRgctPage().gotoWithdraw()
        result = self.page_rgct_withdraw.withdraw(testdata)
        assertEqual(testdata.popupwindow1, result.message_rgct_commit)
        assertEqual(testdata.popupwindow2, result.message_rgct_confirm)
        self.page_rgct_withdraw.glhtLogout()

        # 提款记录页面
        self.page_rgct_withdraw.open(self.url)
        self.page_home = HomePage(self.page_rgct_withdraw.getDriver())
        self.page_home.loginNormal(self.str_username, self.str_password)
        self.page_deal_record = self.page_home.gotoDealRecordPage()
        self.page_withdraw_record = self.page_deal_record.gotoWithdraw()
        result = self.page_withdraw_record.search()
        assertEqual(float(testdata.wmoney), float(result.deal_money))
        assertEqual(testdata.withdraw_status, result.withdraw_status)

        # 交易记录页面
        self.page_deal_detail = self.page_deal_record.gotoDealDetail()
        result = self.page_deal_detail.search()
        assertEqual(testdata.deal_type, result.deal_type)
        assertEqual(float(testdata.wmoney), float(result.deal_money))
        assertEqual(testdata.income_and_expenses, result.income_and_expense)

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_RGCT_WITHDRAW_6' and normal = 'N' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_rgct_withdraw_no_money(self, model, model1, model2, caseID, caseData):
        """
        测试场景：人工线上存提-->人工提出，未输入提款金额。
        :return: 
        """
        dic_original_data = {
            "model": model,
            "model1": model1,
            "model2": model2,
            "caseID": caseID,
            "caseData": caseData
        }
        testdata = TestData(dic_original_data)
        testdata.username = self.str_username

        # 管理后台的人工线上存提-->人工提出
        self.page_rgct_withdraw = self.page_glht_home.gotoRgctPage().gotoWithdraw()
        result = self.page_rgct_withdraw.withdraw_no_money(testdata)
        assertEqual(testdata.popupwindow1, result.message_rgct_no_money)
        self.page_rgct_withdraw.glhtLogout()

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_RGCT_WITHDRAW_7' and normal = 'N' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_rgct_withdraw_wrong_money(self, model, model1, model2, caseID, caseData):
        """
        测试场景：人工线上存提-->人工提出，提款金额格式错误。
        :return: 
        """
        dic_original_data = {
            "model": model,
            "model1": model1,
            "model2": model2,
            "caseID": caseID,
            "caseData": caseData
        }
        testdata = TestData(dic_original_data)
        testdata.username = self.str_username

        # 管理后台的人工线上存提-->人工提出
        self.page_rgct_withdraw = self.page_glht_home.gotoRgctPage().gotoWithdraw()
        result = self.page_rgct_withdraw.withdraw_wrong_money(testdata)
        assertEqual(testdata.popupwindow1, result.message_rgct_wrong_money)
        self.page_rgct_withdraw.glhtLogout()

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_RGCT_WITHDRAW_8' and normal = 'N' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_rgct_withdraw_no_bet_amount(self, model, model1, model2, caseID, caseData):
        """
        测试场景：人工线上存提-->人工提出，未输入'去除投注量'。
        :return: 
        """
        dic_original_data = {
            "model": model,
            "model1": model1,
            "model2": model2,
            "caseID": caseID,
            "caseData": caseData
        }
        testdata = TestData(dic_original_data)
        testdata.username = self.str_username

        # 管理后台的人工线上存提-->人工提出
        self.page_rgct_withdraw = self.page_glht_home.gotoRgctPage().gotoWithdraw()
        result = self.page_rgct_withdraw.withdraw_no_bet_amount(testdata)
        assertEqual(testdata.popupwindow1, result.message_rgct_no_bet_amount)
        self.page_rgct_withdraw.glhtLogout()

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_RGCT_WITHDRAW_9' and normal = 'N' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_rgct_withdraw_wrong_bet_amount(self, model, model1, model2, caseID, caseData):
        """
        测试场景：人工线上存提-->人工提出，'去除投注量'格式错误。
        :return: 
        """
        dic_original_data = {
            "model": model,
            "model1": model1,
            "model2": model2,
            "caseID": caseID,
            "caseData": caseData
        }
        testdata = TestData(dic_original_data)
        testdata.username = self.str_username

        # 管理后台的人工线上存提-->人工提出
        self.page_rgct_withdraw = self.page_glht_home.gotoRgctPage().gotoWithdraw()
        result = self.page_rgct_withdraw.withdraw_wrong_bet_amount(testdata)
        assertEqual(testdata.popupwindow1, result.message_rgct_wrong_bet_amount)
        self.page_rgct_withdraw.glhtLogout()

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_RGCT_WITHDRAW_10' and normal = 'N' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_rgct_withdraw_insufficient_money(self, model, model1, model2, caseID, caseData):
        """
        测试场景：人工线上存提-->人工提出，余额不足。
        :return: 
        """
        dic_original_data = {
            "model": model,
            "model1": model1,
            "model2": model2,
            "caseID": caseID,
            "caseData": caseData
        }
        testdata = TestData(dic_original_data)
        str_username_no_money = DefaultConfig_Project().get("users", "username_no_money")
        testdata.username = str_username_no_money

        # 管理后台的人工线上存提-->人工提出
        self.page_rgct_withdraw = self.page_glht_home.gotoRgctPage().gotoWithdraw()
        result = self.page_rgct_withdraw.withdraw_insufficient_money(testdata)
        assertEqual(testdata.popupwindow1, result.message_rgct_confirm)
        assertEqual(testdata.popupwindow2, result.message_rgct_insufficient_money)
        self.page_rgct_withdraw.glhtLogout()

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_RGCT_WITHDRAW_11' and normal = 'N' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_rgct_withdraw_insufficient_bet_amount(self, model, model1, model2, caseID, caseData):
        """
        测试场景：人工线上存提-->人工提出，'所需投注量'小于'扣除投注量'。
        :return: 
        """
        dic_original_data = {
            "model": model,
            "model1": model1,
            "model2": model2,
            "caseID": caseID,
            "caseData": caseData
        }
        testdata = TestData(dic_original_data)
        str_username_no_money = DefaultConfig_Project().get("users", "username_no_money")
        testdata.username = str_username_no_money

        # 管理后台的人工线上存提-->人工提出
        self.page_rgct_withdraw = self.page_glht_home.gotoRgctPage().gotoWithdraw()
        result = self.page_rgct_withdraw.withdraw_insufficient_bet_amount(testdata)
        assertEqual(testdata.popupwindow1, result.message_rgct_insufficient_bet_amount)
        self.page_rgct_withdraw.glhtLogout()

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_RGCT_WITHDRAW_12' and normal = 'N' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_rgct_withdraw_no_username(self, model, model1, model2, caseID, caseData):
        """
        测试场景：人工线上存提-->人工提出，'所需投注量'小于'扣除投注量'。
        :return: 
        """
        dic_original_data = {
            "model": model,
            "model1": model1,
            "model2": model2,
            "caseID": caseID,
            "caseData": caseData
        }
        testdata = TestData(dic_original_data)

        # 管理后台的人工线上存提-->人工提出
        self.page_rgct_withdraw = self.page_glht_home.gotoRgctPage().gotoWithdraw()
        result = self.page_rgct_withdraw.withdraw_no_username(testdata)
        assertEqual(testdata.popupwindow1, result.message_rgct_no_username)
        self.page_rgct_withdraw.glhtLogout()

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_RGCT_WITHDRAW_13' and normal = 'N' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_rgct_withdraw_no_exist_user(self, model, model1, model2, caseID, caseData):
        """
        测试场景：人工线上存提-->人工提出，查询不存在的用户。
        :return: 
        """
        dic_original_data = {
            "model": model,
            "model1": model1,
            "model2": model2,
            "caseID": caseID,
            "caseData": caseData
        }
        testdata = TestData(dic_original_data)

        # 管理后台的人工线上存提-->人工提出
        self.page_rgct_withdraw = self.page_glht_home.gotoRgctPage().gotoWithdraw()
        result = self.page_rgct_withdraw.withdraw_no_exist_user(testdata)
        assertEqual(testdata.sysbalance, result.sysbalance)
        assertEqual(testdata.require_amount, result.require_amount)
        assertEqual(testdata.current_amount, result.current_amount)
        self.page_rgct_withdraw.glhtLogout()


if __name__ == '__main__':
    # args = ["test_rgct_withdraw_page.py::TestRgctWithdrawPage::test_rgct_withdraw_normal"]
    # args = ["test_rgct_withdraw_page.py::TestRgctWithdrawPage::test_rgct_withdraw_no_money"]
    # args = ["test_rgct_withdraw_page.py::TestRgctWithdrawPage::test_rgct_withdraw_wrong_money"]
    # args = ["test_rgct_withdraw_page.py::TestRgctWithdrawPage::test_rgct_withdraw_no_bet_amount"]
    # args = ["test_rgct_withdraw_page.py::TestRgctWithdrawPage::test_rgct_withdraw_wrong_bet_amount"]
    # args = ["test_rgct_withdraw_page.py::TestRgctWithdrawPage::test_rgct_withdraw_insufficient_money"]
    # args = ["test_rgct_withdraw_page.py::TestRgctWithdrawPage::test_rgct_withdraw_insufficient_bet_amount"]
    # args = ["test_rgct_withdraw_page.py::TestRgctWithdrawPage::test_rgct_withdraw_no_username"]
    # args = ["test_rgct_withdraw_page.py::TestRgctWithdrawPage::test_rgct_withdraw_no_exist_user"]
    args = ["test_rgct_withdraw_page.py::TestRgctWithdrawPage"]
    pytest.main(args)
