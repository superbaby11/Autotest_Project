#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/7/12 12:00
# @Author  : Terry
import pytest

from src.test.UI_test.common.common import TestData, DataBase
from src.test.UI_test.page.GLHT.GlhtLoginPage import GlhtLoginPage
from src.test.UI_test.page.HomePage import HomePage
from src.utils.assert_extra import assertEqual
from src.utils.config import DefaultConfig_Project
from src.utils.getdb import sql_query, db_mysql_connect


class TestRgctTurnpointPage(object):
    page_home = None
    page_rgct_turnpoint = None

    def setup_method(self):
        # 前台的地址、用户名和密码
        self.url = DefaultConfig_Project().base_url
        self.str_username_player = DefaultConfig_Project().get("users", "username_player")  # 会员
        self.str_password_player = DefaultConfig_Project().get("users", "password_player")
        self.str_username_agent = DefaultConfig_Project().get("users", "username_agent")  # 代理
        self.str_password_agent = DefaultConfig_Project().get("users", "password_agent")
        # 登录管理后台，并跳转到人工存提页面
        back_url = DefaultConfig_Project().get("url", "back_url")
        str_username_back = DefaultConfig_Project().get("users", "username_back")
        str_password_back = DefaultConfig_Project().get("users", "password_back")
        self.page_glht_login = GlhtLoginPage()
        self.page_glht_login.open(back_url)
        self.page_glht_home = self.page_glht_login.loginNormal(str_username_back, str_password_back)
        self.page_rgct_turnpoint = self.page_glht_home.gotoRgctPage().gotoTurnpoint()

    def teardown_method(self):
        try:
            self.page_glht_home.glhtLogout()
        except:
            pass
        self.page_glht_home.quit()

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_RGCT_POINT_%' and normal = 'Y' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_rgct_turnpoint_normal(self, model, model1, model2, caseID, caseData):
        """
        测试场景：管理后台-->现金系统-->人工在线存提-->人工转点的正常流程。
        """
        dic_original_data = {
            "model": model,
            "model1": model1,
            "model2": model2,
            "caseID": caseID,
            "caseData": caseData
        }
        testdata = TestData(dic_original_data)
        testdata.username = self.str_username_player
        testdata.username_agent = self.str_username_agent

        # 管理后台的人工线上存提-->人工转点
        result = self.page_rgct_turnpoint.turnpoint(testdata)
        assertEqual(testdata.popupwindow1, result.message_rgct_commit)
        self.page_rgct_turnpoint.glhtLogout()

        # 验证代理的交易详情
        self.page_rgct_turnpoint.open(self.url)
        self.page_home = HomePage(self.page_rgct_turnpoint.getDriver())
        self.page_home.loginNormal(self.str_username_agent, self.str_password_agent)
        self.page_deal_detail = self.page_home.gotoDealRecordPage().gotoDealDetail()
        result = self.page_deal_detail.search()
        assertEqual(testdata.income_and_expenses, result.income_and_expense)
        assertEqual(testdata.deal_type, result.deal_type)
        assertEqual(float(testdata.deal_money), float(result.deal_money))
        self.page_deal_detail.close_current_window()
        self.page_deal_detail.switch_to_window(0)
        self.page_home.logout()

        # 验证代理的下级会员的交易详情
        self.page_home.loginNormal(self.str_username_player, self.str_password_player)
        self.page_deal_detail = self.page_home.gotoDealRecordPage().gotoDealDetail()
        result = self.page_deal_detail.search()
        assertEqual(testdata.income_and_expenses2, result.income_and_expense)
        assertEqual(testdata.deal_type2, result.deal_type)
        assertEqual(float(testdata.deal_money2), float(result.deal_money))
        self.page_deal_detail.close_current_window()
        self.page_deal_detail.switch_to_window(0)
        self.page_home.logout()

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_RGCT_POINT_%' and normal = 'wrong_out_acc' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_rgct_turnpoint_wrong_out_account(self, model, model1, model2, caseID, caseData):
        """
        测试场景：管理后台-->现金系统-->人工在线存提-->人工转点,输入错误的转出账户。
        """
        dic_original_data = {
            "model": model,
            "model1": model1,
            "model2": model2,
            "caseID": caseID,
            "caseData": caseData
        }
        testdata = TestData(dic_original_data)
        testdata.username = self.str_username_player

        # 管理后台的人工线上存提-->人工转点
        result = self.page_rgct_turnpoint.turnpoint(testdata)
        assertEqual(testdata.popupwindow1, result.message_rgct_commit)
        self.page_rgct_turnpoint.glhtLogout()

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_RGCT_POINT_%' and normal = 'wrong_in_acc' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_rgct_turnpoint_wrong_in_account(self, model, model1, model2, caseID, caseData):
        """
        测试场景：管理后台-->现金系统-->人工在线存提-->人工转点,输入错误的转入账户。
        """
        dic_original_data = {
            "model": model,
            "model1": model1,
            "model2": model2,
            "caseID": caseID,
            "caseData": caseData
        }
        testdata = TestData(dic_original_data)
        testdata.username_agent = self.str_username_agent

        # 管理后台的人工线上存提-->人工转点
        result = self.page_rgct_turnpoint.turnpoint(testdata)
        assertEqual(testdata.popupwindow1, result.message_rgct_commit)
        self.page_rgct_turnpoint.glhtLogout()

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_RGCT_POINT_9' and normal = 'N' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_rgct_turnpoint_off_out_account(self, model, model1, model2, caseID, caseData):
        """
        测试场景：管理后台-->现金系统-->人工在线存提-->人工转点,转出账号不开启转点状态。
        """
        dic_original_data = {
            "model": model,
            "model1": model1,
            "model2": model2,
            "caseID": caseID,
            "caseData": caseData
        }
        testdata = TestData(dic_original_data)
        testdata.username = self.str_username_player
        testdata.username_agent = self.str_username_agent

        # 管理后台的人工线上存提-->人工转点
        DataBase.turn_off_turnpoint(testdata.username_agent)
        result = self.page_rgct_turnpoint.turnpoint(testdata)
        assertEqual(testdata.popupwindow1, result.message_rgct_commit)
        self.page_rgct_turnpoint.glhtLogout()
        DataBase.turn_on_turnpoint(testdata.username_agent)

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_RGCT_POINT_10' and normal = 'N' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_rgct_turnpoint_off_in_account(self, model, model1, model2, caseID, caseData):
        """
        测试场景：管理后台-->现金系统-->人工在线存提-->人工转点,转出账号不开启转点状态。
        """
        dic_original_data = {
            "model": model,
            "model1": model1,
            "model2": model2,
            "caseID": caseID,
            "caseData": caseData
        }
        testdata = TestData(dic_original_data)
        testdata.username = self.str_username_player
        testdata.username_agent = self.str_username_agent

        # 管理后台的人工线上存提-->人工转点
        DataBase.turn_off_turnpoint(testdata.username)
        result = self.page_rgct_turnpoint.turnpoint(testdata)
        assertEqual(testdata.popupwindow1, result.message_rgct_commit)
        self.page_rgct_turnpoint.glhtLogout()
        DataBase.turn_on_turnpoint(testdata.username)

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_RGCT_POINT_%' and normal = 'wrong_money' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_rgct_turnpoint_wrong_money(self, model, model1, model2, caseID, caseData):
        """
        测试场景：管理后台-->现金系统-->人工在线存提-->人工转点,转出账号不开启转点状态。
        """
        dic_original_data = {
            "model": model,
            "model1": model1,
            "model2": model2,
            "caseID": caseID,
            "caseData": caseData
        }
        testdata = TestData(dic_original_data)
        testdata.username = self.str_username_player
        testdata.username_agent = self.str_username_agent

        # 管理后台的人工线上存提-->人工转点
        result = self.page_rgct_turnpoint.turnpoint_wrong_money(testdata)
        assertEqual(testdata.popupwindow1, result.message_rgct_commit)
        self.page_rgct_turnpoint.glhtLogout()

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_RGCT_POINT_15' and normal = 'N' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_rgct_turnpoint_insufficient_money(self, model, model1, model2, caseID, caseData):
        """
        测试场景：管理后台-->现金系统-->人工在线存提-->人工转点,转出金额大于账户余额。
        """
        dic_original_data = {
            "model": model,
            "model1": model1,
            "model2": model2,
            "caseID": caseID,
            "caseData": caseData
        }
        testdata = TestData(dic_original_data)
        testdata.username = self.str_username_player
        testdata.username_agent = self.str_username_agent

        # 管理后台的人工线上存提-->人工转点
        result = self.page_rgct_turnpoint.turnpoint(testdata)
        assertEqual(testdata.popupwindow1, result.message_rgct_commit)
        self.page_rgct_turnpoint.glhtLogout()


if __name__ == '__main__':
    # args = ["test_rgct_turnpoint_page.py::TestRgctTurnpointPage::test_rgct_turnpoint_normal"]
    # args = ["test_rgct_turnpoint_page.py::TestRgctTurnpointPage::test_rgct_turnpoint_wrong_out_account"]
    # args = ["test_rgct_turnpoint_page.py::TestRgctTurnpointPage::test_rgct_turnpoint_wrong_in_account"]
    # args = ["test_rgct_turnpoint_page.py::TestRgctTurnpointPage::test_rgct_turnpoint_off_out_account"]
    # args = ["test_rgct_turnpoint_page.py::TestRgctTurnpointPage::test_rgct_turnpoint_off_in_account"]
    # args = ["test_rgct_turnpoint_page.py::TestRgctTurnpointPage::test_rgct_turnpoint_wrong_money"]
    # args = ["test_rgct_turnpoint_page.py::TestRgctTurnpointPage::test_rgct_turnpoint_insufficient_money"]
    args = ["test_rgct_turnpoint_page.py::TestRgctTurnpointPage"]
    pytest.main(args)
