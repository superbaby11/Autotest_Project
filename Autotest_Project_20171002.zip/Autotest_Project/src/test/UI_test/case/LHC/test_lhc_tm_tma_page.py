#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/8/30 11:36
# @Author  : Terry
import pytest

from src.test.UI_test.case.LHC.LHC_TestBase import LHC_TestBase
from src.test.UI_test.page.HomePage import HomePage
from src.utils.config import DefaultConfig_Project
from src.utils.getdb import sql_query, db_mysql_connect


class Test_LHC_TM_TMA_Page(LHC_TestBase):
    def setup_method(self):
        self.page_home = HomePage()
        self.page_gcdt = self.page_home.gotoGcdtPage()
        # 用户登录
        str_username = DefaultConfig_Project().user_name
        str_password = DefaultConfig_Project().pass_word
        str_authnum = DefaultConfig_Project().auth_num
        self.page_gcdt.loginNormal(str_username, str_password, str_authnum)

    def teardown_method(self):
        self.page_gcdt.quit()

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_LHC_TM_TMA_%' and normal = 'Y' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_lhc_tm_tma_normal(self, model, model1, model2, caseID, caseData):
        """
        测试正常投注流程。
        :return: 
        """
        self.normal(model, model1, model2, caseID, caseData)

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_LHC_TM_TMA_6' and normal = 'N' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_lhc_tm_tma_insufficient(self, model, model1, model2, caseID, caseData):
        """
        测试场景：玩家投注时余额不足。
        :return: 
        """
        self.insufficient(model, model1, model2, caseID, caseData)

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_LHC_TM_TMA_7' and normal = 'N' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_lhc_tm_tma_no_codes(self, model, model1, model2, caseID, caseData):
        """
        测试场景：玩家投注时余额不足。
        :return: 
        """
        self.no_codes(model, model1, model2, caseID, caseData)

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_LHC_TM_TMA_8' and normal = 'N' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_lhc_tm_tma_reset(self, model, model1, model2, caseID, caseData):
        """
        测试场景：玩家输入投注号码和金额后，点击重置按钮。
        :return: 
        """
        self.reset(model, model1, model2, caseID, caseData)

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_LHC_TM_TMA_9' and normal = 'N' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_lhc_tm_tma_invalid_money(self, model, model1, model2, caseID, caseData):
        """
        测试场景：玩家输入无效的投注金额。
        :return: 
        """
        self.invalid_money(model, model1, model2, caseID, caseData)

if __name__ == '__main__':
    # args = ["test_lhc_tm_tma_page.py::Test_LHC_TM_TMA_Page::test_lhc_tm_tma_normal"]
    # args = ["test_lhc_tm_tma_page.py::Test_LHC_TM_TMA_Page::test_lhc_tm_tma_insufficient"]
    # args = ["test_lhc_tm_tma_page.py::Test_LHC_TM_TMA_Page::test_lhc_tm_tma_no_codes"]
    # args = ["test_lhc_tm_tma_page.py::Test_LHC_TM_TMA_Page::test_lhc_tm_tma_reset"]
    # args = ["test_lhc_tm_tma_page.py::Test_LHC_TM_TMA_Page::test_lhc_tm_tma_invalid_money"]
    args = ["test_lhc_tm_tma_page.py", "--instafail"]
    pytest.main(args)
