#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/8/30 11:38
# @Author  : Terry
from src.test.UI_test.case.TestBase import TestBase
from src.test.UI_test.common.common import TestData
from src.test.UI_test.page.LHC.LHCBase import LHCBase
from src.test.UI_test.page.LHC.LHC_HX_HX_Page import LHC_HX_HX_Page
from src.test.UI_test.page.LHC.LHC_LM_LM_Page import LHC_LM_LM_Page
from src.test.UI_test.page.LHC.LHC_SB_SB_Page import LHC_SB_SB_Page
from src.test.UI_test.page.LHC.LHC_TM_TMA_Page import LHC_TM_TMA_Page
from src.test.UI_test.page.LHC.LHC_TM_TMB_Page import LHC_TM_TMB_Page
from src.test.UI_test.page.LHC.LHC_TWS_TWS_Page import LHC_TWS_TWS_Page
from src.test.UI_test.page.LHC.LHC_TX_TX_Page import LHC_TX_TX_Page
from src.test.UI_test.page.LHC.LHC_ZMT_Z1T_Page import LHC_ZMT_Z1T_Page
from src.test.UI_test.page.LHC.LHC_ZMT_Z2T_Page import LHC_ZMT_Z2T_Page
from src.test.UI_test.page.LHC.LHC_ZM_ZM_Page import LHC_ZM_ZM_Page
from src.test.UI_test.page.Manage.DealRecord.DealDetailPage import DealDetailPage
from src.utils.assert_extra import assertEqual, assertContain
from src.utils.config import DefaultConfig_Project


class LHC_TestBase(TestBase):
    # 执行测试方法时，生成对应的彩种页面类
    dic_lottery = {
        u"六合彩": LHCBase,
    }
    # 执行测试方法时，生成对应的玩法页面类
    dic_mothod = {
        u"六合彩_特码_特码B": LHC_TM_TMB_Page,
        u"六合彩_特码_特码A": LHC_TM_TMA_Page,
        u"六合彩_两面_两面": LHC_LM_LM_Page,
        u"六合彩_色波_色波": LHC_SB_SB_Page,
        u"六合彩_特肖_特肖": LHC_TX_TX_Page,
        u"六合彩_合肖_合肖": LHC_HX_HX_Page,
        u"六合彩_头尾数_头尾数": LHC_TWS_TWS_Page,
        u"六合彩_正码_正码": LHC_ZM_ZM_Page,
        u"六合彩_正码特_正一特": LHC_ZMT_Z1T_Page,
        u"六合彩_正码特_正二特": LHC_ZMT_Z2T_Page,
    }

    def normal(self, model, model1, model2, caseID, caseData):
        """
        测试正常投注流程。
        :param model: 彩种，例如六合彩。
        :param model1: 大玩法，例如特码。
        :param model2: 小玩法，例如特码B。
        :param caseID: 测试数据ID，在Excel中。
        :param caseData: 测试数据，在Excel中。
        :return: 
        """
        dic_original_data = {
            "model": model,
            "model1": model1,
            "model2": model2,
            "caseID": caseID,
            "caseData": caseData
        }

        testdata = TestData(dic_original_data)
        self.page_method = self._goto_method_page(testdata.model, testdata.model1, testdata.model2)
        # 六合彩投注页面
        result = self.page_method.bet_normal(testdata)
        assertEqual(testdata.deal_money, result.deal_money)
        assertEqual(testdata.popupwindow1, result.message_confirm_bet)
        assertEqual(testdata.popupwindow2, result.message_bet_success)

        # 投注记录页面
        self.page_bet_record = self.page_method.gotoBetRecordPage()
        if testdata.has_status:
            self.page_bet_record.revertBet()
        result = self.page_bet_record.search()
        assertContain(testdata.methodid, result.method)

        # 交易明细页面
        self.page_bet_record.gotoDealDetail()
        self.page_deal_detail = DealDetailPage(self.page_bet_record.getDriver())
        result = self.page_deal_detail.search()
        assertEqual(testdata.income_and_expenses, result.income_and_expense)
        assertEqual(testdata.deal_type, result.deal_type)

    def insufficient(self, model, model1, model2, caseID, caseData):
        """
        测试情景：玩家投注时，余额不足的流程。
        :param model: 彩种，例如六合彩。
        :param model1: 大玩法，例如特码。
        :param model2: 小玩法，例如特码B。
        :param caseID: 测试数据ID，在Excel中。
        :param caseData: 测试数据，在Excel中。
        :return: 
        """
        dic_original_data = {
            "model": model,
            "model1": model1,
            "model2": model2,
            "caseID": caseID,
            "caseData": caseData
        }
        testdata = TestData(dic_original_data)

        # 退出当前余额充足的用户，登录余额不足的用户
        self.page_gcdt.logoutAndClose()
        self.page_gcdt = self.page_home.gotoGcdtPage()
        str_username = DefaultConfig_Project().get("users", "username_no_money")
        str_password = DefaultConfig_Project().get("users", "password_no_money")
        str_authnum = DefaultConfig_Project().get("users", "auth_num_no_money")
        self.page_gcdt.loginNormal(str_username, str_password, str_authnum)
        self.page_method = self._goto_method_page(testdata.model, testdata.model1, testdata.model2)

        # 六合彩投注页面
        result = self.page_method.insufficient(testdata)
        assertEqual(testdata.popupwindow1, result.message_confirm_bet)
        assertEqual(testdata.popupwindow2, result.message_bet_insufficient)

    def no_codes(self, model, model1, model2, caseID, caseData):
        """
        测试情景：玩家投注时，余额不足的流程。
        :param model: 彩种，例如六合彩。
        :param model1: 大玩法，例如特码。
        :param model2: 小玩法，例如特码B。
        :param caseID: 测试数据ID，在Excel中。
        :param caseData: 测试数据，在Excel中。
        :return: 
        """
        dic_original_data = {
            "model": model,
            "model1": model1,
            "model2": model2,
            "caseID": caseID,
            "caseData": caseData
        }
        testdata = TestData(dic_original_data)
        self.page_method = self._goto_method_page(testdata.model, testdata.model1, testdata.model2)

        # 六合彩投注页面
        result = self.page_method.no_codes(testdata)
        assertEqual(testdata.popupwindow1, result.message_wrong_codes)

    def reset(self, model, model1, model2, caseID, caseData):
        """
        测试场景：玩家输入投注号码和金额后，点击重置按钮。
        :param model: 
        :param model1: 
        :param model2: 
        :param caseID: 
        :param caseData: 
        :return: 
        """
        dic_original_data = {
            "model": model,
            "model1": model1,
            "model2": model2,
            "caseID": caseID,
            "caseData": caseData
        }

        testdata = TestData(dic_original_data)
        self.page_method = self._goto_method_page(testdata.model, testdata.model1, testdata.model2)
        # 六合彩投注页面
        result = self.page_method.reset(testdata)
        assertEqual(testdata.popupwindow1, result.message_wrong_codes)

    def invalid_money(self, model, model1, model2, caseID, caseData):
        """
        测试情景：玩家投注时输入无效的金额。
        :param model: 彩种，例如六合彩。
        :param model1: 大玩法，例如特码。
        :param model2: 小玩法，例如特码B。
        :param caseID: 测试数据ID，在Excel中。
        :param caseData: 测试数据，在Excel中。
        :return:
        """
        dic_original_data = {
            "model": model,
            "model1": model1,
            "model2": model2,
            "caseID": caseID,
            "caseData": caseData
        }
        testdata = TestData(dic_original_data)
        self.page_method = self._goto_method_page(testdata.model, testdata.model1, testdata.model2)

        # 六合彩投注页面
        result = self.page_method.invalid_money(testdata)
        assertEqual(testdata.popupwindow2, result.message_invalid_money)
