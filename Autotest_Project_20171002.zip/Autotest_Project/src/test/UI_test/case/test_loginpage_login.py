#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/5/26 13:33
# @Author  : Terry

import pytest

from src.test.UI_test.common.common import DataBase
from src.test.UI_test.page.HomePage import HomePage
from src.utils.assert_extra import assertEqual
from src.utils.getdb import db_mysql_connect, unicode_dict,sql_query


class TestLoginPageLogin(object):
    # @classmethod
    # def setup_class(cls):
    #     DataBase.reset_wrong_count('jtest')
    #     cls.page_home = HomePage()
    #     cls.page_regist = cls.page_home.gotoRegistPage()
    #     cls.page_login = cls.page_regist.gotoLoginPage()
    #
    # @classmethod
    # def teardown_class(cls):
    #     cls.page_login.quit()
    #     DataBase.reset_wrong_count('jtest')
    def setup_method(self):
        DataBase.reset_wrong_count('jtest')
        self.page_home = HomePage()
        self.page_regist = self.page_home.gotoRegistPage()
        self.page_login = self.page_regist.gotoLoginPage()

    def teardown_method(self):
        self.page_login.quit()
        DataBase.reset_wrong_count('jtest')

    str_sql = "select caseID, caseData from web_autotest_case where caseID like 'CP_WEB_MAIN_LOGIN%' and normal = 'Y' ;"

    @pytest.mark.parametrize("caseID,caseData", sql_query(db_mysql_connect(), str_sql))
    def test_loginpage_normal_login(self, caseID, caseData):
        """
        测试登录页面【正常】登陆流程
        :return: 
        """
        dic_test_data = unicode_dict(caseData)
        str_username = unicode(dic_test_data[u"lg_username"])
        str_password = unicode(dic_test_data[u"lg_pwd"])
        str_expected_acc = unicode(dic_test_data[u"acc"])
        str_actual_acc = self.page_login.loginNormal(str_username, str_password)
        assertEqual(str_expected_acc, str_actual_acc)
        self.page_login.logout()
        self.page_regist = self.page_home.gotoRegistPage()
        self.page_login = self.page_regist.gotoLoginPage()

    str_sql = "select caseID, caseData from web_autotest_case where caseID like 'CP_WEB_MAIN_LOGIN%' and normal = 'N' ;"

    @pytest.mark.parametrize("caseID,caseData", sql_query(db_mysql_connect(), str_sql))
    def test_loginpage_abnormal_login(self, caseID, caseData):
        """
        测试登录页面【异常】登陆流程
        :return: 
        """
        dic_test_data = unicode_dict(caseData)
        str_username = unicode(dic_test_data[u"lg_username"], "utf-8")
        str_password = unicode(dic_test_data[u"lg_pwd"])
        str_expected_pop = unicode(dic_test_data[u"popupmessage"], "utf-8")
        str_actual_pop = self.page_login.loginAbnormal(str_username, str_password)
        assertEqual(str_expected_pop, str_actual_pop)

if __name__ == '__main__':
    # args = ['test_loginpage_login.py::TestLoginPageLogin::test_loginpage_normal_login']
    args = ['test_loginpage_login.py']
    pytest.main(args)
