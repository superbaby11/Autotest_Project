#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/6/23 17:12
# @Author  : Terry
import pytest

from src.test.UI_test.case.TestBase import TestBase
from src.test.UI_test.page.HomePage import HomePage
from src.utils.config import DefaultConfig_Project
from src.utils.getdb import sql_query, db_mysql_connect


class Test_AHKS_SBTH_BZ_Page(TestBase):
    # @classmethod
    # def setup_class(cls):
    #     cls.page_home = HomePage()
    #     cls.page_gcdt = cls.page_home.gotoGcdtPage()
    #     # 用户登录
    #     str_username = DefaultConfig_Project().user_name
    #     str_password = DefaultConfig_Project().pass_word
    #     str_authnum = DefaultConfig_Project().auth_num
    #     cls.page_gcdt.loginNormal(str_username, str_password, str_authnum)
    #
    # @classmethod
    # def teardown_class(cls):
    #     cls.page_gcdt.quit()
    def setup_method(self):
        self.page_home = HomePage()
        self.page_gcdt = self.page_home.gotoGcdtPage()
        # 用户登录
        str_username = DefaultConfig_Project().user_name
        str_password = DefaultConfig_Project().pass_word
        str_authnum = DefaultConfig_Project().auth_num
        self.page_gcdt.loginNormal(str_username, str_password, str_authnum)

    def teardown_method(self):
        self.page_gcdt.quit()

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_AHKS_SBTH_BZ_%' and normal = 'Y' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_ahks_sbth_bz_normal(self, model, model1, model2, caseID, caseData):
        """
        测试正常投注流程。
        :return: 
        """
        self.normal(model, model1, model2, caseID, caseData)

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_AHKS_SBTH_BZ_8' and normal = 'N' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_ahks_sbth_bz_insufficient(self, model, model1, model2, caseID, caseData):
        """
        测试场景：用户投注时余额不足。
        :return: 
        """
        self.insufficient(model, model1, model2, caseID, caseData)

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_AHKS_SBTH_BZ_9' and normal = 'N' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_ahks_sbth_bz_clean_all(self, model, model1, model2, caseID, caseData):
        """
        测试场景：添加注单后，删除全部注单。
        :return: 
        """
        self.clean_all(model, model1, model2, caseID, caseData)

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_AHKS_SBTH_BZ_10' and normal = 'N' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_ahks_sbth_bz_change_normal_to_random(self, model, model1, model2, caseID, caseData):
        """
        测试场景：选择投注号码后，不点击‘添加注单’，点击随机一注。
        :return: 
        """
        self.change_normal_to_random(model, model1, model2, caseID, caseData)

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_AHKS_SBTH_BZ_11' and normal = 'N' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_ahks_sbth_bz_wrong_codes(self, model, model1, model2, caseID, caseData):
        """
        测试场景：投注号码不完整。
        :return: 
        """
        self.wrong_codes(model, model1, model2, caseID, caseData)

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_AHKS_SBTH_BZ_12' and normal = 'N' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_ahks_sbth_bz_add_empty(self, model, model1, model2, caseID, caseData):
        """
        测试场景：没有选择投注号码，点击‘添加注单’。
        :return: 
        """
        self.add_empty(model, model1, model2, caseID, caseData)

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_AHKS_SBTH_BZ_13' and normal = 'N' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_ahks_sbth_bz_buy_empty(self, model, model1, model2, caseID, caseData):
        """
        测试场景：没有选择投注号码，点击‘确认投注’。
        :return: 
        """
        self.buy_empty(model, model1, model2, caseID, caseData)

    str_sql = "select model, model1, model2, caseID, caseData from web_autotest_case " \
              "where caseID like 'CP_WEB_AHKS_SBTH_BZ_14' and normal = 'N' ;"

    @pytest.mark.parametrize("model, model1, model2, caseID, caseData", sql_query(db_mysql_connect(), str_sql))
    def test_ahks_sbth_bz_wrong_money(self, model, model1, model2, caseID, caseData):
        """
        测试场景：投注时，输入错误的金额，例如0元。
        :return: 
        """
        self.wrong_money(model, model1, model2, caseID, caseData)

if __name__ == '__main__':
    # args = ['test_ahks_sbth_bz_page.py::Test_AHKS_SBTH_BZ_Page::test_ahks_sbth_bz_normal']
    # args = ['test_ahks_sbth_bz_page.py::Test_AHKS_SBTH_BZ_Page::test_ahks_sbth_bz_insufficient']
    # args = ['test_ahks_sbth_bz_page.py::Test_AHKS_SBTH_BZ_Page::test_ahks_sbth_bz_clean_all']
    # args = ['test_ahks_sbth_bz_page.py::Test_AHKS_SBTH_BZ_Page::test_ahks_sbth_bz_change_normal_to_random']
    # args = ['test_ahks_sbth_bz_page.py::Test_AHKS_SBTH_BZ_Page::test_ahks_sbth_bz_wrong_codes']
    # args = ['test_ahks_sbth_bz_page.py::Test_AHKS_SBTH_BZ_Page::test_ahks_sbth_bz_add_empty']
    # args = ['test_ahks_sbth_bz_page.py::Test_AHKS_SBTH_BZ_Page::test_ahks_sbth_bz_buy_empty']
    # args = ['test_ahks_sbth_bz_page.py::Test_AHKS_SBTH_BZ_Page::test_ahks_sbth_bz_wrong_money']
    args = ['test_ahks_sbth_bz_page.py::Test_AHKS_SBTH_BZ_Page']
    pytest.main(args)
