#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/6/22 20:19
# @Author  : Terry
import pytest
import time


@pytest.fixture(scope="function", autouse=True)
def time_mark(request):
    print("\n`!@#$")
    print(time.strftime("\n%Y-%m-%d %H:%M:%S", time.localtime()))
    print(request.getfuncargvalue("caseID")+"\n")
