#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/6/23 11:13
# @Author  : Terry
from src.test.UI_test.page.Widget import Widget


class AHKSBase(Widget):
    # 安徽快三彩种对应的玩法
    dic_model = {
        u"和值": {
            "locator": ("css", "#tabbar-div-s2 > span:nth-child(1) > span.content"),
            "model2": {}
        },
        u"三同号":{
            "locator": ("css", "#tabbar-div-s2 > span:nth-child(2) > span.content"),
            "model2": {
                u"通选": ("css", "#smalllabel_0_0"),
                u"单选": ("css", "#smalllabel_0_1")
            }
        },
        u"三不同号": {
            "locator": ("css", "#tabbar-div-s2 > span:nth-child(3) > span.content"),
            "model2": {
                u"标准": ("css", "#smalllabel_0_0"),
                u"胆拖": ("css", "#smalllabel_0_1")
            }
        },
        u"三连号": {
            "locator": ("css", "#tabbar-div-s2 > span:nth-child(4) > span.content"),
            "model2": {}
        },
        u"二同号": {
            "locator": ("css", "#tabbar-div-s2 > span:nth-child(5) > span.content"),
            "model2": {
                u"复选": ("css", "#smalllabel_0_0"),
                u"单选": ("css", "#smalllabel_0_1")
            }
        },
        u"二不同号": {
            "locator": ("css", "#tabbar-div-s2 > span:nth-child(6) > span.content"),
            "model2": {
                u"标准": ("css", "#smalllabel_0_0"),
                u"胆拖": ("css", "#smalllabel_0_1")
            }
        }
    }
