#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/6/23 16:12
# @Author  : Terry
from src.test.UI_test.page.AHKS.AHKSBase import AHKSBase


class AHKS_STH_DX_Page(AHKSBase):
    # 安徽快三的三同号玩法的单选玩法对应的号码
    dic_bet_num = {
        1: {
            u"111": ".gdts>div:nth-child(1)",
            u"222": ".gdts>div:nth-child(2)",
            u"333": ".gdts>div:nth-child(3)",
            u"444": ".gdts>div:nth-child(4)",
            u"555": ".gdts>div:nth-child(5)",
            u"666": ".gdts>div:nth-child(6)"
        }
    }
