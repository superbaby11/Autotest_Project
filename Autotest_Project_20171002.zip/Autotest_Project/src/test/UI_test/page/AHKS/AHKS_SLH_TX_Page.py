#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/6/24 8:51
# @Author  : Terry
from src.test.UI_test.page.AHKS.AHKSBase import AHKSBase


class AHKS_SLH_TX_Page(AHKSBase):
    # 安徽快三的三连号玩法的通选玩法对应的号码
    dic_bet_num = {
        1: {
            u"三连号通选": ".gdts>div"
        }
    }
