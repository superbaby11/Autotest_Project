#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/6/23 17:07
# @Author  : Terry
from src.test.UI_test.page.AHKS.AHKSBase import AHKSBase


class AHKS_SBTH_BZ_Page(AHKSBase):
    # 安徽快三的三不同号玩法的标准玩法对应的号码
    dic_bet_num = {
        1: {
            u"1": ".gd>div:nth-child(1)",
            u"2": ".gd>div:nth-child(2)",
            u"3": ".gd>div:nth-child(3)",
            u"4": ".gd>div:nth-child(4)",
            u"5": ".gd>div:nth-child(5)",
            u"6": ".gd>div:nth-child(6)"
        }
    }
