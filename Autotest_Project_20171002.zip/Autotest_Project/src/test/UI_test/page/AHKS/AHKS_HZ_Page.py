#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/6/23 11:26
# @Author  : Terry
from src.test.UI_test.page.AHKS.AHKSBase import AHKSBase


class AHKS_HZ_Page(AHKSBase):
    # 安徽快三和值玩法对应的号码
    dic_bet_num = {
        1: {
            u"3": ".gd>span>div:nth-child(1)",
            u"4": ".gd>span>div:nth-child(2)",
            u"5": ".gd>span>div:nth-child(3)",
            u"6": ".gd>span>div:nth-child(4)",
            u"7": ".gd>span>div:nth-child(5)",
            u"8": ".gd>span>div:nth-child(6)",
            u"9": ".gd>span>div:nth-child(7)",
            u"10": ".gd>span>div:nth-child(8)",
            u"11": ".gd>span>div:nth-child(9)",
            u"12": ".gd>span>div:nth-child(10)",
            u"13": ".gd>span>div:nth-child(11)",
            u"14": ".gd>span>div:nth-child(12)",
            u"15": ".gd>span>div:nth-child(13)",
            u"16": ".gd>span>div:nth-child(14)",
            u"17": ".gd>span>div:nth-child(15)",
            u"18": ".gd>span>div:nth-child(16)",
        }
    }
