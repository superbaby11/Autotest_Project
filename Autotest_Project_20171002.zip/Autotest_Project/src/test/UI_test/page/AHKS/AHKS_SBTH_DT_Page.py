#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/6/24 8:44
# @Author  : Terry
from src.test.UI_test.page.AHKS.AHKSBase import AHKSBase


class AHKS_SBTH_DT_Page(AHKSBase):
    # 安徽快三的三不同号玩法的胆拖玩法对应的号码
    dic_bet_num = {
        1: {
            u"1": "#lt_selector>div:nth-child(1) .gd>div:nth-child(1)",
            u"2": "#lt_selector>div:nth-child(1) .gd>div:nth-child(2)",
            u"3": "#lt_selector>div:nth-child(1) .gd>div:nth-child(3)",
            u"4": "#lt_selector>div:nth-child(1) .gd>div:nth-child(4)",
            u"5": "#lt_selector>div:nth-child(1) .gd>div:nth-child(5)",
            u"6": "#lt_selector>div:nth-child(1) .gd>div:nth-child(6)"
        },
        2: {
            u"1": "#lt_selector>div:nth-child(2) .gd>div:nth-child(1)",
            u"2": "#lt_selector>div:nth-child(2) .gd>div:nth-child(2)",
            u"3": "#lt_selector>div:nth-child(2) .gd>div:nth-child(3)",
            u"4": "#lt_selector>div:nth-child(2) .gd>div:nth-child(4)",
            u"5": "#lt_selector>div:nth-child(2) .gd>div:nth-child(5)",
            u"6": "#lt_selector>div:nth-child(2) .gd>div:nth-child(6)"
        }
    }
