#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/7/15 10:26
# @Author  : Terry
from src.test.UI_test.common.common import TestResult
from src.test.UI_test.page.GLHT.GlhtBase import GlhtBase


class FundsSettingPage(GlhtBase):
    """
    管理后台-->现金系统-->出入款设定。
    """
    # 首存优惠设定
    tup_min_reload = ("css", "[name=DFStand1]")  # 最低存款金额
    tup_bonus_pct = ("css", "[name=DFRate1]")  # 优惠百分比
    tup_bonus_max = ("css", "[name=DFUpper1]")  # 优惠金额上限

    # 银行/微信/支付宝充值 每次存款优惠
    tup_min_reload2 = ("css", "[name=DFStand2]")  # 最低存款金额
    tup_bonus_pct2 = ("css", "[name=DFRate2]")  # 优惠百分比
    tup_bonus_max2 = ("css", "[name=DFUpper2]")  # 优惠金额上限

    # 第三方支付 每次存款优惠
    tup_min_reload4 = ("css", "[name=DFStand4]")  # 最低存款金额
    tup_bonus_pct4 = ("css", "[name=DFRate4]")  # 优惠百分比
    tup_deposit_upper = ("css", "[name=DepositUpper4]")  # 单次入款最高的额度
    tup_deposit_lower = ("css", "[name=DepositLower4]")  # 单次入款最低的额度
    tup_bonus_max4 = ("css", "[name=DFUpper4]")  # 优惠金额上限

    # 保存
    tup_damabeishu = ("css", "[name=FirstDepositCheckRete]")  # 打码倍数
    dic_on_off_favor = {
        u"有": ("css", "tbody input+label .uniform"),  # 开启首存优惠
        u"无": ("css", "tbody input+label+label .uniform")  # 关闭首存优惠
    }
    tup_commit_btn = ("css", "[type=button]")
    tup_reset_btn = ("css", "[type=reset]")
    tup_popup_window1 = ("css", "#ui-id-1")
    tup_close_btn = ("css", ".zzh_qd")

    def first_deposit_setting(self, testdata):
        """
        首存优惠设定。
        :return: 
        """
        result = TestResult()
        self.type(self.tup_min_reload, testdata.min_reload)
        self.type(self.tup_bonus_pct, testdata.bonus_pct)
        self.type(self.tup_bonus_max, testdata.bonus_max)
        self.type(self.tup_damabeishu, testdata.damabeishu)
        if testdata.has_first_dbonus:
            if testdata.first_dbonus in self.dic_on_off_favor.keys():
                self.click(self.dic_on_off_favor[testdata.first_dbonus])
            else:
                raise Exception("Invalid data: %s. Should be one of: %s."
                                % (testdata.first_dbonus, str(self.dic_on_off_favor.keys())))
        self.click(self.tup_commit_btn)
        result.message_funds_setting_commit = self.getText(self.tup_popup_window1)
        if self.getDisplay(self.tup_close_btn):
            self.click(self.tup_close_btn)
        return result

    def every_deposit_setting(self, testdata):
        """
        银行/微信/支付宝，每次充值设定。
        :param testdata: 
        :return: 
        """
        result = TestResult()
        self.type(self.tup_min_reload2, testdata.min_reload)
        self.type(self.tup_bonus_pct2, testdata.bonus_pct)
        self.type(self.tup_bonus_max2, testdata.bonus_max)
        self.type(self.tup_damabeishu, testdata.damabeishu)
        if testdata.has_first_dbonus:
            if testdata.first_dbonus in self.dic_on_off_favor.keys():
                self.click(self.dic_on_off_favor[testdata.first_dbonus])
            else:
                raise Exception("Invalid data: %s. Should be one of: %s."
                                % (testdata.first_dbonus, str(self.dic_on_off_favor.keys())))
        self.click(self.tup_commit_btn)
        result.message_funds_setting_commit = self.getText(self.tup_popup_window1)
        if self.getDisplay(self.tup_close_btn):
            self.click(self.tup_close_btn)
        return result
