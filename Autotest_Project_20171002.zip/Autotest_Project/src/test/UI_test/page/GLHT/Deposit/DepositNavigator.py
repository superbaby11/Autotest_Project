#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/7/3 15:42
# @Author  : Terry
from src.test.UI_test.page.BasePage import BasePage
from src.test.UI_test.page.GLHT.Deposit.AlipayPage import AlipayPage
from src.test.UI_test.page.GLHT.Deposit.CompanyPage import CompanyPage
from src.test.UI_test.page.GLHT.Deposit.ThirdPage import ThirdPage
from src.test.UI_test.page.GLHT.Deposit.WechatPage import WechatPage


class DepositNavigator(BasePage):
    tup_bank = ("css", ".header.fl>a:nth-child(2)")
    tup_third = ("css", ".header.fl>a:nth-child(3)")
    tup_wechat = ("css", ".header.fl>a:nth-child(4)")
    tup_alipay = ("css", ".header.fl>a:nth-child(5)")

    def company(self):
        """
        打开管理后台的公司入款页面。
        :return: 
        """
        self.click(self.tup_bank)
        return CompanyPage(self.getDriver())

    def wechat(self):
        """
        打开管理后台的微信入款页面。
        :return: 
        """
        self.click(self.tup_wechat)
        return WechatPage(self.getDriver())

    def alipay(self):
        """
        打开管理后台的支付宝入款页面。
        :return: 
        """
        self.click(self.tup_alipay)
        return AlipayPage(self.getDriver())

    def third(self):
        """
        打开管理后台的第三方支付页面。
        :return: 
        """
        self.click(self.tup_third)
        return ThirdPage(self.getDriver())
