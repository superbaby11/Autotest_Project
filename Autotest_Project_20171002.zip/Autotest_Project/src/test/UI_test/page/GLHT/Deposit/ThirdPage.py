#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/7/1 10:44
# @Author  : Terry
import time

from src.test.UI_test.common.common import TestResult
from src.test.UI_test.page.GLHT.Deposit.DepositBase import DepositBase


class ThirdPage(DepositBase):
    tup_order_id = ("css", "[name=orderid]")
    tup_search_btn = ("css", "#searchBtn")
    tup_table = ("css", "#withdrawTable>tbody")
    tup_force_deposit = ("css", "tbody>tr:nth-child(2) button:nth-child(1)")

    def search(self, str_order):
        """
        在第三方支付入款页面，依据订单号进行搜索。
        :param str_order: 订单号
        :return: 
        """
        result = TestResult()
        self.type(self.tup_order_id, str_order)
        self.click(self.tup_search_btn)
        self.waitElementPresent(self.tup_table)
        lis_row = self.getTargetRow(str_order, self.tup_table, 7)
        if len(lis_row) == 0:
            raise Exception("\nThere is no data according to order: %s." % str_order)
        else:
            # 读取充值金额和优惠金额
            result.dmoney = self.getCellText(self.tup_table, lis_row[0], 4)
            result.reward = self.getCellText(self.tup_table, lis_row[0], 5)

            # 强制入款
            if not u"已确认" == self.getCellText(self.tup_table, lis_row[0], 8):
                self.click(self.tup_force_deposit)
                if self.getDisplay(self.tup_close_btn):
                    self.click(self.tup_close_btn)

            # 读取充值时间和交易时间
            time.sleep(3)
            str_deposit_time = self.getCellText(self.tup_table, lis_row[0], 11)
            result.deposit_time = (str_deposit_time.split("\n")[1]).split(u"：", 1)[1].strip()
            result.deal_time = (str_deposit_time.split("\n")[1]).split(u"：", 1)[1].strip()
        return result
