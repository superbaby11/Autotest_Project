#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/7/1 10:43
# @Author  : Terry
from src.test.UI_test.common.common import TestResult
from src.test.UI_test.page.GLHT.Deposit.DepositBase import DepositBase


class CompanyPage(DepositBase):
    def search(self, str_order):
        """
        在公司入款页面，依据订单号进行搜索。
        :param str_order: 订单号
        :return: 
        """
        result = TestResult()
        self.type(self.tup_order_id, str_order)
        self.click(self.tup_search_btn)
        self.waitElementPresent(self.tup_table)
        lis_row = self.getTargetRow(str_order, self.tup_table, 2)
        if len(lis_row) == 0:
            raise Exception("\nThere is no data according to order: %s." % str_order)
        else:
            # 读取充值金额和优惠金额
            str_deposit_money = self.getCellText(self.tup_table, lis_row[0], 5)
            result.dmoney = (str_deposit_money.split("\n")[0]).split(":")[1]
            result.reward = (str_deposit_money.split("\n")[1]).split(":")[1]
            if u"首存优惠" == (str_deposit_money.split("\n")[2]).split(":")[0]:
                result.first_reward = (str_deposit_money.split("\n")[2]).split(":")[1]

            # 锁定和确认存款
            if not u"已存入" == self.getCellText(self.tup_table, lis_row[0], 7):
                self.click(self.tup_lock_btn)
                result.message_deposit_lock = self.getText(self.tup_popup_message1)
                if self.getDisplay(self.tup_close_btn):
                    self.click(self.tup_close_btn)
                self.click(self.tup_confirm_btn)
                result.message_deposit_confirm = self.getText(self.tup_popup_message2)
                if self.getDisplay(self.tup_close_btn):
                    self.click(self.tup_close_btn)

            # 读取充值时间和交易时间
            str_deposit_time = self.getCellText(self.tup_table, lis_row[0], 11)
            result.deposit_time = (str_deposit_time.split("\n")[0]).split(":", 1)[1].strip()
            result.deal_time = (str_deposit_time.split("\n")[1]).split(":", 1)[1].strip()
        return result
