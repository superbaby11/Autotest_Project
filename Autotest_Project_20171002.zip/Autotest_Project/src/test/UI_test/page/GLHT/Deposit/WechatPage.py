#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/7/1 10:43
# @Author  : Terry
from src.test.UI_test.page.GLHT.Deposit.DepositBase import DepositBase


class WechatPage(DepositBase):
    pass
