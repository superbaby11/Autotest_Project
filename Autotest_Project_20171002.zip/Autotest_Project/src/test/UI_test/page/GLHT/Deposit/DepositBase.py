#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/7/3 16:25
# @Author  : Terry
import time

from src.test.UI_test.common.common import TestResult
from src.test.UI_test.page.GLHT.GlhtBase import GlhtBase


class DepositBase(GlhtBase):
    tup_user_account = ("css", "#member_account")
    tup_order_id = ("css", "#recipient")
    tup_search_btn = ("css", "#search")
    tup_table = ("css", "#datatable")
    tup_lock_btn = ("css", "#datatable button:nth-child(1)")
    tup_confirm_btn = ("css", "#datatable button:nth-child(2)")
    tup_cancel_btn = ("css", "#datatable button:nth-child(3)")
    tup_popup_message1 = ("css", "#ui-id-1")
    tup_close_btn = ("css", ".zzh_qd")
    tup_popup_message2 = ("css", "#ui-id-3")

    def getTargetRow(self, str_order, tup_table, int_order_column, second=1):
        """
        找出与投注时间一致的条目。
        :param str_order: 入款订单号码。
        :param tup_table: 表格地址。
        :param int_order_column: 订单号所在列，从0开始编号。
        :param second: 等待时间。
        :return: 返回与入款订单号码匹配的条目的行号。
        """
        lis_row = []
        el = self.findElement(tup_table)
        time.sleep(second)
        lis_tr = el.find_elements_by_tag_name("tr")
        for i in range(len(lis_tr) - 2):  # 最后两行是统计数据
            if str_order == self.getCellText(tup_table, i, int_order_column):
                lis_row.append(i)
        return lis_row

    def search(self, account):
        """
        在支付宝或者微信入款页面，根据玩家的名称进行筛选信息。
        :param account: 玩家的用户名。
        :return: 
        """
        result = TestResult()
        self.type(self.tup_user_account, account)
        self.click(self.tup_search_btn)
        self.waitElementPresent(self.tup_table)
        lis_row = self.getTargetRow(account, self.tup_table, 3)
        if len(lis_row) == 0:
            raise Exception("\nThere is no data according to user account: %s." % account)
        else:
            # 读取充值金额和优惠金额
            str_deposit_money = self.getCellText(self.tup_table, lis_row[0], 5)
            result.dmoney = (str_deposit_money.split("\n")[0]).split(":")[1]
            result.reward = (str_deposit_money.split("\n")[1]).split(":")[1]
            if u"首存优惠" == (str_deposit_money.split("\n")[2]).split(":")[0]:
                result.first_reward = (str_deposit_money.split("\n")[2]).split(":")[1]

            # 锁定和确认存款
            if not u"已存入" == self.getCellText(self.tup_table, lis_row[0], 7):
                self.click(self.tup_lock_btn)
                result.message_deposit_lock = self.getText(self.tup_popup_message1)
                if self.getDisplay(self.tup_close_btn):
                    self.click(self.tup_close_btn)
                self.click(self.tup_confirm_btn)
                result.message_deposit_confirm = self.getText(self.tup_popup_message2)
                if self.getDisplay(self.tup_close_btn):
                    self.click(self.tup_close_btn)

            # 读取充值时间和交易时间
            str_deposit_time = self.getCellText(self.tup_table, lis_row[0], 11)
            result.deposit_time = (str_deposit_time.split("\n")[0]).split(":", 1)[1].strip()
            result.deal_time = (str_deposit_time.split("\n")[1]).split(":", 1)[1].strip()

            # 读取订单号
            result.order_number = self.getCellText(self.tup_table, lis_row[0], 2)
        return result
