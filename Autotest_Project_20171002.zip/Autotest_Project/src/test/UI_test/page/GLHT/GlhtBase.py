#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/7/10 19:35
# @Author  : Terry
from src.test.UI_test.page.BasePage import BasePage


class GlhtBase(BasePage):
    tup_logout = ("css", ".top>a:nth-child(2)")

    def glhtLogout(self):
        """
        管理后台用户退出登录。
        :return: 
        """
        self.click(self.tup_logout)
