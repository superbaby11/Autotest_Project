#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/7/1 10:38
# @Author  : Terry
import time

from src.test.UI_test.page.GLHT.Deposit.DepositNavigator import DepositNavigator
from src.test.UI_test.page.GLHT.FundsSetting.FundsSettingPage import FundsSettingPage
from src.test.UI_test.page.GLHT.GlhtBase import GlhtBase
from src.test.UI_test.page.GLHT.RGCT.RgctNavigator import RgctNavigator
from src.test.UI_test.page.GLHT.Withdraw.GlhtWithdrawPage import GlhtWithdrawPage


class GlhtHomePage(GlhtBase):

    # 公告管理
    tup_manage_message = ("css", ".nav>ul>li:nth-child(1) >a")
    # 游戏管理
    tup_manage_lottery = ("css", ".nav>ul>li:nth-child(2) >a")
    # 账号管理
    tup_manage_account = ("css", ".nav>ul>li:nth-child(3) >a")
    # 现金系统
    tup_manage_money = ("css", ".nav>ul>li:nth-child(4) >a")
    tup_funds_setting = ("css", ".nav>ul>li:nth-child(4)  li:nth-child(2)>a")
    tup_deposit = ("css", ".nav>ul>li:nth-child(4)  li:nth-child(4)>a")
    tup_withdraw = ("css", ".nav>ul>li:nth-child(4)  li:nth-child(5)>a")
    tup_rgct = ("css", ".nav>ul>li:nth-child(4)  li:nth-child(6)>a")


    # 优惠退佣
    tup_manage_reward = ("css", ".nav>ul>li:nth-child(5) >a")
    # 报表查询
    tup_manage_report = ("css", ".nav>ul>li:nth-child(6) >a")
    # 系统设置
    tup_manage_system = ("css", ".nav>ul>li:nth-child(7) >a")
    # 优惠活动
    tup_manage_activity = ("css", ".nav>ul>li:nth-child(8) >a")

    def gotoDepositPage(self):
        """
        跳转到管理后台的现金系统下的入款管理页面。
        :return: 
        """
        try:
            self.waitElementPresent(self.tup_manage_money)
            self.scrollIntoView(self.tup_manage_money, 2)
        except:
            self.waitElementPresent(self.tup_manage_money)
            self.scrollIntoView(self.tup_manage_money, 2)
        time.sleep(1)
        self.click(self.tup_deposit)
        return DepositNavigator(self.getDriver())

    def gotoRgctPage(self):
        """
        跳转到管理后台的现金系统下的人工线上存提页面。
        :return: 
        """
        try:
            self.waitElementPresent(self.tup_manage_money)
            self.scrollIntoView(self.tup_manage_money, 2)
        except:
            self.waitElementPresent(self.tup_manage_money)
            self.scrollIntoView(self.tup_manage_money, 2)
        time.sleep(1)
        self.click(self.tup_rgct)
        return RgctNavigator(self.getDriver())

    def gotoWithdrawPage(self):
        """
        跳转到管理后台的现金系统下的出款管理页面。
        :return: 
        """
        try:
            self.waitElementPresent(self.tup_manage_money)
            self.scrollIntoView(self.tup_manage_money, 2)
        except:
            self.waitElementPresent(self.tup_manage_money)
            self.scrollIntoView(self.tup_manage_money, 2)
        time.sleep(1)
        self.click(self.tup_withdraw)
        return GlhtWithdrawPage(self.getDriver())

    def gotoFundsSettingPage(self):
        """
        跳转到管理后台的现金系统下的出入款设定页面。
        :return: 
        """
        try:
            self.waitElementPresent(self.tup_manage_money)
            self.scrollIntoView(self.tup_manage_money, 2)
        except:
            self.waitElementPresent(self.tup_manage_money)
            self.scrollIntoView(self.tup_manage_money, 2)
        time.sleep(1)
        self.click(self.tup_funds_setting)
        return FundsSettingPage(self.getDriver())
