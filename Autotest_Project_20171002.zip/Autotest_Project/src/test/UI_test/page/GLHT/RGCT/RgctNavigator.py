#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/7/10 9:14
# @Author  : Terry
from src.test.UI_test.page.BasePage import BasePage
from src.test.UI_test.page.GLHT.RGCT.RgctDepositPage import RgctDepositPage
from src.test.UI_test.page.GLHT.RGCT.RgctTurnpointPage import RgctTurnpointPage
from src.test.UI_test.page.GLHT.RGCT.RgctWithdrawPage import RgctWithdrawPage


class RgctNavigator(BasePage):
    tup_deposit = ("css", "#Deposit_btn")
    tup_withdraw = ("css", "#Withdrawal_btn")
    tup_turn_point = ("css", "#TurnPoint_btn")

    def gotoDeposit(self):
        """
        跳转到人工线上存提的人工存入页面。
        :return: 
        """
        self.click(self.tup_deposit)
        return RgctDepositPage(self.getDriver())

    def gotoWithdraw(self):
        """
        跳转到人工线上存提的人工提出页面。
        :return: 
        """
        self.click(self.tup_withdraw)
        return RgctWithdrawPage(self.getDriver())

    def gotoTurnpoint(self):
        """
        跳转到人工线上存提的人工转点页面。
        :return: 
        """
        self.click(self.tup_turn_point)
        return RgctTurnpointPage(self.getDriver())
