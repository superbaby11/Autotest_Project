#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/7/11 10:02
# @Author  : Terry
import time

from src.test.UI_test.common.common import TestResult
from src.test.UI_test.page.GLHT.RGCT.RgctBase import RgctBase


class RgctWithdrawPage(RgctBase):
    """
    管理后台-->现金系统-->人工在线存提-->人工提出。
    """
    tup_table = ("css", "#WithdrawalTable tbody")  # 页面表格
    tup_table_account = ("css", "#withdraw_userid")  # 页面表格中的用户名
    tup_money = ("css", "#withdraw_amount")  # 提款金额输入框
    tup_bet_amount = ("css", "#bet_amount_cut")  # 扣除投注量输入框
    tup_wrong_money = ("css", "#span2")  # 金额格式错误
    tup_wrong_bet_amount = ("css", "#span3")  # '扣除投注量'格式错误
    tup_withdraw_type = ("css", "#withdrawItem")  # 提款类型
    lis_withdraw_type = [
        u"冲帐-公司入款误存 (扣点+公司支出)",
        u"手动申请出款 (扣点+公司支出)",
        u"会员负数回冲 (扣点)",
        u"扣除非法下注派彩 (扣点)",
        u"放弃存款优惠 (扣点)",
        u"其它 (扣点)",
        u"人工扣点(扣点)-解除转点锁定",
        u"人工存提-(扣)活动优惠",
        u"人工存提-(扣)紅利",
    ]
    tup_remark = ("css", "#WithdrawalTable [name=amount_memo]")  # 评论输入框
    tup_commit_btn = ("css", "#WithdrawalTable  .Deposit_input.button_a")  # 提交按钮

    def withdraw(self, testdata):
        """
        人工在线存提的正常提出流程。
        :param testdata: 
        :return: 
        """
        result = TestResult()
        self.search(testdata.username)
        self.type(self.tup_money, testdata.wmoney)
        self.type(self.tup_bet_amount, testdata.bet_amount)
        if testdata.wtype in self.lis_withdraw_type:
            self.selectByVisibleText(self.tup_withdraw_type, testdata.wtype)
        else:
            raise Exception("\nInvalid withdraw type: %s.\nShould be one of: %s."
                            % (testdata.wtype, str(self.lis_withdraw_type)))
        self.type(self.tup_remark, testdata.remark)
        self.click(self.tup_commit_btn)
        result.message_rgct_commit = self.getText(self.tup_popup_window1)
        if self.getDisplay(self.tup_close_btn):
            self.click(self.tup_close_btn)
        result.message_rgct_confirm = self.getText(self.tup_popup_window2)
        if self.getDisplay(self.tup_close_btn):
            self.click(self.tup_close_btn)
        return result

    def withdraw_no_money(self, testdata):
        """
        人工在线存提-->人工提出页面，未输入提款金额。
        :param testdata: 
        :return: 
        """
        result = TestResult()
        self.search(testdata.username)
        self.type(self.tup_money, testdata.wmoney)
        self.type(self.tup_bet_amount, testdata.bet_amount)
        if testdata.wtype in self.lis_withdraw_type:
            self.selectByVisibleText(self.tup_withdraw_type, testdata.wtype)
        else:
            raise Exception("\nInvalid withdraw type: %s.\nShould be one of: %s."
                            % (testdata.wtype, str(self.lis_withdraw_type)))
        self.type(self.tup_remark, testdata.remark)
        self.click(self.tup_commit_btn)
        result.message_rgct_no_money = self.getText(self.tup_popup_window1)
        if self.getDisplay(self.tup_close_btn):
            self.click(self.tup_close_btn)
        return result

    def withdraw_wrong_money(self, testdata):
        """
        人工在线存提-->人工提出页面，提款金额的格式错误。
        :param testdata: 
        :return: 
        """
        result = TestResult()
        self.search(testdata.username)
        self.type(self.tup_money, testdata.wmoney)
        self.click(self.tup_commit_btn)
        result.message_rgct_wrong_money = self.getText(self.tup_wrong_money)
        return result

    def withdraw_no_bet_amount(self, testdata):
        """
        人工在线存提-->人工提出页面，未输入'去除投注量'。
        :param testdata: 
        :return: 
        """
        result = TestResult()
        self.search(testdata.username)
        self.type(self.tup_money, testdata.wmoney)
        self.type(self.tup_bet_amount, testdata.bet_amount)
        if testdata.wtype in self.lis_withdraw_type:
            self.selectByVisibleText(self.tup_withdraw_type, testdata.wtype)
        else:
            raise Exception("\nInvalid withdraw type: %s.\nShould be one of: %s."
                            % (testdata.wtype, str(self.lis_withdraw_type)))
        self.type(self.tup_remark, testdata.remark)
        self.click(self.tup_commit_btn)
        result.message_rgct_no_bet_amount = self.getText(self.tup_popup_window1)
        if self.getDisplay(self.tup_close_btn):
            self.click(self.tup_close_btn)
        return result

    def withdraw_wrong_bet_amount(self, testdata):
        """
        人工在线存提-->人工提出页面，'去除投注量'的格式错误。
        :param testdata: 
        :return: 
        """
        result = TestResult()
        self.search(testdata.username)
        self.type(self.tup_money, testdata.wmoney)
        self.type(self.tup_bet_amount, testdata.bet_amount)
        self.click(self.tup_commit_btn)
        result.message_rgct_wrong_bet_amount = self.getText(self.tup_wrong_bet_amount)
        return result

    def withdraw_insufficient_money(self, testdata):
        """
        人工提款时，余额小于提出金额。
        :param testdata: 
        :return: 
        """
        result = TestResult()
        self.search(testdata.username)
        self.type(self.tup_money, testdata.wmoney)
        self.type(self.tup_bet_amount, testdata.bet_amount)
        if testdata.wtype in self.lis_withdraw_type:
            self.selectByVisibleText(self.tup_withdraw_type, testdata.wtype)
        else:
            raise Exception("\nInvalid withdraw type: %s.\nShould be one of: %s."
                            % (testdata.wtype, str(self.lis_withdraw_type)))
        self.type(self.tup_remark, testdata.remark)
        self.click(self.tup_commit_btn)
        result.message_rgct_confirm = self.getText(self.tup_popup_window1)
        if self.getDisplay(self.tup_close_btn):
            self.click(self.tup_close_btn)
        result.message_rgct_insufficient_money = self.getText(self.tup_popup_window2)
        if self.getDisplay(self.tup_close_btn):
            self.click(self.tup_close_btn)
        return result

    def withdraw_insufficient_bet_amount(self, testdata):
        """
        人工提款时，'所需投注量'小于'扣除投注量'。
        :param testdata: 
        :return: 
        """
        result = TestResult()
        self.search(testdata.username)
        self.type(self.tup_money, testdata.wmoney)
        self.type(self.tup_bet_amount, testdata.bet_amount)
        if testdata.wtype in self.lis_withdraw_type:
            self.selectByVisibleText(self.tup_withdraw_type, testdata.wtype)
        else:
            raise Exception("\nInvalid withdraw type: %s.\nShould be one of: %s."
                            % (testdata.wtype, str(self.lis_withdraw_type)))
        self.type(self.tup_remark, testdata.remark)
        self.click(self.tup_commit_btn)
        result.message_rgct_insufficient_bet_amount = self.getText(self.tup_popup_window1)
        if self.getDisplay(self.tup_close_btn):
            self.click(self.tup_close_btn)
        return result

    def withdraw_no_username(self, testdata):
        """
        人工提款，没有输入会员名就点击查询按钮。
        :return: 
        """
        result = TestResult()
        self.search('')
        result.message_rgct_no_username = self.getText(self.tup_popup_window1)
        if self.getDisplay(self.tup_close_btn):
            self.click(self.tup_close_btn)
        return result

    def withdraw_no_exist_user(self, testdata):
        """
        查询不存在的用户名。
        :return: 
        """
        result = TestResult()
        self.search(testdata.username)
        self.waitElementVisible(self.tup_table)
        time.sleep(1)
        result.sysbalance = self.getCellText(self.tup_table, 2, 1)  # 系统余额
        result.require_amount = self.getCellText(self.tup_table, 4, 1)  # 有效出款打码量
        result.current_amount = self.getCellText(self.tup_table, 3, 1)  # 当前投注量
        return result
