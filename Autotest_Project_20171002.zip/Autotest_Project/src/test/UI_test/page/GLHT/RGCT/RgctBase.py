#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/7/10 9:15
# @Author  : Terry
from src.test.UI_test.page.GLHT.GlhtBase import GlhtBase


class RgctBase(GlhtBase):
    tup_account = ("css", "#account_bar")  # 账户名输入框
    tup_search_btn = ("css", "#search_button")  # 搜索按钮
    tup_table_account = None  # 页面表格中的用户名
    tup_popup_window1 = ("css", "#ui-id-1")  # 点击提交按钮后的弹窗
    tup_popup_window2 = ("css", "#ui-id-3")  # 页面第二个弹窗
    tup_close_btn = ("css", ".zzh_qd")  # 关闭弹窗

    def search(self, account):
        """
        输入会员名，点击搜索按钮，查询会员的余额和打码量信息。
        :param account: 
        :return: 
        """
        self.type(self.tup_account, account)
        self.click(self.tup_search_btn)
        self.waitElementText(self.tup_table_account, account)
