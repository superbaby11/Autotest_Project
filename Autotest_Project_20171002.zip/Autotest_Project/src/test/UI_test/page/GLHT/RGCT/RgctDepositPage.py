#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/7/10 9:09
# @Author  : Terry
import time

from src.test.UI_test.common.common import TestResult
from src.test.UI_test.page.GLHT.RGCT.RgctBase import RgctBase


class RgctDepositPage(RgctBase):
    """
    管理后台-->现金系统-->人工在线存提-->人工存入。
    """
    tup_table = ("css", "#DepositTable>tbody")  # 页面中的表格
    tup_table_account = ("css", "#deposit_userid")  # 页面表格中的用户名
    tup_money = ("css", "#DepositTable [name=amount]")  # 充值金额输入框
    tup_bet_amount = ("css", "#bet_amount")  # 所需投注量输入框
    tup_deposit_type = ("css", "#depositItem")  # 充值类型
    lis_deposit_type = [u"人工入款 (补点+公司收入)",
                        u"冲帐-取消出款 (补点+公司收入)",
                        u"冲帐-重覆出款 (补点+公司收入)",
                        u"存款优惠 (补点)",
                        u"返点优惠 (补点)",
                        u"活动优惠 (补点)",
                        u"负数额度归零 (补点)",
                        u"其它 (补点)",
                        u"优惠补点(补点)-锁定转点功能",
                        u"人工存提-紅利"
                        ]
    tup_remark = ("css", "#DepositTable [name=amount_memo]")  # 评论输入框
    tup_confirm_btn = ("css", "#DepositTable .button_a")  # 提交按钮

    def deposit(self, testdata):
        """
        人工存入的正常流程。
        :param testdata: 
        :return: 
        """
        result = TestResult()
        self.search(testdata.username)
        self.type(self.tup_money, testdata.dmoney)
        self.type(self.tup_bet_amount, testdata.bet_amount)
        if testdata.dtype in self.lis_deposit_type:
            self.selectByVisibleText(self.tup_deposit_type, testdata.dtype)
        else:
            raise Exception("\nInvalid dtype: %s.\nShould be one of: %s."
                            % (testdata.dtype, str(self.lis_deposit_type)))
        self.type(self.tup_remark, testdata.remark)
        self.click(self.tup_confirm_btn)
        result.message_rgct_commit = self.getText(self.tup_popup_window1)
        if self.getDisplay(self.tup_close_btn):
            self.click(self.tup_close_btn)
        result.message_rgct_confirm = self.getText(self.tup_popup_window2)
        if self.getDisplay(self.tup_close_btn):
            self.click(self.tup_close_btn)
        return result

    def deposit_no_search(self, testdata):
        """
        人工存入，但没有查询会员。
        :return: 
        """
        result = TestResult()
        self.type(self.tup_money, testdata.dmoney)
        self.type(self.tup_bet_amount, testdata.bet_amount)
        if testdata.dtype in self.lis_deposit_type:
            self.selectByVisibleText(self.tup_deposit_type, testdata.dtype)
        else:
            raise Exception("\nInvalid dtype: %s.\nShould be one of: %s."
                            % (testdata.dtype, str(self.lis_deposit_type)))
        self.type(self.tup_remark, testdata.remark)
        self.click(self.tup_confirm_btn)
        result.message_rgct_no_search = self.getText(self.tup_popup_window1)
        if self.getDisplay(self.tup_close_btn):
            self.click(self.tup_close_btn)
        return result

    def deposit_no_username(self, testdata):
        """
        人工存入，没有输入会员名就查询会员。
        :param testdata: 
        :return: 
        """
        result = TestResult()
        self.search("")
        result.message_rgct_no_username = self.getText(self.tup_popup_window1)
        if self.getDisplay(self.tup_close_btn):
            self.click(self.tup_close_btn)
        return result

    def deposit_no_exist_user(self, testdata):
        """
        人工存入，查询不存在的会员。
        :param testdata: 
        :return: 
        """
        result = TestResult()
        self.search(testdata.username)
        self.waitElementVisible(self.tup_table)
        time.sleep(1)
        result.sysbalance = self.getCellText(self.tup_table, 1, 3)  # 系统余额
        result.require_amount = self.getCellText(self.tup_table, 2, 1)  # 有效出款打码量
        result.current_amount = self.getCellText(self.tup_table, 2, 3)  # 当前投注量
        return result

    def deposit_wrong_money(self, testdata):
        """
        人工存入，输入金额错误。
        :param testdata: 
        :return: 
        """
        result = TestResult()
        self.search(testdata.username)
        self.type(self.tup_money, testdata.dmoney)
        self.type(self.tup_bet_amount, testdata.bet_amount)
        if testdata.dtype in self.lis_deposit_type:
            self.selectByVisibleText(self.tup_deposit_type, testdata.dtype)
        else:
            raise Exception("\nInvalid dtype: %s.\nShould be one of: %s."
                            % (testdata.dtype, str(self.lis_deposit_type)))
        self.type(self.tup_remark, testdata.remark)
        self.click(self.tup_confirm_btn)
        result.message_rgct_no_money = self.getText(self.tup_popup_window1)
        if self.getDisplay(self.tup_close_btn):
            self.click(self.tup_close_btn)
        return result

    def deposit_no_bet_amount(self, testdata):
        """
        人工存入，投注量为空。
        :param testdata: 
        :return: 
        """
        result = TestResult()
        self.search(testdata.username)
        self.type(self.tup_money, testdata.dmoney)
        self.type(self.tup_bet_amount, testdata.bet_amount)
        if testdata.dtype in self.lis_deposit_type:
            self.selectByVisibleText(self.tup_deposit_type, testdata.dtype)
        else:
            raise Exception("\nInvalid dtype: %s.\nShould be one of: %s."
                            % (testdata.dtype, str(self.lis_deposit_type)))
        self.type(self.tup_remark, testdata.remark)
        self.click(self.tup_confirm_btn)
        result.message_rgct_no_bet_amount = self.getText(self.tup_popup_window1)
        if self.getDisplay(self.tup_close_btn):
            self.click(self.tup_close_btn)
        return result
