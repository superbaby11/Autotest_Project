#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/7/12 10:36
# @Author  : Terry
from src.test.UI_test.common.common import TestResult
from src.test.UI_test.page.GLHT.RGCT.RgctBase import RgctBase


class RgctTurnpointPage(RgctBase):
    """
    管理后台-->现金系统-->人工在线存提-->人工转点。
    """
    tup_out_account = ("css", "[name=idOut]")
    tup_in_account = ("css", "[name=idIn]")
    tup_turn_money = ("css", "#turnMoney")
    tup_commit_btn = ("css", "#turnPoint_form .Deposit_input.button_a")
    tup_popup_window1 = ("css", "[role=alert]")

    def turnpoint(self, testdata):
        """
        正常转点流程。
        :param testdata: 
        :return: 
        """
        result = TestResult()
        self.type(self.tup_out_account, testdata.username_agent)
        self.type(self.tup_in_account, testdata.username)
        self.type(self.tup_turn_money, testdata.tmoney)
        self.click(self.tup_commit_btn)
        result.message_rgct_commit = self.getText(self.tup_popup_window1)
        return result

    def turnpoint_wrong_money(self, testdata):
        """
        人工转点时，输入错误的金额。
        :param testdata: 
        :return: 
        """
        result = TestResult()
        self.type(self.tup_out_account, testdata.username_agent)
        self.type(self.tup_in_account, testdata.username)
        self.type(self.tup_turn_money, testdata.tmoney)
        self.click(self.tup_commit_btn)
        result.message_rgct_commit = self.getAlertText()
        self.acceptAlert()
        return result
