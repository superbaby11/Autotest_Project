#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/7/13 15:59
# @Author  : Terry
import time

from src.test.UI_test.common.common import TestResult
from src.test.UI_test.page.BasePage import BasePage
from src.test.UI_test.page.GLHT.GlhtBase import GlhtBase


class GlhtWithdrawPage(GlhtBase):
    """
    管理后台-->现金系统-->出款管理页面
    """
    tup_account = ("css", "[name=account]")
    tup_search_btn = ("css", "#searchBtn")
    tup_table = ("css", "#withdrawTable tbody")
    tup_lock_btn = ("css", "[name=readybtn]")
    tup_confirm_btn = ("css", "[name=confirmbtn]")
    tup_cancel_btn = ("css", "[name=cancelbtn]")
    tup_popup_window1 = ("css", "#ui-id-1")
    tup_popup_window2 = ("css", "#ui-id-3")
    tup_close_btn = ("css", ".zzh_qd")

    def search(self, testdata):
        """
        使用会员名称筛选。
        :param testdata: 
        :return: 
        """
        self.type(self.tup_account, testdata.username)
        self.click(self.tup_search_btn)
        time.sleep(1)
        self.waitElementPresent(self.tup_table)

    def confirm_withdraw(self, testdata):
        """
        使用会员名称筛选，审核通过表格第一条数据。
        :param testdata: 
        :return: 
        """
        result = TestResult()
        self.search(testdata)
        if not u'已确认' == self.getCellText(self.tup_table, 1, 10):
            self.click(self.tup_lock_btn)
            result.message_withdraw_lock = self.getText(self.tup_popup_window1)
            if self.getDisplay(self.tup_close_btn):
                self.click(self.tup_close_btn)
            self.click(self.tup_confirm_btn)
            result.message_withdraw_confirm = self.getText(self.tup_popup_window2)
            if self.getDisplay(self.tup_close_btn):
                self.click(self.tup_close_btn)
        return result

    def cancel_withdraw(self, testdata):
        """
        使用会员名称筛选，取消表格第一条数据。
        :param testdata: 
        :return: 
        """
        result = TestResult()
        self.search(testdata)
        if not u'已取消' == self.getCellText(self.tup_table, 1, 10):
            self.click(self.tup_cancel_btn)
            result.message_withdraw_cancel = self.getText(self.tup_popup_window1)
            if self.getDisplay(self.tup_close_btn):
                self.click(self.tup_close_btn)
        return result
