#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/7/1 10:37
# @Author  : Terry
from src.test.UI_test.page.BasePage import BasePage
from src.test.UI_test.page.GLHT.GlhtHomePage import GlhtHomePage
from src.utils.config import DefaultConfig_Project


class GlhtLoginPage(BasePage):

    tup_username = ("css", "#username")
    tup_password = ("css", "#password")
    tup_authnum = ("css", "#captcha")
    tup_submit = ("css", "#login_submit")

    def loginNormal(self, str_username=None, str_password=None, str_authnum='1111'):
        """
        正常登录管理后台。
        :param str_username: 管理后台用户名。
        :param str_password: 管理后台用户密码。
        :param str_authnum: 验证码。
        :return: 
        """
        if (str_username is None) and (str_password is None):
            str_username = DefaultConfig_Project().get("users", "username_back")
            str_password = DefaultConfig_Project().get("users", "password_back")
        self.type(self.tup_username, str_username)
        self.type(self.tup_password, str_password)
        if self.isVisible(self.tup_authnum):
            self.type(self.tup_authnum, str_authnum)
        self.click(self.tup_submit)
        return GlhtHomePage(self.getDriver())
