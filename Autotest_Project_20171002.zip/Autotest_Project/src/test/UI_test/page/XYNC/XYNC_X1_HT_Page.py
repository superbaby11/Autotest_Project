#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/8/18 13:49
# @Author  : Terry
from src.test.UI_test.page.XYNC.XYNCBase import XYNCBase


class XYNC_X1_HT_Page(XYNCBase):
    # 幸运农场彩种的选一玩法的红投对应的号码
    dic_bet_num = {
        1: {
            u"19": ".gd.gt11>div:nth-child(1)",
            u"20": ".gd.gt11>div:nth-child(2)",
            u"全": "[name = 'all']",
            u"大": "[name = 'big']",
            u"小": "[name = 'small']",
            u"奇": "[name = 'odd']",
            u"偶": "[name = 'even']",
            u"清": "[name = 'clean']"
        }
    }
