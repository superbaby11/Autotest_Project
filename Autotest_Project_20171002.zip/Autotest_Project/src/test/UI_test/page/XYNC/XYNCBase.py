#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/8/18 13:50
# @Author  : Terry
from src.test.UI_test.page.Widget import Widget


class XYNCBase(Widget):
    # 幸运农场彩种对应的玩法
    dic_model = {
        u"选一": {
            "locator": ("css", "#tabbar-div-s2 > span:nth-child(1) > span.content"),
            "model2": {
                u"数投": ("css", "#smalllabel_0"),
                u"红投": ("css", "#smalllabel_1")
            }
        },
        u"选二": {
            "locator": ("css", "#tabbar-div-s2 > span:nth-child(2) > span.content"),
            "model2": {
                u"任选二": ("css", "#smalllabel_0"),
                u"任选胆拖": ("css", "#smalllabel_1"),
                u"连组": ("css", "#smalllabel_2"),
                u"连组胆拖": ("css", "#smalllabel_3"),
                u"连直": ("css", "#smalllabel_4")
            }
        },
        u"选三": {
            "locator": ("css", "#tabbar-div-s2 > span:nth-child(3) > span.content"),
            "model2": {
                u"任选": ("css", "#smalllabel_0"),
                u"任选胆拖": ("css", "#smalllabel_1"),
                u"前组": ("css", "#smalllabel_2"),
                u"前组胆拖": ("css", "#smalllabel_3"),
                u"前直": ("css", "#smalllabel_4")
            }
        },
        u"选四": {
            "locator": ("css", "#tabbar-div-s2 > span:nth-child(4) > span.content"),
            "model2": {
                u"任选": ("css", "#smalllabel_0"),
                u"任选胆拖": ("css", "#smalllabel_1")
            }
        },
        u"选五": {
            "locator": ("css", "#tabbar-div-s2 > span:nth-child(5) > span.content"),
            "model2": {
                u"任选": ("css", "#smalllabel_0"),
                u"任选胆拖": ("css", "#smalllabel_1")
            }
        }
    }