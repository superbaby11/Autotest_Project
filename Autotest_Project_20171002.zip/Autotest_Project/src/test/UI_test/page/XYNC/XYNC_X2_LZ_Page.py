#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/8/18 13:49
# @Author  : Terry
from src.test.UI_test.page.XYNC.XYNCBase import XYNCBase


class XYNC_X2_LZ_Page(XYNCBase):
    # 幸运农场彩种的选二玩法的连组对应的号码
    dic_bet_num = {
        1: {
            u"01": ".gd.gt11>div:nth-child(1)",
            u"02": ".gd.gt11>div:nth-child(2)",
            u"03": ".gd.gt11>div:nth-child(3)",
            u"04": ".gd.gt11>div:nth-child(4)",
            u"05": ".gd.gt11>div:nth-child(5)",
            u"06": ".gd.gt11>div:nth-child(6)",
            u"07": ".gd.gt11>div:nth-child(7)",
            u"08": ".gd.gt11>div:nth-child(8)",
            u"09": ".gd.gt11>div:nth-child(9)",
            u"10": ".gd.gt11>div:nth-child(10)",
            u"11": ".gd.gt11>div:nth-child(11)",
            u"12": ".gd.gt11>div:nth-child(12)",
            u"13": ".gd.gt11>div:nth-child(13)",
            u"14": ".gd.gt11>div:nth-child(14)",
            u"15": ".gd.gt11>div:nth-child(15)",
            u"16": ".gd.gt11>div:nth-child(16)",
            u"17": ".gd.gt11>div:nth-child(17)",
            u"18": ".gd.gt11>div:nth-child(18)",
            u"19": ".gd.gt11>div:nth-child(19)",
            u"20": ".gd.gt11>div:nth-child(20)",
            u"全": "[name = 'all']",
            u"大": "[name = 'big']",
            u"小": "[name = 'small']",
            u"奇": "[name = 'odd']",
            u"偶": "[name = 'even']",
            u"清": "[name = 'clean']"
        }
    }
