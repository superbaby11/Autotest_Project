#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/6/15 9:53
# @Author  : Terry
from src.test.UI_test.page.PK10.PK10Base import PK10Base


class PK10_Q3_ZXDS_Page(PK10Base):
    pass
