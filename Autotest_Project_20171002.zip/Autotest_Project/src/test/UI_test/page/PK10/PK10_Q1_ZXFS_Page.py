#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/5/31 8:35
# @Author  : Terry
from src.test.UI_test.page.PK10.PK10Base import PK10Base


class PK10_Q1_ZXFS_Page(PK10Base):
    pass