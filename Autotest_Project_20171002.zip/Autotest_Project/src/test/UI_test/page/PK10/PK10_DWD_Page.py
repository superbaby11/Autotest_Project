#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/6/15 14:05
# @Author  : Terry
from src.test.UI_test.page.PK10.PK10Base import PK10Base


class PK10_DWD_Page(PK10Base):
    pass
