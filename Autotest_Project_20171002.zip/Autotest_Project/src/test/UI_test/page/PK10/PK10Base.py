#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/5/31 16:10
# @Author  : Terry
from src.test.UI_test.page.Widget import Widget


class PK10Base(Widget):
    # PK10彩种对应的玩法和投注号码
    dic_bet_num = {
        1: {
            "01": "#wei_1_01",
            "02": "#wei_1_02",
            "03": "#wei_1_03",
            "04": "#wei_1_04",
            "05": "#wei_1_05",
            "06": "#wei_1_06",
            "07": "#wei_1_07",
            "08": "#wei_1_08",
            "09": "#wei_1_09",
            "10": "#wei_1_10",
            u"全": "[name = 'all']",
            u"大": "[name = 'big']",
            u"小": "[name = 'small']",
            u"奇": "[name = 'odd']",
            u"偶": "[name = 'even']",
            u"清": "[name = 'clean']"
        },
        2: {
            "01": "#wei_2_01",
            "02": "#wei_2_02",
            "03": "#wei_2_03",
            "04": "#wei_2_04",
            "05": "#wei_2_05",
            "06": "#wei_2_06",
            "07": "#wei_2_07",
            "08": "#wei_2_08",
            "09": "#wei_2_09",
            "10": "#wei_2_10",
            u"全": "[name = 'all']",
            u"大": "[name = 'big']",
            u"小": "[name = 'small']",
            u"奇": "[name = 'odd']",
            u"偶": "[name = 'even']",
            u"清": "[name = 'clean']"
        },
        3: {
            "01": "#wei_3_01",
            "02": "#wei_3_02",
            "03": "#wei_3_03",
            "04": "#wei_3_04",
            "05": "#wei_3_05",
            "06": "#wei_3_06",
            "07": "#wei_3_07",
            "08": "#wei_3_08",
            "09": "#wei_3_09",
            "10": "#wei_3_10",
            u"全": "[name = 'all']",
            u"大": "[name = 'big']",
            u"小": "[name = 'small']",
            u"奇": "[name = 'odd']",
            u"偶": "[name = 'even']",
            u"清": "[name = 'clean']"
        },
        4: {
            "01": "#wei_4_01",
            "02": "#wei_4_02",
            "03": "#wei_4_03",
            "04": "#wei_4_04",
            "05": "#wei_4_05",
            "06": "#wei_4_06",
            "07": "#wei_4_07",
            "08": "#wei_4_08",
            "09": "#wei_4_09",
            "10": "#wei_4_10",
            u"全": "[name = 'all']",
            u"大": "[name = 'big']",
            u"小": "[name = 'small']",
            u"奇": "[name = 'odd']",
            u"偶": "[name = 'even']",
            u"清": "[name = 'clean']"
        },
        5: {
            "01": "#wei_5_01",
            "02": "#wei_5_02",
            "03": "#wei_5_03",
            "04": "#wei_5_04",
            "05": "#wei_5_05",
            "06": "#wei_5_06",
            "07": "#wei_5_07",
            "08": "#wei_5_08",
            "09": "#wei_5_09",
            "10": "#wei_5_10",
            u"全": "[name = 'all']",
            u"大": "[name = 'big']",
            u"小": "[name = 'small']",
            u"奇": "[name = 'odd']",
            u"偶": "[name = 'even']",
            u"清": "[name = 'clean']"
        },
        6: {
            "01": "#wei_6_01",
            "02": "#wei_6_02",
            "03": "#wei_6_03",
            "04": "#wei_6_04",
            "05": "#wei_6_05",
            "06": "#wei_6_06",
            "07": "#wei_6_07",
            "08": "#wei_6_08",
            "09": "#wei_6_09",
            "10": "#wei_6_10",
            u"全": "[name = 'all']",
            u"大": "[name = 'big']",
            u"小": "[name = 'small']",
            u"奇": "[name = 'odd']",
            u"偶": "[name = 'even']",
            u"清": "[name = 'clean']"
        },
        7: {
            "01": "#wei_7_01",
            "02": "#wei_7_02",
            "03": "#wei_7_03",
            "04": "#wei_7_04",
            "05": "#wei_7_05",
            "06": "#wei_7_06",
            "07": "#wei_7_07",
            "08": "#wei_7_08",
            "09": "#wei_7_09",
            "10": "#wei_7_10",
            u"全": "[name = 'all']",
            u"大": "[name = 'big']",
            u"小": "[name = 'small']",
            u"奇": "[name = 'odd']",
            u"偶": "[name = 'even']",
            u"清": "[name = 'clean']"
        },
        8: {
            "01": "#wei_8_01",
            "02": "#wei_8_02",
            "03": "#wei_8_03",
            "04": "#wei_8_04",
            "05": "#wei_8_05",
            "06": "#wei_8_06",
            "07": "#wei_8_07",
            "08": "#wei_8_08",
            "09": "#wei_8_09",
            "10": "#wei_8_10",
            u"全": "[name = 'all']",
            u"大": "[name = 'big']",
            u"小": "[name = 'small']",
            u"奇": "[name = 'odd']",
            u"偶": "[name = 'even']",
            u"清": "[name = 'clean']"
        },
        9: {
            "01": "#wei_9_01",
            "02": "#wei_9_02",
            "03": "#wei_9_03",
            "04": "#wei_9_04",
            "05": "#wei_9_05",
            "06": "#wei_9_06",
            "07": "#wei_9_07",
            "08": "#wei_9_08",
            "09": "#wei_9_09",
            "10": "#wei_9_10",
            u"全": "[name = 'all']",
            u"大": "[name = 'big']",
            u"小": "[name = 'small']",
            u"奇": "[name = 'odd']",
            u"偶": "[name = 'even']",
            u"清": "[name = 'clean']"
        },
        10: {
            "01": "#wei_10_01",
            "02": "#wei_10_02",
            "03": "#wei_10_03",
            "04": "#wei_10_04",
            "05": "#wei_10_05",
            "06": "#wei_10_06",
            "07": "#wei_10_07",
            "08": "#wei_10_08",
            "09": "#wei_10_09",
            "10": "#wei_10_10",
            u"全": "[name = 'all']",
            u"大": "[name = 'big']",
            u"小": "[name = 'small']",
            u"奇": "[name = 'odd']",
            u"偶": "[name = 'even']",
            u"清": "[name = 'clean']"
        }
    }
    dic_model = {
        u"前一": {
            "locator": ("css", "#tabbar-div-s2 > span:nth-child(1) > span.content"),
            "model2": {}
        },
        u"前二":{
            "locator": ("css", "#tabbar-div-s2 > span:nth-child(2) > span.content"),
            "model2": {
                u"直选复式": ("css", "#smalllabel_0_0"),
                u"直选单式": ("css", "#smalllabel_0_1")
            }
        },
        u"前三": {
            "locator": ("css", "#tabbar-div-s2 > span:nth-child(3) > span.content"),
            "model2": {
                u"直选复式": ("css", "#smalllabel_0_0"),
                u"直选单式": ("css", "#smalllabel_0_1")
            }
        },
        u"定位胆": {
            "locator": ("css", "#tabbar-div-s2 > span:nth-child(4) > span.content"),
            "model2": {}
        }
    }




