#!/usr/bin/env python
# coding:utf-8
# __author__ = 'Jason'
# Created on 2017年3月23日
import re
import time

from selenium.common.exceptions import TimeoutException, NoSuchElementException
from selenium.webdriver.support.select import Select
from selenium.webdriver.remote.webdriver import WebDriver
from selenium import webdriver
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.keys import Keys
from src.utils.config import DefaultConfig_Project, DefaultConfig


class BasePage(object):
    """description of class"""

    str_default_browser = DefaultConfig().browser

    def __init__(self, browser=str_default_browser):
        """
        若browser是driver类型，则直接赋值给self.driver，否则进行浏览器类型判断，生成新的driver。
        """
        if isinstance(browser, WebDriver):
            self.driver = browser
        else:
            if browser == 'firefox' or browser == 'ff':
                self.driver = webdriver.Firefox()
            elif browser == 'chrome':
                self.driver = webdriver.Chrome()
            elif browser == 'internet explorer' or browser == 'ie':
                self.driver = webdriver.Ie()
            elif browser == 'opera':
                self.driver = webdriver.Opera()
            elif browser == 'phantomjs':
                self.driver = webdriver.PhantomJS()
            elif browser == 'edge':
                self.driver = webdriver.Edge()
            else:
                raise NameError("Not Found %s browser,"
                                " You can enter 'ie', 'ff', 'opera', 'phantomjs', 'edge' or 'chrome'." % browser)

    def getDriver(self):
        """
        返回浏览器driver。
        :return: 
        """
        return self.driver

    def waitElementPresent(self, element, secs=3):
        """
        期待指定元素出现在页面上。
        :param element: element is a set with format (identifier type, value), e.g. ('id', 'username')
        :param secs: 超时时间。
        :return: 
        """
        try:
            type1 = element[0]
            if type1.lower() in ["id", "name", "class", "link_text", "xpath", "css"]:
                WebDriverWait(self.driver, secs).until(EC.presence_of_element_located(element))
            else:
                raise NameError("\nPlease enter the correct targeting elements:"
                                "'id','name','class','link_text','partial_link_text','tag_name','xpath','css'.")
        except TimeoutException:
            raise TimeoutException("\nElement locator is: %s.\nElement is not present on the page "
                                   "within %s seconds." % (str(element), secs))

    def waitAlertPresent(self, secs=3):
        """
        期待alert弹窗出现在页面上。
        :param secs: 超时时间。
        :return: 
        """
        WebDriverWait(self.driver, secs).until(EC.alert_is_present())

    def waitElementVisible(self, element, secs=3):
        """
        期待指定元素出现在页面上，并且是可见状态。
        可见状态是指，元素不仅仅是已经呈现在页面上，还要拥有大于0的宽度和高度。
        :param element: element is a set with format (identifier type, value), e.g. ('id', 'username')
        :param secs: 超时时间。
        :return: 
        """
        self.waitElementPresent(element, secs)
        try:
            type1 = element[0]
            if type1.lower() in ["id", "name", "class", "link_text", "xpath", "css"]:
                WebDriverWait(self.driver, secs).until(EC.visibility_of_element_located(element))
            else:
                raise NameError("\nPlease enter the correct targeting elements:"
                                "'id','name','class','link_text','partial_link_text','tag_name','xpath','css'.")
        except TimeoutException:
            raise TimeoutException("\nElement locator is: %s."
                                   "\nElement is not visible within %s seconds." % (str(element), secs))

    def waitElementClickable(self, element, secs=3):
        """
        期待指定元素出现在页面上，并且是可以点击的状态。
        :param element: element is a set with format (identifier type, value), e.g. ('id', 'username')
        :param secs: 超时时间。
        :return: 
        """
        self.waitElementPresent(element, secs)
        try:
            type1 = element[0]
            if type1.lower() in ["id", "name", "class", "link_text", "xpath", "css"]:
                WebDriverWait(self.driver, secs).until(EC.element_to_be_clickable(element))
            else:
                raise NameError("\nPlease enter the correct targeting elements:"
                                "'id','name','class','link_text','partial_link_text','tag_name','xpath','css'.")
        except TimeoutException:
            raise TimeoutException("\nElement locator is (%s, %s)."
                                   "\nElement is not clickable within %s seconds." % (element[0], element[1], secs))

    def waitElementText(self, element, text, secs=3):
        """
        Waiting for the text to be present in element.

        Usage:
        self.waitElementText(("name","username"),10)
        """
        try:
            type1 = element[0]
            if type1.lower() in ["id", "name", "class", "link_text", "xpath", "css"]:
                WebDriverWait(self.driver, secs).until(EC.text_to_be_present_in_element(element, text))
            else:
                raise NameError(
                    "Please enter the correct targeting elements,'id','name','class','link_text','xpath','css'.")
        except Exception:
            raise ValueError("The Text:%s not found in the element:%s" % (text, str(element)))

    def waitElementNotVisible(self, element, secs=3):
        """
        等待元素不可见或者从dom中移除。
        :param element: element is a set with format (identifier type, value), e.g. ('id', 'username')
        :param secs: 超时时间。
        :return: 
        """
        try:
            type1 = element[0]
            if type1.lower() in ["id", "name", "class", "link_text", "xpath", "css"]:
                WebDriverWait(self.driver, secs).until(EC.invisibility_of_element_located(element))
            else:
                raise NameError("\nPlease enter the correct targeting elements:"
                                "'id','name','class','link_text','partial_link_text','tag_name','xpath','css'.")
        except TimeoutException:
            raise TimeoutException("\nElement locator is: %s."
                                   "\nElement is still visible within %s seconds." % (str(element), secs))
                
    def findElement(self, element):
        """
        Find element
        element is a set with format (identifier type, value), e.g. ('id', 'username')
        Usage:
        self.findElement(element)
        """
        try:
            type1 = element[0]
            value1 = element[1]
            if type1.lower() == "id":
                elem = self.driver.find_element_by_id(value1)
            elif type1.lower() == "name":
                elem = self.driver.find_element_by_name(value1)
            elif type1.lower() == "class":
                elem = self.driver.find_element_by_class_name(value1)
            elif type1.lower() == "link_text":
                elem = self.driver.find_element_by_link_text(value1)
            elif type1.lower() == "partial_link_text":
                elem = self.driver.find_element_by_partial_link_text(value1)
            elif type1.lower() == "tag_name":
                element = self.driver.find_element_by_tag_name(value1)                
            elif type1.lower() == "xpath":
                elem = self.driver.find_element_by_xpath(value1)
            elif type1.lower() == "css":
                elem = self.driver.find_element_by_css_selector(value1)
            else:
                raise NameError("Please correct the type in function parameter")
        except Exception:
            raise ValueError("No such element found"+ str(element))
        return elem
    
    def findElements(self, element):
        """
        Find elements
        element is a set with format (identifier type, value), e.g. ('id', 'username')
        Usage:
        self.findElement(element)
        """
        try:
            type1 = element[0]
            value1 = element[1]
            if type1.lower() == "id" or type1.lower() == "i":
                elem = self.driver.find_elements_by_id(value1)
            elif type1.lower() == "name" or type1.lower() == "n":
                elem = self.driver.find_elements_by_name(value1)
            elif type1.lower() == "class" or type1.lower() == "c":
                elem = self.driver.find_elements_by_class_name(value1)
            elif type1.lower() == "link_text" or type1.lower() == "l":
                elem = self.driver.find_elements_by_link_text(value1)
            elif type1.lower() == "partial_link_text" or type1.lower() == "p":
                elem = self.driver.find_elements_by_partial_link_text(value1)
            elif type1.lower() == "tag_name" or type1.lower() == 't':
                element = self.driver.find_elements_by_tag_name(value1)                
            elif type1.lower() == "xpath" or type1.lower() == "x":
                elem = self.driver.find_elements_by_xpath(value1)
            elif type1.lower() == "css" or type1.lower() == "s":
                elem = self.driver.find_elements_by_css_selector(value1)
            else:
                raise NameError("Please correct the type in function parameter")
        except Exception:
            raise ValueError("No such element found"+ str(element))
        return elem        
    
    def open(self, url=None):
        """
        Open web url
        Usage:
        self.open(url)
        """
        self.driver.maximize_window()   # 最大化窗口
        if url is None:
            url = DefaultConfig_Project().base_url
            self.driver.get(url)
        else:
            self.driver.get(url)

    def openNewTab(self, element):
        """
        打开一个新的tab页面。因为selenium自身的限制，需要借助一个页面元素打开新的tab。
        :param element: <a>类型的页面元素，需要有href属性。
        :return: 
        """
        el = self.findElement(element)
        el.send_keys(Keys.CONTROL + Keys.RETURN)
    
    def type(self, element, text):
        """
        Operation input box.
        Usage:
        self.type(element, text)
        """
        self.scrollIntoView(element)
        el = self.findElement(element)
        el.clear()
        el.send_keys(text)

    def jsType(self, element, text):
        """
        自定义的输入操作。适用场景：原生api的send_keys无法输入的情况。
        element必须采用css定位字符串，例如("css", "css_selector")
        :param element: 
        :return: 
        """
        self.waitElementPresent(element)
        css_selector = element[1]
        # jQuery语句格式：定位元素--第几个--操作。
        # jQuery语句，点击操作
        jQuery_script = """$("%s").eq(0).val('%s')""" % (css_selector, str(text))
        self.driver.execute_script(jQuery_script)

    def clear(self, element):
        """
        Operation input box.
        Usage:
        self.clear(element)
        """
        self.waitElementVisible(element)
        el = self.findElement(element)
        el.clear()        
    
    def enter(self, element):
        """
        Keyboard: hit return
        Usage:
        self.enter(element)
        """
        el = self.findElement(element)
        el.clear()
        el.send_keys(Keys.RETURN)
        
    def click(self, element):
        """Click page element, like button, image, link, etc."""
        self.scrollIntoView(element)
        self.waitElementClickable(element)
        el = self.findElement(element)
        el.click()

    def jsClick(self, element):
        """
        自定义的点击操作。适用场景：原生api的click无法点击的情况。
        element必须采用css定位字符串，例如("css", "css_selector")
        :param element: 
        :return: 
        """
        self.waitElementPresent(element)
        css_selector = element[1]
        # jQuery语句格式：定位元素--第几个--操作。
        # jQuery语句，点击操作
        jQuery_script = """$("%s").eq(0).trigger('click')""" % css_selector
        self.driver.execute_script(jQuery_script)

    def submit(self, element):
        """
        Submit the specified form.
        Usage:
        self.submit(element)
        """
        self.waitElementVisible(element)
        el = self.findElement(element)
        el.submit()        
        
    def quit(self):
        """Quit webdriver"""
        self.driver.quit()

    def acceptAlert(self):
        """
        点击alert弹窗的ok按钮。
        :return: 
        """
        self.waitAlertPresent()
        el = self.driver.switch_to.alert
        el.accept()
        
    def getAttribute(self, element, attribute):
        """Get element attribute"""
        el = self.findElement(element)
        return el.get_attribute(attribute)
    
    def getText(self, element):
        """Get text of a web element"""
        self.waitElementVisible(element)
        el = self.findElement(element)
        return el.text

    def getAlertText(self):
        """
        返回alert弹窗的文本。
        :return: 
        """
        self.waitAlertPresent()
        el = self.driver.switch_to.alert
        return el.text
    
    def getTitle(self):
        """Get window title"""
        return self.driver.title
    
    def getCurrentUrl(self):
        """Get current url"""
        return self.driver.current_url
    
    def getScreenshot(self, targetpath):
        """Get current screenshot and save it to target path"""
        self.driver.get_screenshot_as_file(targetpath)

    def getWindowHandles(self):
        """
        返回一个列表，列表元素是所有页面的句柄。
        :return: 
        """
        return self.driver.window_handles
        
    def maximizeWindow(self):
        """Maximize current browser window"""
        self.driver.maximize_window()
        
    def setWindow(self, wide, high):
        """
        Set browser window wide and high.

        Usage:
        driver.setWindow(wide,high)
        """
        self.driver.set_window_size(wide, high)
        
    def back(self):
        """Goes one step backward in the browser history."""
        self.driver.back()
    
    def forward(self):
        """Goes one step forward in the browser history."""
        self.driver.forward()
        
    def getWindowSize(self):
        """Gets the width and height of the current window."""
        return self.driver.get_window_size()
    
    def refresh(self):
        """Refresh current page."""
        self.driver.refresh()
        
    def switch_to_window(self, window_name, second=1):
        """
        跳转到一个窗口。
        :param window_name: 指窗口的编号或者窗口名称，窗口编号从0开始计数。
        :param second: 默认等待时间。
        :return: 无返回值。
        """
        pattern = re.compile('^\d+$')
        time.sleep(second)
        if pattern.search(str(window_name)):
            self.driver.switch_to.window(self.driver.window_handles[int(window_name)])
        else:
            self.driver.switch_to.window(window_name)

    def switch_to_frame(self, element, secs=10):
        """
        在指定时间内，尝试跳转到一个frame。
        :param element:element is a set with format (identifier type, value), e.g. ('id', 'username')
        :param secs: 默认3秒后超时。
        :return: 无返回值。
        """
        self.waitElementPresent(element, secs)
        try:
            type1 = element[0]
            if type1.lower() in ["id", "name", "class", "link_text", "xpath", "css"]:
                WebDriverWait(self.driver, secs).until(EC.frame_to_be_available_and_switch_to_it(element))
            else:
                raise NameError("\nPlease enter the correct targeting elements:"
                                "'id','name','class','link_text','partial_link_text','tag_name','xpath','css'.")
        except TimeoutException:
            raise TimeoutException("\nElement locator is: %s."
                                   "\nElement is not visible within % seconds." % (str(element), secs))

    def switch_to_parent_frame(self, second=1):
        """
        从子frame切回到父frame。
        :param second: 默认等待时间。
        :return: 无返回值。
        """
        time.sleep(second)
        self.driver.switch_to.parent_frame()

    def switch_to_default_frame(self, second=1):
        """
        切到frame中之后，我们便不能继续操作主文档的元素，这时如果想操作主文档内容，则需切回主文档。
        :param second: 默认等待时间。
        :return: 无返回值。
        """
        time.sleep(second)
        self.driver.switch_to.default_content()

    def close_current_window(self):
        """
        关闭当前窗口。
        使用该方法后，会失去当前窗口的句柄，需要使用Basepage类的switch_to_window方法跳转到一个窗口，以获得当前窗口句柄。
        否则，将无法继续操作。
        :return: 
        """
        self.driver.close()
    
    def getDisplay(self, element):
        """
        Gets the element to display,The return result is true or false.

        Usage:
        driver.get_display("i,el")
        """
        self.waitElementPresent(element)
        el = self.findElement(element)
        return el.is_displayed()
        
    def isSelected(self, element):
        el = self.findElement(element)
        return el.is_selected()

    def isExist(self, element):
        """
        当前页面存在某个元素，返回True，否则，返回False。
        :param element: element is a set with format (identifier type, value), e.g. ('id', 'username')
        :return: 
        """
        try:
            self.findElement(element)
            return True
        except NoSuchElementException:
            return False

    def isVisible(self, element):
        """
        页面存在某个元素，并且可见，返回True，否则返回False.
        :param element: 
        :return: 
        """
        try:
            self.waitElementVisible(element, 1)
            return True
        except TimeoutException:
            pass
            return False

    def selectByVisibleText(self, element, text):
        """
        根据显示的文本，选择下拉框。
        :param element: element is a set with format (identifier type, value), e.g. ('id', 'username')
        :param text: 下拉框的条目显示的文本。
        :return: 无返回值。
        """
        self.waitElementVisible(element)
        el = self.findElement(element)
        select_e1 = Select(el)
        select_e1.select_by_visible_text(text)

    def getCellText(self, element, int_row, int_column):
        """
        从一个表格中读取某个单元格的文本。
        :param element: <tbody>元素的地址。
        :param int_row: 行编号，从0开始。
        :param int_column: 列编号，从0开始。
        :param second: 获取文本前的等待时间。
        :return: 返回单元格的文本。
        """
        int_row = int(int_row)
        int_column = int(int_column)
        self.waitElementVisible(element)
        e1 = self.findElement(element)
        lis_tr = e1.find_elements_by_tag_name("tr")
        if 0 == len(lis_tr):
            raise Exception("\nEmpty table! There is no rows in the table.")
        if 0 <= int_row < len(lis_tr):
            lis_td = lis_tr[int_row].find_elements_by_tag_name("td")
            if 0 <= int_column < len(lis_td):
                return lis_td[int_column].text
            else:
                raise Exception("\nInvalid column num: %s.\nThe max column num is: %s." % (int_column, len(lis_td)))
        else:
            raise Exception("\nInvalid row num: %s.\nThe max row num is: %s." % (int_row, len(lis_tr)))

    def clickCell(self, element, int_row, int_column):
        """
        点击一个表格中的某个单元格。
        :param element: <tbody>元素的地址。
        :param int_row: 行编号，从0开始。
        :param int_column: 列编号，从0开始。
        :return: 无返回值。
        """
        int_row = int(int_row)
        int_column = int(int_column)
        self.waitElementVisible(element)
        e1 = self.findElement(element)
        lis_tr = e1.find_elements_by_tag_name("tr")
        if 0 <= int_row < len(lis_tr):
            lis_td = lis_tr[int_row].find_elements_by_tag_name("td")
            if 0 <= int_column < len(lis_td):
                cell = lis_td[int_column]
                chain = ActionChains(self.driver)
                chain.move_to_element(cell)
                chain.click()
                chain.perform()
            else:
                raise Exception("\nInvalid column num: %s.\nThe max column num is: %s." % (int_column, len(lis_td)))
        else:
            raise Exception("\nInvalid row num: %s.\nThe max row num is: %s." % (int_row, len(lis_tr)))

    def getLocation(self, element):
        """
        返回元素的坐标。
        :param element: element is a set with format (identifier type, value), e.g. ('id', 'username')
        :return: 
        """
        self.waitElementVisible(element)
        el = self.findElement(element)
        return el.location

    def getSize(self, element):
        """
        返回元素的长度和宽度。
        :param element: element is a set with format (identifier type, value), e.g. ('id', 'username')
        :return: 
        """
        self.scrollIntoView(element)
        el = self.findElement(element)
        return el.size

    def scrollIntoView(self, element, secs=1):
        """
        滚动页面，直到页面元素移到视野内。
        :param element: 
        :param element: 
        :return: 
        """
        time.sleep(secs)
        el = self.findElement(element)
        actions = ActionChains(self.driver)
        actions.move_to_element(el)
        actions.perform()

    def scrollBy(self, x, y):
        """
        移动到指定的坐标(相对当前的坐标移动)
        例如，driver.execute_script("window.scrollBy(0, 100)")
        已经在chrome和Firefox浏览器上测试过。
        :return: 
        """
        str_js_script = "window.scrollBy(%d, %d)" % (int(x), int(y))
        self.driver.execute_script(str_js_script)

    def scrollToBottom(self):
        """
        移动到页面最底部。
        已经在chrome和Firefox浏览器上测试过。
        :return: 
        """
        str_js_script = "window.scrollTo(0, document.body.scrollHeight)"
        self.driver.execute_script(str_js_script)

    def scrollToTop(self):
        """
        移动到页面最顶部。
        已经在chrome和Firefox浏览器上测试过。
        :return: 
        """
        str_js_script = "window.scrollTo(0, 0)"
        self.driver.execute_script(str_js_script)

    def scrollToElement(self, element, top=True):
        """
        移动到元素element的“顶端”与当前窗口的“顶部”对齐
        已经在chrome和Firefox浏览器测试过。
        driver.execute_script("arguments[0].scrollIntoView(true);", el)
        移动到元素element对象的“底端”与当前窗口的“底部”对齐
        driver.execute_script("arguments[0].scrollIntoView(false);", el)
        :param element: element is a set with format (identifier type, value), e.g. ('id', 'username')
        :param top: top为True时，将元素移动到窗口的顶部；否则，移动到窗口底部。
        :return: 
        """
        self.waitElementVisible(element)
        el = self.findElement(element)
        if top:
            self.driver.execute_script("arguments[0].scrollIntoView(true);", el)
        else:
            self.driver.execute_script("arguments[0].scrollIntoView(false);", el)

    def scrollVerticalDragger(self, path, dragger, top=True):
        """
        拖动垂直方向的滚动条到顶端或底部。
        :param path: 滚动条轨道的地址("css", "#mCSB_1_scrollbar_vertical")
        :param dragger: 滚动条的地址，例如("css", ".mCSB_dragger_bar")
        :param top: top=True时，拖动滚动条到轨道顶端；否则，底部。
        :return: 
        """
        el_path = self.findElement(path)
        el_dragger = self.findElement(dragger)
        location_path = el_path.location
        location_dragger = el_dragger.location
        size_path = el_path.size
        size_dragger = el_dragger.size

        chain = ActionChains(self.getDriver())
        chain.move_to_element(el_dragger)
        chain.click_and_hold(el_dragger)
        if top:
            y_offset = location_path["y"] - location_dragger["y"]
        else:
            y_offset = (location_path["y"] + size_path["height"]) - (location_dragger["y"] + size_dragger["height"])
        chain.move_by_offset(0, y_offset)
        chain.release()
        chain.perform()



        
if __name__ == "__main__":
    driver1 = BasePage("ff")
#     driver.open("http://500vip.hqu29zoq.com/")
#     driver.open("http://lotf.jwoquxoc.com/")
    driver1.open()
    element1 = ('name', 'username')
    b = driver1.findElement(("name", "username"))
    driver1.type(("name", "username"), 'jtest')
    driver1.type(('name', 'passwd'), 'j12345')
    driver1.type(('id', 'authnum'), '1111')
    driver1.click(('name', 'login'))
    time.sleep(2)
    driver1.click(('xpath', '//*[@id="header_user"]/div/span[5]/a[6]'))
    time.sleep(3)
    driver1.quit()
