#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/8/1 16:39
# @Author  : Terry
from src.test.UI_test.page.CQSSC.CQSSCBase import CQSSCBase


class CQSSC_Q3_TSH_Page(CQSSCBase):
    # 重庆时时彩前3特殊号对应的号码
    dic_bet_num = {
        1: {
            u"豹子": "#wei__豹子",
            u"顺子": "#wei__顺子",
            u"对子": "#wei__对子"
        }
    }