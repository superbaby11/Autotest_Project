#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/6/15 14:05
# @Author  : Terry
from src.test.UI_test.page.CQSSC.CQSSCBase import CQSSCBase


class CQSSC_DWD_Page(CQSSCBase):
    # 重庆时时彩定位胆
    dic_bet_num = {
        1: {
            "0": "#wei_1_0",
            "1": "#wei_1_1",
            "2": "#wei_1_2",
            "3": "#wei_1_3",
            "4": "#wei_1_4",
            "5": "#wei_1_5",
            "6": "#wei_1_6",
            "7": "#wei_1_7",
            "8": "#wei_1_8",
            "9": "#wei_1_9",
            u"全": "[name = 'all']",
            u"大": "[name = 'big']",
            u"小": "[name = 'small']",
            u"奇": "[name = 'odd']",
            u"偶": "[name = 'even']",
            u"清": "[name = 'clean']"
        },
        2: {
            "0": "#wei_2_0",
            "1": "#wei_2_1",
            "2": "#wei_2_2",
            "3": "#wei_2_3",
            "4": "#wei_2_4",
            "5": "#wei_2_5",
            "6": "#wei_2_6",
            "7": "#wei_2_7",
            "8": "#wei_2_8",
            "9": "#wei_2_9",
            u"全": "[name = 'all']",
            u"大": "[name = 'big']",
            u"小": "[name = 'small']",
            u"奇": "[name = 'odd']",
            u"偶": "[name = 'even']",
            u"清": "[name = 'clean']"
        },
        3: {
            "0": "#wei_3_0",
            "1": "#wei_3_1",
            "2": "#wei_3_2",
            "3": "#wei_3_3",
            "4": "#wei_3_4",
            "5": "#wei_3_5",
            "6": "#wei_3_6",
            "7": "#wei_3_7",
            "8": "#wei_3_8",
            "9": "#wei_3_9",
            u"全": "[name = 'all']",
            u"大": "[name = 'big']",
            u"小": "[name = 'small']",
            u"奇": "[name = 'odd']",
            u"偶": "[name = 'even']",
            u"清": "[name = 'clean']"
        },
        4: {
            "0": "#wei_4_0",
            "1": "#wei_4_1",
            "2": "#wei_4_2",
            "3": "#wei_4_3",
            "4": "#wei_4_4",
            "5": "#wei_4_5",
            "6": "#wei_4_6",
            "7": "#wei_4_7",
            "8": "#wei_4_8",
            "9": "#wei_4_9",
            u"全": "[name = 'all']",
            u"大": "[name = 'big']",
            u"小": "[name = 'small']",
            u"奇": "[name = 'odd']",
            u"偶": "[name = 'even']",
            u"清": "[name = 'clean']"
        },
        5: {
            "0": "#wei_5_0",
            "1": "#wei_5_1",
            "2": "#wei_5_2",
            "3": "#wei_5_3",
            "4": "#wei_5_4",
            "5": "#wei_5_5",
            "6": "#wei_5_6",
            "7": "#wei_5_7",
            "8": "#wei_5_8",
            "9": "#wei_5_9",
            u"全": "[name = 'all']",
            u"大": "[name = 'big']",
            u"小": "[name = 'small']",
            u"奇": "[name = 'odd']",
            u"偶": "[name = 'even']",
            u"清": "[name = 'clean']"
        }
    }
