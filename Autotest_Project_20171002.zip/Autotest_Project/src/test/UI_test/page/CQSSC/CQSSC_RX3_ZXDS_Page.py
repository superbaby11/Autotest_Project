#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/8/2 15:56
# @Author  : Terry
from src.test.UI_test.page.CQSSC.CQSSCBase import CQSSCBase


class CQSSC_RX3_ZXDS_Page(CQSSCBase):
    pass
