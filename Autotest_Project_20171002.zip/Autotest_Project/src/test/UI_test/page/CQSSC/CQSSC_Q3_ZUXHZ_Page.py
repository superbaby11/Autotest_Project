#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/8/1 13:42
# @Author  : Terry
from src.test.UI_test.page.CQSSC.CQSSCBase import CQSSCBase


class CQSSC_Q3_ZUXHZ_Page(CQSSCBase):
    # 重庆时时彩前3组选和值对应的号码
    dic_bet_num = {
        1: {
            u"1": "#wei__1",
            u"2": "#wei__2",
            u"3": "#wei__3",
            u"4": "#wei__4",
            u"5": "#wei__5",
            u"6": "#wei__6",
            u"7": "#wei__7",
            u"8": "#wei__8",
            u"9": "#wei__9",
            u"10": "#wei__10",
            u"11": "#wei__11",
            u"12": "#wei__12",
            u"13": "#wei__13"
        },
        2: {
            u"14": "#wei__14",
            u"15": "#wei__15",
            u"16": "#wei__16",
            u"17": "#wei__17",
            u"18": "#wei__18",
            u"19": "#wei__19",
            u"20": "#wei__20",
            u"21": "#wei__21",
            u"22": "#wei__22",
            u"23": "#wei__23",
            u"24": "#wei__24",
            u"25": "#wei__25",
            u"26": "#wei__26"
        }
    }
