#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/8/1 16:39
# @Author  : Terry
from src.test.UI_test.page.CQSSC.CQSSCBase import CQSSCBase


class CQSSC_H2_DXDS_Page(CQSSCBase):
    # 重庆时时彩后2大小单双对应的号码
    dic_bet_num = {
        1: {
            u"大": ".gd>div:nth-child(1)",
            u"小": ".gd>div:nth-child(2)",
            u"单": ".gd>div:nth-child(3)",
            u"双": ".gd>div:nth-child(4)"
        },
        2: {
            u"大": ".gd>div:nth-child(1)",
            u"小": ".gd>div:nth-child(2)",
            u"单": ".gd>div:nth-child(3)",
            u"双": ".gd>div:nth-child(4)"
        }
    }
