#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/6/20 15:36
# @Author  : Terry
from src.test.UI_test.page.CQSSC.CQSSCBase import CQSSCBase


class CQSSC_WX_ZXDS_Page(CQSSCBase):
    pass
