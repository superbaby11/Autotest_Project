#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/6/22 10:20
# @Author  : Terry
from src.test.UI_test.page.CQSSC.CQSSCBase import CQSSCBase


class CQSSC_RX3_HHZX_Page(CQSSCBase):
    pass
