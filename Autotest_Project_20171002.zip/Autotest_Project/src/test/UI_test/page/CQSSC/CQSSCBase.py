#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/6/20 10:51
# @Author  : Terry
from src.test.UI_test.page.Widget import Widget


class CQSSCBase(Widget):
    # 重庆时时彩对应的玩法
    dic_model = {
        u"五星": {
            "locator": ("css", "#tabbar-div-s2 > span:nth-child(1) > span.content"),
            "model2": {
                u"直选复式": ("css", "#smalllabel_0_0"),
                u"直选单式": ("css", "#smalllabel_0_1")
            }
        },
        u"四星": {
            "locator": ("css", "#tabbar-div-s2 > span:nth-child(2) > span.content"),
            "model2": {
                u"直选复式": ("css", "#smalllabel_0_0"),
                u"直选单式": ("css", "#smalllabel_0_1")
            }
        },
        u"后三": {
            "locator": ("css", "#tabbar-div-s2 > span:nth-child(3) > span.content"),
            "model2": {
                u"直选复式": ("css", "#smalllabel_0_0"),
                u"直选单式": ("css", "#smalllabel_0_1"),
                u"后三组合": ("css", "#smalllabel_0_2"),
                u"直选和值": ("css", "#smalllabel_0_3"),
                u"直选跨度": ("css", "#smalllabel_0_4"),
                u"组三复式": ("css", "#smalllabel_1_0"),
                u"组三单式": ("css", "#smalllabel_1_1"),
                u"组六复式": ("css", "#smalllabel_1_2"),
                u"组六单式": ("css", "#smalllabel_1_3"),
                u"混合组选": ("css", "#smalllabel_1_4"),
                u"组选和值": ("css", "#smalllabel_1_5"),
                u"组选包胆": ("css", "#smalllabel_1_6"),
                u"和值尾数": ("css", "#smalllabel_2_0"),
                u"特殊号": ("css", "#smalllabel_2_1"),
            }
        },
        u"前三": {
            "locator": ("css", "#tabbar-div-s2 > span:nth-child(4) > span.content"),
            "model2": {
                u"直选复式": ("css", "#smalllabel_0_0"),
                u"直选单式": ("css", "#smalllabel_0_1"),
                u"前三组合": ("css", "#smalllabel_0_2"),
                u"直选和值": ("css", "#smalllabel_0_3"),
                u"直选跨度": ("css", "#smalllabel_0_4"),
                u"组三复式": ("css", "#smalllabel_1_0"),
                u"组三单式": ("css", "#smalllabel_1_1"),
                u"组六复式": ("css", "#smalllabel_1_2"),
                u"组六单式": ("css", "#smalllabel_1_3"),
                u"混合组选": ("css", "#smalllabel_1_4"),
                u"组选和值": ("css", "#smalllabel_1_5"),
                u"组选包胆": ("css", "#smalllabel_1_6"),
                u"和值尾数": ("css", "#smalllabel_2_0"),
                u"特殊号": ("css", "#smalllabel_2_1"),
            }
        },
        u"前二": {
            "locator": ("css", "#tabbar-div-s2 > span:nth-child(5) > span.content"),
            "model2": {
                u"直选复式": ("css", "#smalllabel_0_0"),
                u"直选单式": ("css", "#smalllabel_0_1"),
                u"直选和值": ("css", "#smalllabel_0_2"),
                u"直选跨度": ("css", "#smalllabel_0_3"),
                u"组选复式": ("css", "#smalllabel_1_0"),
                u"组选单式": ("css", "#smalllabel_1_1"),
                u"组选和值": ("css", "#smalllabel_1_2"),
                u"组选包胆": ("css", "#smalllabel_1_3")
            }
        },
        u"定位胆": {
            "locator": ("css", "#tabbar-div-s2 > span:nth-child(6) > span.content"),
            "model2": {}
        },
        u"不定位": {
            "locator": ("css", "#tabbar-div-s2 > span:nth-child(7) > span.content"),
            "model2": {
                u"前三一码": ("css", "#smalllabel_0_0"),
                u"前三二码": ("css", "#smalllabel_0_1"),
                u"后三一码": ("css", "#smalllabel_0_2"),
                u"后三二码": ("css", "#smalllabel_0_3"),
                u"前四一码": ("css", "#smalllabel_1_0"),
                u"前四二码": ("css", "#smalllabel_1_1"),
                u"后四一码": ("css", "#smalllabel_1_2"),
                u"后四二码": ("css", "#smalllabel_1_3"),
                u"五星一码": ("css", "#smalllabel_2_0"),
                u"五星二码": ("css", "#smalllabel_2_1"),
                u"五星三码": ("css", "#smalllabel_2_2")
            }
        },
        u"大小单双": {
            "locator": ("css", "#tabbar-div-s2 > span:nth-child(8) > span.content"),
            "model2": {
                u"前二大小单双": ("css", "#smalllabel_0_0"),
                u"后二大小单双": ("css", "#smalllabel_0_1"),
                u"前三大小单双": ("css", "#smalllabel_0_2"),
                u"后三大小单双": ("css", "#smalllabel_0_3")
            }
        },
        u"任选二": {
            "locator": ("css", "#tabbar-div-s2 > span:nth-child(10) > span.content"),
            "model2": {
                u"直选复式": ("css", "#smalllabel_0_0"),
                u"直选单式": ("css", "#smalllabel_0_1"),
                u"直选和值": ("css", "#smalllabel_0_2"),
                u"组选复式": ("css", "#smalllabel_1_0"),
                u"组选单式": ("css", "#smalllabel_1_1"),
                u"组选和值": ("css", "#smalllabel_1_2")
            }
        },
        u"任选三": {
            "locator": ("css", "#tabbar-div-s2 > span:nth-child(11) > span.content"),
            "model2": {
                u"直选复式": ("css", "#smalllabel_0_0"),
                u"直选单式": ("css", "#smalllabel_0_1"),
                u"直选和值": ("css", "#smalllabel_0_2"),
                u"组三复式": ("css", "#smalllabel_1_0"),
                u"组三单式": ("css", "#smalllabel_1_1"),
                u"组六复式": ("css", "#smalllabel_1_2"),
                u"组六单式": ("css", "#smalllabel_1_3"),
                u"混合组选": ("css", "#smalllabel_1_4"),
                u"组选和值": ("css", "#smalllabel_1_5")
            }
        },
        u"任选四": {
            "locator": ("css", "#tabbar-div-s2 > span:nth-child(12) > span.content"),
            "model2": {
                u"直选复式": ("css", "#smalllabel_0_0"),
                u"直选单式": ("css", "#smalllabel_0_1"),
                u"组选24": ("css", "#smalllabel_1_0"),
                u"组选12": ("css", "#smalllabel_1_1"),
                u"组选6": ("css", "#smalllabel_1_2"),
                u"组选4": ("css", "#smalllabel_1_3")
            }
        }
    }

    tup_renxuan = ("css", "[title='点击切换']")

    def _gotomodel1(self, str_model1):
        """
        跳转到大玩法，例如前一，前二，前三。
        :param str_model1: 
        :return: 
        """
        if self.dic_model:
            if str_model1 in self.dic_model.keys():
                self.switch_to_default_frame()
                # 任选玩法有别于其它玩法的彩种--大玩法--小玩法的这种三级结构
                # 任选玩法是彩种--任选--大玩法--小玩法的四级结构
                # 所以任选玩法多一次点击
                self.waitElementVisible(self.tup_iframe)
                self.switch_to_frame(self.tup_iframe)
                if u"任选" in str_model1:
                    self.click(self.tup_renxuan)
                str_model1_locator = self.dic_model[str_model1]["locator"]
                self.waitElementVisible(str_model1_locator)
                self.click(str_model1_locator)
        else:
            raise Exception('\nPlease check data self.dic_model, which should not be empty!')