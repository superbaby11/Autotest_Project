#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/8/1 14:55
# @Author  : Terry
from src.test.UI_test.page.CQSSC.CQSSCBase import CQSSCBase


class CQSSC_H3_ZXBD_Page(CQSSCBase):
    # 重庆时时彩后3组选包胆对应的号码
    dic_bet_num = {
        1: {
            u"0": "#wei__0",
            u"1": "#wei__1",
            u"2": "#wei__2",
            u"3": "#wei__3",
            u"4": "#wei__4",
            u"5": "#wei__5",
            u"6": "#wei__6",
            u"7": "#wei__7",
            u"8": "#wei__8",
            u"9": "#wei__9"
        }
    }