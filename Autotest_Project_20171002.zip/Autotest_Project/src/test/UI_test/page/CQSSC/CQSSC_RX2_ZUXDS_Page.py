#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/6/22 10:15
# @Author  : Terry
from src.test.UI_test.page.CQSSC.CQSSCBase import CQSSCBase


class CQSSC_RX2_ZUXDS_Page(CQSSCBase):
    pass
