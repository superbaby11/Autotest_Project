#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/6/15 14:05
# @Author  : Terry
from src.test.UI_test.page.CQSSC.CQSSCBase import CQSSCBase


class CQSSC_BDW_HS2M_Page(CQSSCBase):
    # 重庆时时彩不定位--后三二码
    dic_bet_num = {
        1: {
            "0": "#wei__0",
            "1": "#wei__1",
            "2": "#wei__2",
            "3": "#wei__3",
            "4": "#wei__4",
            "5": "#wei__5",
            "6": "#wei__6",
            "7": "#wei__7",
            "8": "#wei__8",
            "9": "#wei__9",
            u"全": "[name = 'all']",
            u"大": "[name = 'big']",
            u"小": "[name = 'small']",
            u"奇": "[name = 'odd']",
            u"偶": "[name = 'even']",
            u"清": "[name = 'clean']"
        }
    }
