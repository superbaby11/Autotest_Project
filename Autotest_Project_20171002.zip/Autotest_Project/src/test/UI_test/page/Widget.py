#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/5/31 13:27
# @Author  : Terry
import os
import time
from selenium.common.exceptions import NoSuchElementException, TimeoutException
from selenium.webdriver import ActionChains

from src.test.UI_test.common.common import TestResult
from src.test.UI_test.page.BasePage import BasePage
from src.test.UI_test.page.Manage.DealRecord.BetRecordPage import BetRecordPage


class Widget(BasePage):
    # 页面滚动条
    tup_path = ("css", "#mCSB_1_scrollbar_vertical")
    tup_dragger = ("css", ".mCSB_dragger_bar")

    # 不同彩种对应的iframe、玩法和投注号码
    tup_iframe = ("css", "iframe#iframe2")
    dic_bet_num = {}
    dic_model = {}

    # 下注记录
    tup_bet_detail = ("css", "#header_user > div.user-center > ul > li:nth-child(2)")

    # 当前期数
    tup_current_issue = ("css", "#current_issue")

    # 剩余开局时间
    tup_hour1 = ("css", ".leaveh-1>span")
    tup_hour2 = ("css", ".leaveh-2>span")
    tup_minute1 = ("css", ".leavem-1>span")
    tup_minute2 = ("css", ".leavem-2>span")
    tup_second1 = ("css", ".leaves-1>span")

    # 投注区域
    lis_bet_selector = [
        ("css", "#lt_selector>div.gds:nth-child(1)"),
        ("css", "#lt_selector>div.gds:nth-child(2)"),
        ("css", "#lt_selector>div.gds:nth-child(3)"),
        ("css", "#lt_selector>div.gds:nth-child(4)"),
        ("css", "#lt_selector>div.gds:nth-child(5)"),
        ("css", "#lt_selector>div.gds:nth-child(6)"),
        ("css", "#lt_selector>div.gds:nth-child(7)"),
        ("css", "#lt_selector>div.gds:nth-child(8)"),
        ("css", "#lt_selector>div.gds:nth-child(9)"),
        ("css", "#lt_selector>div.gds:nth-child(10)")
    ]  # 选号区域(冠军、亚军、季军等)
    tup_money = ("css", "#lt_sel_times")  # 单注额
    tup_current_unit_yuan = ("css", ".choose-money li:nth-child(1)")  # 投注时的货币单位：元
    tup_current_unit_jiao = ("css", ".choose-money li:nth-child(2)")
    tup_current_unit_fen = ("css", ".choose-money li:nth-child(3)")
    tup_add_button = ("css", "#lt_sel_insert")  # 添加注单按钮
    tup_buy_button = ("css", "#lt_buy")  # 确认投注按钮
    tup_popup_message1 = ("css", ".mdl>table>tbody>tr>td>h4")
    tup_confirm_button = ("css", "#confirm_yes")  # 正常流程弹窗的确认按钮
    tup_alert_close_button = ("css", "#alert_close_button")  # 异常流程弹窗的确认按钮
    tup_clean = ("css", "#lt_cf_clear")  # 删除全部注单按钮
    tup_clean_one = ("css", "#lt_cf_content tr:nth-child(1) .c")  # 删除一个注单按钮
    tup_popup_message2 = ("css", ".mdl>table>tbody>tr:nth-child(1)>td")
    tup_popup_message4 = ("css", ".mdl>table>tbody>tr:nth-child(1)>td>div")
    tup_point = ("css", "#mySlider")  # 返水
    flo_max_point = 13.0  # 最大返水百分比
    tup_randomone = ("css", "#lt_random_one")  # 随机一注
    tup_randomfive = ("css", "#lt_random_five")  # 随机五注

    # 直选单式
    tup_remove_duplication = ("css", "#lt_write_del")  # 删除重复号按钮
    tup_upload_file = ("css", "#lt_write_import")  # 导入文件按钮
    tup_empty_input = ("css", "#lt_write_empty")  # 清空按钮
    tup_input_box = ("css", "#lt_write_box")  # 号码输入框
    tup_upload_browse = ("css", "#block_ajaxUploadFile")  # 浏览文件按钮
    tup_upload_confirm = ("css", u"input[value='载入文件']")  # 确认上传按钮
    tup_upload_succeed = ("css", u"[value='完成']")  # 上传成功按钮
    tup_popup_message3 = ("css", "#block_ajaxUploading")

    # 追号
    tup_on_off = ("css", "label[for='lt_trace_if']")
    tup_term = ("css", "#lt_trace_count_input")
    tup_total_money = ("css", "#lt_trace_hmoney")
    tup_same_times = ("css", "#tab02 #lt_sametime")
    tup_time1 = ("css", "#lt_trace_times_same")
    tup_diff_times = ("css", "#tab02 #lt_difftime")
    tup_skip = ("css", "#lt_trace_diff")
    tup_time2 = ("css", "#lt_trace_times_diff")

    # 投注记录表格
    tup_bet_record = ("css", "#projectlist")
    tup_revert_button = ("css", "#ched")
    tup_page_record_count = ("css", "#pageRecordCount")

    # 以下为投注的步骤
    def bet(self, int_selector_index, lis_bet_num):
        """
        在指定区域选择一组号码，这组号码将用作投注号码。
        :param int_selector_index: 选择区域的编号，从0开始。
        :param lis_bet_num: 投注号码。
        :return: 
        """
        if lis_bet_num:
            for i in range(len(lis_bet_num)):
                self._bet(int_selector_index, lis_bet_num[i])
        else:
            raise Exception("\nBet number can not be empty!")

    def _bet(self, int_selector_index, str_bet_num):
        """
        在指定区域选择一个号码，这个号码将用作投注号码。
        :param int_selector_index: 选择区域的编号，从0开始。
        :param str_bet_num: 投注号码。
        :return: 
        """
        el_bet_selector = self.findElement(self.lis_bet_selector[int_selector_index])
        if str_bet_num in self.dic_bet_num[int_selector_index+1].keys():
            try:
                el_bet_num = \
                    el_bet_selector.find_element_by_css_selector(self.dic_bet_num[int_selector_index+1][str_bet_num])
            except:
                raise NoSuchElementException("Invalid element locator of codes: %s."
                                             % str(self.dic_bet_num[int_selector_index+1][str_bet_num]))
            chain = ActionChains(self.getDriver())
            chain.move_to_element(el_bet_num)
            chain.click()
            chain.perform()
        else:
            str_valid_num = ", ".join(self.dic_bet_num[1].keys())
            raise KeyError(u"\nInvalid key: %s\nValid keys are: %s" % (str_bet_num, str_valid_num))

    def upLoadFile(self, str_filename):
        """
        上传投注号码文件。
        :param str_filename:文件名称，包含路径。 
        :return: 
        """
        dic_result = {}
        self.click(self.tup_upload_file)
        self.waitElementVisible(self.tup_upload_browse)
        # FileUpload(self.getDriver(), self.findElement(self.tup_upload_browse)).upload_by_win32(str_filename)
        # 不点击浏览按钮，直接在input控件中输入文件路径，这样可以避免出现与操作系统相关的弹窗。
        self.type(self.tup_upload_browse, str_filename)
        self.waitElementVisible(self.tup_upload_confirm)
        if self.getDisplay(self.tup_upload_confirm):
            self.click(self.tup_upload_confirm)
        self.waitElementVisible(self.tup_upload_succeed)
        self.waitElementVisible(self.tup_popup_message3)
        dic_result["popup_message1"] = self.getText(self.tup_popup_message3)
        if self.getDisplay(self.tup_upload_succeed):
            self.click(self.tup_upload_succeed)
        try:
            self.waitElementVisible(self.tup_popup_message2)
            dic_result["popup_message2"] = self.getText(self.tup_popup_message2)
            if self.getDisplay(self.tup_alert_close_button):
                self.click(self.tup_alert_close_button)
        except TimeoutException:
            pass
        return dic_result

    def gotoBetRecordPage(self):
        """
        跳转到投注记录页面。
        :return: 
        """
        self.switch_to_default_frame()
        self.waitElementVisible(self.tup_bet_detail)
        self.click(self.tup_bet_detail)
        self.switch_to_window(2)
        self.maximizeWindow()
        return BetRecordPage(self.getDriver())

    def setPoint(self, flo_percent=0):
        """
        设置返水百分比。
        :return: 
        """
        flo_percent = float(flo_percent)
        dic_size = self.getSize(self.tup_point)
        el = self.findElement(self.tup_point)
        # 计算返水点数对应的拖动条位置
        xoffset = (flo_percent / self.flo_max_point) * float(dic_size["width"])
        # 将鼠标移动到返水拖动条最左端
        chain = ActionChains(self.getDriver())
        chain.move_to_element(el)
        time.sleep(1)
        chain.move_by_offset(-dic_size["width"]/2, 0)
        # 将鼠标移动到目标位置
        chain.move_by_offset(xoffset, 0)
        chain.click()
        chain.perform()

    def waitOpening(self, second=40):
        """
        如果剩余的开局时间在20秒以内，那么等待40秒再进行投注。
        :return: 
        """
        int_hour1 = int(self.getText(self.tup_hour1))
        int_hour2 = int(self.getText(self.tup_hour2))
        if 0 == int_hour1 and 0 == int_hour2:
            int_minute1 = int(self.getText(self.tup_minute1))
            int_minute2 = int(self.getText(self.tup_minute2))
            if 0 == int_minute1 and 0 == int_minute2:
                int_second1 = int(self.getText(self.tup_second1))
                if 2 > int_second1:
                    time.sleep(second)

    def setCurrentUnit(self, str_current_unit):
        """
        设置投注时的货币单位，例如元，角，分
        :param str_current_unit: 
        :return: 
        """
        if u"元" == str_current_unit:
            self.click(self.tup_current_unit_yuan)
        elif u"角" == str_current_unit:
            self.click(self.tup_current_unit_jiao)
        elif u"分" == str_current_unit:
            self.click(self.tup_current_unit_fen)
        else:
            raise Exception("\n Invalid current unit: %s.\nShould be 元, 角 or 分." % str_current_unit)

    def randomBet(self, int_amount):
        """
        随机投注。
        :param int_amount: 随机投注的数量，1或者5.
        :return: 
        """
        if 1 == int(int_amount):
            self.click(self.tup_randomone)
        elif 5 == int(int_amount):
            self.click(self.tup_randomfive)
        else:
            raise Exception("\nInvalid amount of bet. Should be 1 or 5.")

    def revertBet(self):
        """
        对最后一次投注进行撤单。
        :return: 
        """
        self.clickCell(self.tup_bet_record, 0, 7)

    def get_issue(self):
        """
        读取当前的彩票期数，并返回。
        :return: 返回当前的彩票期数。
        """
        time.sleep(1)
        self.scrollVerticalDragger(self.tup_path, self.tup_dragger, top=True)
        time.sleep(1)
        self.scrollIntoView(self.tup_current_issue)
        return self.getText(self.tup_current_issue)

    def getBetTime(self):
        """
        读取最后一次的投注时间。
        :return: 
        """
        self.scrollIntoView(self.tup_bet_record)
        return self.getCellText(self.tup_bet_record, 0, 1)

    def gotoGameMethod(self, str_model1, str_model2):
        """
        跳转到指定玩法。
        :param str_model1: 大玩法，例如前一，前二。
        :param str_model2: 小玩法，例如直选复式。
        :return: 
        """
        self.checkAutoPopup()
        self._gotomodel1(str_model1)
        self.checkAutoPopup()
        self._gotomodel2(str_model1, str_model2)

    def _gotomodel1(self, str_model1):
        """
        跳转到大玩法，例如前一，前二，前三。
        :param str_model1: 
        :return: 
        """
        if self.dic_model:
            if str_model1 in self.dic_model.keys():
                self.switch_to_default_frame()
                self.waitElementVisible(self.tup_iframe)
                self.switch_to_frame(self.tup_iframe)
                str_model1_locator = self.dic_model[str_model1]["locator"]
                self.waitElementVisible(str_model1_locator)
                self.click(str_model1_locator)
        else:
            raise Exception('\nPlease check data self.dic_model, which should not be empty!')

    def _gotomodel2(self, str_model1, str_model2):
        """
        跳转到小玩法，例如直选复式，直选单式。
        :param str_model1: 
        :param str_model2: 
        :return: 
        """
        if self.dic_model[str_model1]["model2"]:
            if str_model2 in self.dic_model[str_model1]["model2"].keys():
                str_model2_locator = self.dic_model[str_model1]["model2"][str_model2]
                self.waitElementVisible(str_model2_locator)
                self.click(str_model2_locator)

    def checkAutoPopup(self):
        """
        临近投注截止时间时，会有一个自动弹窗，提示玩家是否清空投注内容。
        若该弹窗存在，则等待5秒，再操作。
        :return: 
        """
        try:
            self.findElement(self.tup_popup_message2)
            time.sleep(10)
        except:
            pass

    def giveCodes(self, codes):
        """
        设置投注号码。
        如果codes是列表类型，那么这是直选复式，选号。
        如果codes是一个文件名称，那么这是上传文件投注。
        如果codes是一个数字字符串，那么这是直选单式，直接在文本框写入号码。
        :param codes: 投注号码。
        :return: 
        """
        if type(codes) == list:
            for i in range(len(codes)):
                self.bet(i, codes[i])
        elif type(codes) == unicode or type(codes) == str:
            if os.path.isfile(codes):
                self.upLoadFile(codes)
            else:
                self.type(self.tup_input_box, codes)
        else:
            raise Exception("\nInvalid type of codes: %s. Should be: unicode, str or list." % str(type(codes)))

    # 以下为直选复式流程
    def bet_normal(self, testdata):
        """
        正常登陆时，调用bet_normal方法。
        具体包括：一般投注（选号、输入字符串）、快捷投注、上传文件投注、返点投注、随机投注、追号投注、撤单投注等流程。
        :param testdata: 测试数据。
        :return: 
        """
        result = TestResult()
        self.switch_to_default_frame()
        self.waitElementVisible(self.tup_iframe)
        self.switch_to_frame(self.tup_iframe)
        self.waitOpening()  # 步骤1：等待开局
        if testdata.has_money:  # 步骤2：设置单注金额
            self.type(self.tup_money, testdata.money)
        if testdata.has_currentunit:  # 步骤3：设置货币单位
            self.setCurrentUnit(testdata.currentunit)
        if testdata.has_point:  # 步骤4：设置返水
            self.setPoint(testdata.point)
        if testdata.has_codes or testdata.has_upload:  # 步骤5：输入投注号码,并添加注单
            self.giveCodes(testdata.codes)
            if testdata.has_random:  # 输入号码后，点击随机一注或五注
                self.randomBet(testdata.random)
            else:  # 输入号码后，点击添加订单
                self.click(self.tup_add_button)
        if testdata.has_random:  # 随机一注或者五注
            self.randomBet(testdata.random)
        if testdata.has_term or testdata.has_times:  # 步骤5：追号
            self.scrollIntoView(self.tup_on_off,secs=2)
            if not self.isSelected(self.tup_on_off):
                self.click(self.tup_on_off)
            if testdata.has_skip:  # 翻倍追号
                self.click(self.tup_diff_times)
                self.type(self.tup_skip, testdata.skip)
                if testdata.has_times:  # 倍数
                    self.type(self.tup_time2, testdata.times)
            else:  # 同倍追号
                self.click(self.tup_same_times)
                if testdata.has_times:
                    self.type(self.tup_time1, testdata.times)
            if testdata.has_term:  # 期数
                self.type(self.tup_term, testdata.term)
            try:
                self.waitElementVisible(self.tup_popup_message2)
                result.message_wrong_term = self.getText(self.tup_popup_message2)
                if self.getDisplay(self.tup_alert_close_button):
                    self.click(self.tup_alert_close_button)
                return result
            except:
                result.total_money = self.getText(self.tup_total_money)
        self.scrollVerticalDragger(self.tup_path, self.tup_dragger)
        self.click(self.tup_buy_button)  # 步骤6：确认投注
        self.waitElementVisible(self.tup_popup_message1)
        message_confirm_bet = self.getText(self.tup_popup_message1)
        result.message_confirm_bet = message_confirm_bet
        if self.getDisplay(self.tup_confirm_button):
            self.click(self.tup_confirm_button)
        self.waitElementVisible(self.tup_popup_message2)
        message_bet_success = self.getText(self.tup_popup_message2)
        result.message_bet_success = message_bet_success
        if self.getDisplay(self.tup_alert_close_button):
            self.click(self.tup_alert_close_button)
        result.bet_time = self.getBetTime()
        if testdata.has_status:  # 步骤7：撤单
            self.revertBet()
            self.click(self.tup_revert_button)
            self.waitElementVisible(self.tup_confirm_button)
            if self.getDisplay(self.tup_confirm_button):
                self.click(self.tup_confirm_button)
            self.waitElementVisible(self.tup_alert_close_button)
            if self.getDisplay(self.tup_alert_close_button):
                self.click(self.tup_alert_close_button)
        return result

    def insufficient(self, testdata):
        """
        投注时余额不足的流程。
        :return: 
        """
        result = TestResult()
        self.switch_to_default_frame()
        self.waitElementVisible(self.tup_iframe)
        self.switch_to_frame(self.tup_iframe)
        self.waitOpening()  # 步骤1：等待开局
        if testdata.has_money:
            self.type(self.tup_money, testdata.money)
        if testdata.has_point:
            self.setPoint(testdata.point)
        if testdata.has_codes:
            self.giveCodes(testdata.codes)
        self.click(self.tup_add_button)
        self.click(self.tup_buy_button)  # 步骤5：确认投注
        self.waitElementVisible(self.tup_popup_message1)
        message_confirm_bet = self.getText(self.tup_popup_message1)
        result.message_confirm_bet = message_confirm_bet
        if self.getDisplay(self.tup_confirm_button):
            self.click(self.tup_confirm_button)
        self.waitElementVisible(self.tup_popup_message2)
        message_bet_success = self.getText(self.tup_popup_message2)
        result.message_bet_success = message_bet_success
        if self.getDisplay(self.tup_alert_close_button):
            self.click(self.tup_alert_close_button)
        return result

    def bet_clean_all(self, testdata):
        """
        投注后，清除号码
        :return: 返回弹窗信息。
        """
        result = TestResult()
        self.switch_to_default_frame()
        self.waitElementVisible(self.tup_iframe)
        self.switch_to_frame(self.tup_iframe)
        self.waitOpening()  # 步骤1：等待开局
        if testdata.has_money:  # 步骤2：设置单注金额
            self.type(self.tup_money, testdata.money)
        if testdata.has_point:  # 步骤3：设置返水
            self.setPoint(testdata.point)
        if testdata.has_codes or testdata.has_upload:  # 步骤4：输入投注号码,并添加注单
            self.giveCodes(testdata.codes)
            if testdata.has_random:  # 输入号码后，点击随机一注或五注
                self.randomBet(testdata.random)
            else:  # 输入号码后，点击添加订单
                self.click(self.tup_add_button)
        if testdata.has_random:  # 随机一注或者五注
            self.randomBet(testdata.random)
        self.click(self.tup_clean)
        self.waitElementVisible(self.tup_popup_message2)
        result.message_clean_all = self.getText(self.tup_popup_message2)
        if self.getDisplay(self.tup_confirm_button):
            self.click(self.tup_confirm_button)
        return result

    def clean_one(self, codes, str_each_money=2, flo_return_water=0):
        """
        添加注单后，删除一个注单。
        :param codes: 投注号码。
        :param str_each_money: 单注金额。
        :param flo_return_water: 返水百分比。
        :return: 
        """
        self.switch_to_default_frame()
        self.waitElementVisible(self.tup_iframe)
        self.switch_to_frame(self.tup_iframe)
        self.waitOpening()  # 等待开局
        self.giveCodes(codes)
        self.type(self.tup_money, str_each_money)
        self.setPoint(flo_return_water)
        self.click(self.tup_add_button)
        self.click(self.tup_clean_one)
        self.click(self.tup_buy_button)
        self.waitElementVisible(self.tup_popup_message2)
        str_popup_message = self.getText(self.tup_popup_message2)
        if self.getDisplay(self.tup_alert_close_button):
            self.click(self.tup_alert_close_button)
        return str_popup_message

    def change_normal_to_random(self, codes, int_bet_amount, str_each_money=2, flo_return_water=0):
        """
        选择一个号码，不点击‘添加注单’，点击‘随机一注’。
        :param codes: 
        :param int_bet_amount: 
        :param str_each_money: 
        :param flo_return_water: 
        :return: 
        """
        self.switch_to_default_frame()
        self.waitElementVisible(self.tup_iframe)
        self.switch_to_frame(self.tup_iframe)
        self.waitOpening()  # 等待开局
        self.giveCodes(codes)
        self.type(self.tup_money, str_each_money)
        self.setPoint(flo_return_water)
        self.randomBet(int_bet_amount)
        self.waitElementVisible(self.tup_popup_message2)
        str_popup_message = self.getText(self.tup_popup_message2)
        if self.getDisplay(self.tup_confirm_button):
            self.click(self.tup_confirm_button)
        return str_popup_message

    def wrong_codes(self, testdata):
        """
        投注号码错误的流程。
        :param codes: 投注号码。
        :param str_each_money: 单注金额。
        :param flo_return_water: 返水百分比。
        :return: 
        """
        result = TestResult()
        self.switch_to_default_frame()
        self.waitElementVisible(self.tup_iframe)
        self.switch_to_frame(self.tup_iframe)
        self.waitOpening()  # 等待开局
        if testdata.has_money:
            self.type(self.tup_money, testdata.money)
        if testdata.has_point:
            self.setPoint(testdata.point)
        if testdata.has_codes:
            self.giveCodes(testdata.codes)
        try:
            self.waitElementVisible(self.tup_popup_message2)
            result.message_wrong_codes = self.getText(self.tup_popup_message2)
            if self.getDisplay(self.tup_alert_close_button):
                self.click(self.tup_alert_close_button)
            return result
        except TimeoutException:
            pass
        self.click(self.tup_add_button)
        self.waitElementVisible(self.tup_popup_message2)
        result.message_wrong_codes = self.getText(self.tup_popup_message2)
        if self.getDisplay(self.tup_alert_close_button):
            self.click(self.tup_alert_close_button)
        return result

    def add_empty(self, str_each_money=2, flo_return_water=0):
        """
        没有选择投注号码，添加注单。
        :param str_each_money: 单注金额。
        :param flo_return_water: 返水百分比。
        :return: 
        """
        self.switch_to_default_frame()
        self.waitElementVisible(self.tup_iframe)
        self.switch_to_frame(self.tup_iframe)
        self.waitOpening()  # 等待开局
        self.type(self.tup_money, str_each_money)
        self.setPoint(flo_return_water)
        self.click(self.tup_add_button)
        self.waitElementVisible(self.tup_popup_message2)
        str_popup_message = self.getText(self.tup_popup_message2)
        if self.getDisplay(self.tup_alert_close_button):
            self.click(self.tup_alert_close_button)
        return str_popup_message

    def buy_empty(self, str_each_money=2, flo_return_water=0):
        """
        没有选择投注号码，点击‘确认投注’按钮。
        :param str_each_money: 单注金额。
        :param flo_return_water: 返水百分比。
        :return: 
        """
        self.switch_to_default_frame()
        self.waitElementVisible(self.tup_iframe)
        self.switch_to_frame(self.tup_iframe)
        self.waitOpening()  # 等待开局
        self.type(self.tup_money, str_each_money)
        self.setPoint(flo_return_water)
        self.click(self.tup_buy_button)
        self.waitElementVisible(self.tup_popup_message2)
        str_popup_message = self.getText(self.tup_popup_message2)
        if self.getDisplay(self.tup_alert_close_button):
            self.click(self.tup_alert_close_button)
        return str_popup_message

    def wrong_money(self, codes, str_each_money=0, flo_return_water=0):
        """
        投注时，输入错误的单注额，比如0元每注。
        :param codes: 投注号码。
        :param str_each_money: 单注额。
        :param flo_return_water: 返水百分比。
        :return: 
        """
        self.switch_to_default_frame()
        self.waitElementVisible(self.tup_iframe)
        self.switch_to_frame(self.tup_iframe)
        self.waitOpening()  # 等待开局
        self.giveCodes(codes)
        self.type(self.tup_money, str_each_money)
        self.setPoint(flo_return_water)
        self.click(self.tup_add_button)
        self.waitElementVisible(self.tup_popup_message2)
        str_popup_message = self.getText(self.tup_popup_message2)
        if self.getDisplay(self.tup_alert_close_button):
            self.click(self.tup_alert_close_button)
        return str_popup_message

    def wrong_term(self, testdata):
        """
        追号时，输入超大的追号期数，比如81期。
        :param testdata: 测试数据。
        :return: 
        """
        return self.bet_normal(testdata)

    # 以下为直选单式流程
    def remove_duplication(self, testdata):
        """
        直选单式，删除重复号码。
        :param codes: 投注号码。
        :param str_each_money: 单注金额。
        :param flo_return_water: 返水百分比。
        :return: 
        """
        result = TestResult()
        self.switch_to_default_frame()
        self.waitElementVisible(self.tup_iframe)
        self.switch_to_frame(self.tup_iframe)
        self.waitOpening()  # 等待开局
        if testdata.has_money:
            self.type(self.tup_money, testdata.money)
        if testdata.has_point:
            self.setPoint(testdata.point)
        if testdata.has_codes:
            self.giveCodes(testdata.codes)
        self.click(self.tup_remove_duplication)
        self.waitElementVisible(self.tup_popup_message2)
        result.message_remove_duplication = self.getText(self.tup_popup_message2)
        if self.getDisplay(self.tup_alert_close_button):
            self.click(self.tup_alert_close_button)
        self.click(self.tup_add_button)
        self.click(self.tup_buy_button)
        self.waitElementVisible(self.tup_popup_message1)
        result.message_confirm_bet = self.getText(self.tup_popup_message1)
        if self.getDisplay(self.tup_confirm_button):
            self.click(self.tup_confirm_button)
        result.message_bet_success = self.getText(self.tup_popup_message2)
        if self.getDisplay(self.tup_alert_close_button):
            self.click(self.tup_alert_close_button)
        return result

    def filt(self, testdata):
        """
        自动过滤重复号码的流程。
        :param codes: 投注号码。
        :param str_each_money: 单注金额。
        :param flo_return_water: 返水百分比。
        :return: 
        """
        result = TestResult()
        self.switch_to_default_frame()
        self.waitElementVisible(self.tup_iframe)
        self.switch_to_frame(self.tup_iframe)
        self.waitOpening()  # 等待开局
        if testdata.has_money:
            self.type(self.tup_money, testdata.money)
        if testdata.has_point:
            self.setPoint(testdata.point)
        if testdata.has_codes:
            self.giveCodes(testdata.codes)
        self.click(self.tup_add_button)
        self.waitElementVisible(self.tup_popup_message4)
        result.message_auto_filer = self.getText(self.tup_popup_message4)
        self.waitElementVisible(self.tup_alert_close_button)
        if self.getDisplay(self.tup_alert_close_button):
            self.click(self.tup_alert_close_button)
        self.click(self.tup_buy_button)
        self.waitElementVisible(self.tup_popup_message1)
        result.message_confirm_bet = self.getText(self.tup_popup_message1)
        if self.getDisplay(self.tup_confirm_button):
            self.click(self.tup_confirm_button)
        result.message_bet_success = self.getText(self.tup_popup_message2)
        if self.getDisplay(self.tup_alert_close_button):
            self.click(self.tup_alert_close_button)
        return result

    def upload_then_empty(self, codes, str_each_money=2, flo_return_water=0):
        """
        上传文件，然后清空投注号码。
        :param codes: 文件路径。文件内写有投注号码。
        :param str_each_money: 单注金额。
        :param flo_return_water: 返水百分比。
        :return: 
        """
        self.switch_to_default_frame()
        self.waitElementVisible(self.tup_iframe)
        self.switch_to_frame(self.tup_iframe)
        self.waitOpening()  # 等待开局
        self.type(self.tup_money, str_each_money)
        self.setPoint(flo_return_water)
        self.giveCodes(codes)
        self.click(self.tup_empty_input)
        self.click(self.tup_add_button)
        self.waitElementVisible(self.tup_popup_message2)
        str_popup_message = self.getText(self.tup_popup_message2)
        if self.getDisplay(self.tup_alert_close_button):
            self.click(self.tup_alert_close_button)
        return str_popup_message

    def upload_wrong_codes(self, str_filename, str_each_money=2, flo_return_water=0):
        """
        通过上传文件进行下注，但文件中的号码错误。
        :param str_filename: 文件路径。文件内写有投注号码。
        :param str_each_money: 单注金额。
        :param flo_return_water: 返水百分比。
        :return: 
        """
        self.switch_to_default_frame()
        self.waitElementVisible(self.tup_iframe)
        self.switch_to_frame(self.tup_iframe)
        self.waitOpening()  # 等待开局
        self.type(self.tup_money, str_each_money)
        self.setPoint(flo_return_water)
        dic_result = self.upLoadFile(str_filename)
        return dic_result
