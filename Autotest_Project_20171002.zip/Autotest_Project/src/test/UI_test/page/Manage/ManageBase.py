#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/6/1 11:54
# @Author  : Terry
from src.test.UI_test.page.BasePage import BasePage


class ManageBase(BasePage):
    def gotoUserCenterPage(self):
        pass
    def gotoDepositPage(self):
        pass

    def gotoDrawMoneyPage(self):
        pass

    def gotoAccountInfoPage(self):
        pass

    def gotoDealRecordPage(self):
        pass

    def gotoMessageCenterPage(self):
        pass

    def gotoServicePage(self):
        pass