#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/7/13 9:59
# @Author  : Terry
from src.test.UI_test.common.common import TestResult
from src.test.UI_test.page.BasePage import BasePage


class WithdrawPage(BasePage):
    """
    用户管理中心-->在线取款。
    """
    tup_money = ("css", "#amount")
    tup_password = ("css", "#transpwd")
    tup_commit_btn = ("css", "#withdraw_submit")
    tup_popup_window1 = ("css", "._alert_.anim>p")
    tup_close_btn = ("css", ".btn_ok")

    def withdraw(self, testdata):
        """
        正常提款流程。
        :param testdata: 
        :return: 
        """
        result = TestResult()
        self.type(self.tup_money, testdata.wmoney)
        self.type(self.tup_password, testdata.password_withdraw)
        self.click(self.tup_commit_btn)
        result.message_withdraw_commit = self.getText(self.tup_popup_window1)
        if self.getDisplay(self.tup_close_btn):
            self.click(self.tup_close_btn)
        return result
