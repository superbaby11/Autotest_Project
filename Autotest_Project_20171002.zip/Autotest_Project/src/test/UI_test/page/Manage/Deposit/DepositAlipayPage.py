#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/7/1 10:48
# @Author  : Terry
from src.test.UI_test.page.Manage.Deposit.DepositBase import DepositBase


class DepositAlipayPage(DepositBase):
    # 第一页
    dic_to_account = {
        u"仁信支付宝(扫码)": {
            "money": ("css", "#bao_step1 .wechat-one>div:nth-child(1) .wechat-int"),
            "button": ("css", "#bao_step1 .wechat-one>div:nth-child(1) .btn.fr")
        },
        u"支付宝支付（添加好友进行支付）": {
            "money": ("css", "#bao_step1 .wechat-one>div:nth-child(2) .wechat-int"),
            "button": ("css", "#bao_step1 .wechat-one>div:nth-child(2) .btn.fr")
        }
    }
    # 第二页
    tup_message = ("css", "#bao_step2_scan  .we-or-tit>h3")
    tup_order_number = ("css", "#bao_2_oid_s")
    tup_commit_order = ("css", "#bao_step2_addF .pay-wei-btn")
