#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/7/1 10:47
# @Author  : Terry
from src.test.UI_test.common.common import TestResult
from src.test.UI_test.page.BasePage import BasePage


class DepositBankPage(BasePage):
    # 第一页
    tup_popup_message = ("css", "._alert_.anim>p")
    tup_close_btn = ("css", ".btn_ok")
    tup_name = ('css', '#bankDeposit_div [name=userName]')
    tup_bank = ('css', '#bankDeposit_div  select')
    tup_amount = ('css', '#bankDeposit_div  [name=ipt_money]')
    lis_from_bank = [
        u"中国农业银行",
        u"中国建设银行",
        u"中国工商银行",
        u"招商银行",
        u"中国银行",
        u"中国邮政储蓄",
        u"中国民生银行",
        u"中信银行",
        u"中国光大银行",
        u"兴业银行",
        u"华夏银行",
        u"北京银行",
        u"浦发银行",
        u"广发银行",
        u"平安银行"
    ]
    tup_next_button1 = ('css', '#bankDeposit_div  [name=next_btn]')
    # 第二页
    dic_to_account = {
        u"21": ("css", "#bank_list div:nth-child(1)>input"),
        u"1111111111111111111": ("css", "#bank_list div:nth-child(2)>input"),
        u"4123401480412": ("css", "#bank_list div:nth-child(3)>input"),
        u"2017067601001227719": ("css", "#bank_list div:nth-child(4)>input"),
        u"1111": ("css", "#bank_list div:nth-child(6)>input"),
        u"123456789123456789": ("css", "#bank_list div:nth-child(7)>input")
    }
    tup_back_button1 = ("css", "#div_2_2 [name=back_btn]")
    tup_next_button2 = ("css", "#div_2_2 [name=next_btn]")
    # 第三页
    tup_to_bank = ("css", "#bank_name_url>button")
    tup_order_number = ("css", ".int.int-bg")
    dic_deposit_type = {
        u"网银转账": ("css", "label:nth-child(1) .order-radio"),
        u"ATM自动柜员机": ("css", "label:nth-child(2) .order-radio"),
        u"ATM现金入款": ("css", "label:nth-child(3) .order-radio"),
        u"银行柜台": ("css", "label:nth-child(4) .order-radio"),
        u"手机银行": ("css", "label:nth-child(5) .order-radio"),
        u"其它": ("css", "label:nth-child(6) .order-radio")
    }
    tup_back_button2 = ("css", "#div_2_3 .btn-blue")
    tup_submit = ("css", ".btn-orange")
    # 第四页
    tup_message = ("css", "#div_2_4 .bank-order-info>p:nth-child(1)")

    def deposit(self, testdata):
        """
        正常充值的流程。
        :param testdata: 测试数据。
        :return: 
        """
        result = TestResult()
        # 第一页
        self.type(self.tup_name, testdata.dname)
        if testdata.from_bank in self.lis_from_bank:
            self.selectByVisibleText(self.tup_bank, testdata.from_bank)
        else:
            raise Exception("\nInvalid bank name: %s.\nShould be one of %s."
                            % (testdata.from_bank, str(self.lis_from_bank)))
        self.type(self.tup_amount, testdata.dmoney)
        self.click(self.tup_next_button1)
        # 第二页
        if testdata.to_account in self.dic_to_account.keys():
            self.click(self.dic_to_account[testdata.to_account])
        else:
            raise Exception("\nInvalid account: %s.\nShould be one of %s."
                            % (testdata.to_account, str(self.dic_to_account.keys())))
        self.click(self.tup_next_button2)
        # 第三页
        if testdata.has_title:
            self.click(self.tup_to_bank)
            self.switch_to_window(2)
            result.title = self.getTitle()
            self.close_current_window()
            self.switch_to_window(1)
            return result
        result.order_number = self.getText(self.tup_order_number)
        if testdata.dtype in self.dic_deposit_type.keys():
            self.click(self.dic_deposit_type[testdata.dtype])
        else:
            raise Exception("\nInvalid deposit type: %s.\nShould be one of %s."
                            % (testdata.dtype, str(self.dic_deposit_type.keys())))
        self.click(self.tup_submit)
        # 第四页
        self.scrollIntoView(self.tup_message)
        result.message_deposit_info = self.getText(self.tup_message)
        return result

    def no_name(self, testdata):
        """
        玩家充值时，不输入用户名。
        :param testdata: 
        :return: 
        """
        result = TestResult()
        # 第一页
        if testdata.from_bank in self.lis_from_bank:
            self.selectByVisibleText(self.tup_bank, testdata.from_bank)
        else:
            raise Exception("\nInvalid bank name: %s.\nShould be one of %s."
                            % (testdata.from_bank, str(self.lis_from_bank)))
        self.type(self.tup_amount, testdata.dmoney)
        self.click(self.tup_next_button1)
        result.message_deposit_no_name = self.getText(self.tup_popup_message)
        if self.getDisplay(self.tup_close_btn):
            self.click(self.tup_close_btn)
        return result

    def wrong_money(self, testdata):
        """
        玩家充值时，输入错误的金额。
        :param testdata: 
        :return: 
        """
        result = TestResult()
        # 第一页
        self.type(self.tup_name, testdata.dname)
        if testdata.from_bank in self.lis_from_bank:
            self.selectByVisibleText(self.tup_bank, testdata.from_bank)
        else:
            raise Exception("\nInvalid bank name: %s.\nShould be one of %s."
                            % (testdata.from_bank, str(self.lis_from_bank)))
        if testdata.has_dmoney:
            self.type(self.tup_amount, testdata.dmoney)
        self.click(self.tup_next_button1)
        result.message_deposit_wrong_money = self.getText(self.tup_popup_message)
        if self.getDisplay(self.tup_close_btn):
            self.click(self.tup_close_btn)
        return result
