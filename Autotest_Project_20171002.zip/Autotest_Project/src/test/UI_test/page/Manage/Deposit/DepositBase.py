#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/7/1 11:23
# @Author  : Terry
import time

from src.test.UI_test.common.common import TestResult
from src.test.UI_test.page.BasePage import BasePage


class DepositBase(BasePage):
    # 第一页
    dic_to_account = {}
    # 第二页
    tup_order_number = None
    tup_message = None
    tup_commit_order = None
    tup_popup_window1 = ("css", "._alert_.anim>p")
    tup_close_btn = ("css", ".btn_ok")

    def deposit(self, testdata):
        """
        正常充值的流程。
        :param testdata: 
        :return: 
        """
        result = TestResult()
        # 第一页
        if testdata.to_account in self.dic_to_account.keys():
            tup_dmoney = self.dic_to_account[testdata.to_account]["money"]
            tup_next_btn = self.dic_to_account[testdata.to_account]["button"]
        else:
            raise Exception("\nInvalid account: %s.\nShould be one of: %s."
                            % (testdata.to_account, str(self.dic_to_account.keys())))
        self.type(tup_dmoney, testdata.dmoney)
        self.click(tup_next_btn)
        # 第二页
        try:  # 微信入款，需要加好友
            self.click(self.tup_commit_order)
            result.message_deposit_info = self.getText(self.tup_popup_window1)
            if self.getDisplay(self.tup_close_btn):
                self.click(self.tup_close_btn)
            return result
        except Exception:  # 微信入款，不需要加好友，需要扫码
            time.sleep(2)
            result.message_deposit_info = self.getText(self.tup_message)
            result.order_number = self.getText(self.tup_order_number)
            return result

    def wrong_money(self, testdata):
        """
        玩家充值时，金额错误。
        :param testdata: 
        :return: 
        """
        result = TestResult()
        if testdata.to_account in self.dic_to_account.keys():
            tup_dmoney = self.dic_to_account[testdata.to_account]["money"]
            tup_next_btn = self.dic_to_account[testdata.to_account]["button"]
        else:
            raise Exception("\nInvalid account: %s.\nShould be one of: %s."
                            % (testdata.to_account, str(self.dic_to_account.keys())))
        if testdata.has_dmoney:
            self.type(tup_dmoney, testdata.dmoney)
        self.click(tup_next_btn)
        result.message_deposit_wrong_money = self.getText(self.tup_popup_window1)
        if self.getDisplay(self.tup_close_btn):
            self.click(self.tup_close_btn)
        return result
