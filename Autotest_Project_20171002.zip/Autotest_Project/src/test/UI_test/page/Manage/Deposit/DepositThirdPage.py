#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/7/1 10:49
# @Author  : Terry
from src.test.UI_test.page.BasePage import BasePage


class DepositThirdPage(BasePage):
    pass
