#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/7/1 11:27
# @Author  : Terry
from src.test.UI_test.page.BasePage import BasePage
from src.test.UI_test.page.Manage.Deposit.DepositAlipayPage import DepositAlipayPage
from src.test.UI_test.page.Manage.Deposit.DepositBankPage import DepositBankPage
from src.test.UI_test.page.Manage.Deposit.DepositThirdPage import DepositThirdPage
from src.test.UI_test.page.Manage.Deposit.DepositWechatPage import DepositWechatPage


class DepositNavigator(BasePage):

    tup_wechat = ('css', '.pay-top_1.clearfix>a:nth-child(1)')
    tup_alipay = ('css', '.pay-top_1.clearfix>a:nth-child(2)')
    tup_bank = ('css', '.pay-top_1.clearfix>a:nth-child(3)')
    tup_third = ('css', '.pay-top_1.clearfix>a:nth-child(4)')

    def bank(self):
        """
        跳转到银行入款页面。
        :return: 
        """
        self.click(self.tup_bank)
        return DepositBankPage(self.getDriver())

    def wechat(self):
        """
        跳转到微信支付页面。
        :return: 
        """
        self.click(self.tup_wechat)
        return DepositWechatPage(self.getDriver())

    def alipay(self):
        """
        跳转到支付宝支付页面。
        :return: 
        """
        self.click(self.tup_alipay)
        return DepositAlipayPage(self.getDriver())

    def third(self):
        """
        跳转到线上支付页面。
        :return: 
        """
        self.click(self.tup_third)
        return DepositThirdPage(self.getDriver())
