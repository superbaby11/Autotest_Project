#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/7/1 10:47
# @Author  : Terry


from src.test.UI_test.page.Manage.Deposit.DepositBase import DepositBase


class DepositWechatPage(DepositBase):
    # 第一页
    dic_to_account = {
        u"智付微信2": {
            "money": ("css", "#WePay_div .wechat-one>div:nth-child(1) .wechat-int"),
            "button": ("css", "#WePay_div .wechat-one>div:nth-child(1) .btn.fr")
        },
        u"E宝微信(扫码)": {
            "money": ("css", "#WePay_div .wechat-one>div:nth-child(2) .wechat-int"),
            "button": ("css", "#WePay_div .wechat-one>div:nth-child(2) .btn.fr")
        },
        u"支付通微信(扫码)": {
            "money": ("css", "#WePay_div .wechat-one>div:nth-child(3) .wechat-int"),
            "button": ("css", "#WePay_div .wechat-one>div:nth-child(3) .btn.fr")
        },
        u"E宝微信(扫码)": {
            "money": ("css", "#WePay_div .wechat-one>div:nth-child(4) .wechat-int"),
            "button": ("css", "#WePay_div .wechat-one>div:nth-child(4) .btn.fr")
        },
        u"微信支付（添加好友进行支付）": {
            "money": ("css", "#WePay_div .wechat-one>div:nth-child(5) .wechat-int"),
            "button": ("css", "#WePay_div .wechat-one>div:nth-child(5) .btn.fr")
        }
    }
    # 第二页
    tup_message = ("css", "#wechat_step2_scan .we-or-tit>h3")
    tup_order_number = ("css", "#orderId_2_s")
    tup_commit_order = ("css", "#WePay_div .pay-wei-btn")
