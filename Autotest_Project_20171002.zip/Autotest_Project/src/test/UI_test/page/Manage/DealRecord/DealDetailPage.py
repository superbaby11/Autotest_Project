#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/6/2 14:47
# @Author  : Terry
import re

import time

from src.test.UI_test.common.common import TestResult
from src.test.UI_test.page.Manage.DealRecord.DealRecordBase import DealRecordBase


class DealDetailPage(DealRecordBase):
    tup_search = ("css", "#trade_div  .btn_search")
    tup_date_scope = ("css", "#trade_div .datatype_select")
    tup_table = ("css", "#trade_div .content>table>tbody")
    lis_type_reward = [u"汇款优惠", u"首存优惠"]

    def search(self, str_time=None, str_record_num="5", str_date_scope=u"今天"):
        """
        筛选出符合条件的条目，返回该条目的收支清况、交易类型、交易金额。
        若筛选出的条目包含充值优惠，也会返回充值优惠。
        :param str_time: 投注时间或者充值时间。
        :param str_record_num: 每页表格展示条目的数量，例如，10。
        :param str_date_scope: 日期范围，例如，今天。
        :return: 返回该条目的收支清况、交易类型、交易金额。
        """
        result = TestResult()
        self.setRecordNum(str_record_num)
        self.setDateScope(str_date_scope)
        self.click(self.tup_search)
        self.waitElementVisible(self.tup_table)
        if str_time is None:  # 若没有提供时间信息，则默认取第一列数据
            time.sleep(1)
            result.income_and_expense = self.getCellText(self.tup_table, 0, 2)
            result.deal_type = self.getCellText(self.tup_table, 0, 3)
            result.deal_money = self.getCellText(self.tup_table, 0, 4)
        else:
            lis_row = self.getTargetRow(str_time, self.tup_table, 0)
            if 0 == len(lis_row):
                raise Exception("\nCan not find any item in the table according to the given bet time: %s" % str_time)
            result.deal_item = len(lis_row)
            result.income_and_expense = self.getCellText(self.tup_table, lis_row[0], 2)
            result.deal_type = self.getCellText(self.tup_table, lis_row[0], 3)
            result.deal_money = self.getCellText(self.tup_table, lis_row[0], 4)
            if self.getCellText(self.tup_table, lis_row[-1], 3) in self.lis_type_reward:
                result.reward = self.getCellText(self.tup_table, lis_row[-1], 4)
        return result
