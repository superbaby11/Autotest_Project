#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/7/4 13:43
# @Author  : Terry
import time

from src.test.UI_test.common.common import TestResult
from src.test.UI_test.page.Manage.DealRecord.DealRecordBase import DealRecordBase


class DepositRecordPage(DealRecordBase):
    lis_deposit_status = [u"全部", u"待确认", u"已存入", u"已取消"]
    tup_date_scope = ("css", "#recharge_div .datatype_select")
    tup_search = ("css", "#recharge_div .btn_search")
    tup_deposit_status = ("css", "#recharge_div .deposit_status")
    tup_table = ("css", "#recharge_div tbody")

    def setDepositStatus(self, str_deposit_status):
        """
        设置‘充值记录’页面的存款状态条件。
        :return: 
        """
        if str_deposit_status in self.lis_deposit_status:
            self.selectByVisibleText(self.tup_deposit_status, str_deposit_status)
        else:
            raise Exception("\nInvalid deposit status: %s.\nShould be one of: %s."
                            % (str_deposit_status, str(self.lis_deposit_status)))

    def search(self, str_order_number=None, str_deposit_status=u"全部", str_record_num="5", str_date_scope=u"今天"):
        """
        筛选出符合条件的条目，返回该条目的充值类型、充值金额和订单状态。
        :param str_order_number: 订单号码。
        :param str_deposit_status: 订单状态
        :param str_record_num: 每页表格展示条目的数量，例如，10。
        :param str_date_scope: 日期范围，例如，今天。
        :return: 
        """
        result = TestResult()
        self.setRecordNum(str_record_num)
        self.setDepositStatus(str_deposit_status)
        self.setDateScope(str_date_scope)
        self.click(self.tup_search)
        self.waitElementVisible(self.tup_table)
        if str_order_number is None:  # 若没有提供订单号，默认取表格的第一行数据
            time.sleep(1)
            result.deal_type = self.getCellText(self.tup_table, 0, 2)  # 交易类型
            result.deal_money = self.getCellText(self.tup_table, 0, 3)  # 交易金额
            result.deposit_status = self.getCellText(self.tup_table, 0, 4)  # 交易状态
        else:
            lis_row = self.getTargetRow(str_order_number, self.tup_table, 1)
            if 0 == len(lis_row):
                raise Exception("\nThere is no data, according to the order: %s" % str_order_number)
            result.deal_type = self.getCellText(self.tup_table, lis_row[0], 2)
            result.deal_money = self.getCellText(self.tup_table, lis_row[0], 3)
            result.deposit_status = self.getCellText(self.tup_table, lis_row[0], 4)
        return result

