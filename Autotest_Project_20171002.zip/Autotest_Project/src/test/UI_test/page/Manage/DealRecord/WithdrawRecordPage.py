#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/7/11 11:42
# @Author  : Terry
import time

from src.test.UI_test.common.common import TestResult
from src.test.UI_test.page.Manage.DealRecord.DealRecordBase import DealRecordBase


class WithdrawRecordPage(DealRecordBase):
    """
    用户管理中心，提款记录页面。
    """
    lis_withdraw_status = [u"全部", u"成功", u"等待审核", u"审核未通过"]
    tup_date_scope = ("css", "#withdrawal_div .datatype_select")
    tup_search = ("css", "#withdrawal_div .btn_search")
    tup_withdraw_status = ("css", "#withdrawal_div .deposit_status")
    tup_table = ("css", "#withdrawal_div tbody")

    def setWithdrawStatus(self, str_withdraw_status):
        """
        设置‘出款记录’页面的出款状态条件。
        :return: 
        """
        if str_withdraw_status in self.lis_withdraw_status:
            self.selectByVisibleText(self.tup_withdraw_status, str_withdraw_status)
        else:
            raise Exception("\nInvalid withdraw status: %s.\nShould be one of: %s."
                            % (str_withdraw_status, str(self.lis_withdraw_status)))

    def search(self, str_order_number=None, str_withdraw_status=u"全部", str_record_num="5", str_date_scope=u"今天"):
        """
        筛选出符合条件的条目，返回该条目的充值类型、充值金额和订单状态。
        :param str_order_number: 订单号码。
        :param str_withdraw_status: 订单状态
        :param str_record_num: 每页表格展示条目的数量，例如，10。
        :param str_date_scope: 日期范围，例如，今天。
        :return: 
        """
        result = TestResult()
        self.setRecordNum(str_record_num)
        self.setWithdrawStatus(str_withdraw_status)
        self.setDateScope(str_date_scope)
        self.click(self.tup_search)
        self.waitElementVisible(self.tup_table)
        if str_order_number is None:  # 若没有提供订单号，默认取表格的第一行数据
            time.sleep(1)
            result.deal_money = self.getCellText(self.tup_table, 0, 2)  # 交易金额
            result.withdraw_status = self.getCellText(self.tup_table, 0, 5)  # 交易状态
        else:
            lis_row = self.getTargetRow(str_order_number, self.tup_table, 1)
            if 0 == len(lis_row):
                raise Exception("\nThere is no data, according to the order: %s" % str_order_number)
            result.deal_money = self.getCellText(self.tup_table, lis_row[0], 2)
            result.withdraw_status = self.getCellText(self.tup_table, lis_row[0], 5)
        return result
