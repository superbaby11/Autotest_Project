#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/6/1 13:30
# @Author  : Terry
import time

from src.test.UI_test.page.Manage.ManageBase import ManageBase


class DealRecordBase(ManageBase):
    # 页面显示条数
    tup_record_num = ("css", "#recordNum")
    lis_record_num = ["5", "10", "15", "20", "25", "30", "40", "50"]

    # 日期范围
    tup_date_scope = ()
    lis_date_scope = [u"今天", u"最近一周", u"最近2周", u"最近一个月", u"最近3个月", u"自定义"]

    tup_bet = ("css", "#top_lab>div:nth-child(1)")
    tup_reposit = ("css", "#top_lab>div:nth-child(2)")
    tup_withdraw = ("css", "#top_lab>div:nth-child(3)")
    tup_consume = ("css", "#top_lab>div:nth-child(4)")
    tup_Bonus = ("css", "#top_lab>div:nth-child(5)")
    tup_deal = ("css", "#top_lab>div:nth-child(6)")

    def gotoBetRecord(self):
        pass

    def gotoRepositRecord(self):
        pass

    def gotoWithdraw(self):
        pass

    def gotoBetConsume(self):
        pass

    def gotoBonusRecord(self):
        pass

    def gotoDealDetail(self):
        self.click(self.tup_deal)

    def setRecordNum(self, str_record_num):
        """
        在交易记录分类下，设置子页面的表格的显示条数
        :param str_record_num: 显示的条数
        :return: 无返回值。
        """
        str_record_num = str(str_record_num)
        if str_record_num in self.lis_record_num:
            self.selectByVisibleText(self.tup_record_num, str_record_num)
        else:
            raise KeyError("\nInvalid record number: %s.\nRecord number should be one of %s."
                           % (str_record_num, ", ".join(self.lis_record_num)))

    def setDateScope(self, str_date_scope):
        """
        在交易记录分类下，设置子页面的时间范围。
        :param str_date_scope: 时间范围。
        :return: 无返回值。
        """
        if str_date_scope in self.lis_date_scope:
            self.selectByVisibleText(self.tup_date_scope, str_date_scope)
        else:
            raise KeyError("\nInvalid date scope: %s.\nDate scope should be one of %s."
                           % (str_date_scope, ", ".join(self.lis_date_scope)))

    def getTargetRow(self, str_bet_time, tup_table, int_date_column, second=1):
        """
        找出与投注时间一致的条目。
        :param str_bet_time: 投注时间。
        :param tup_table: 表格地址。
        :param int_date_column: 日期所在列，从0开始编号。
        :param second: 等待时间。
        :return: 返回与投注时间匹配的条目的行号。
        """
        lis_row = []
        el = self.findElement(tup_table)
        time.sleep(second)
        lis_tr = el.find_elements_by_tag_name("tr")
        for i in range(len(lis_tr)):
            if str_bet_time == self.getCellText(tup_table, i, int_date_column):
                lis_row.append(i)
        return lis_row

