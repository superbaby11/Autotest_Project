#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/7/3 18:21
# @Author  : Terry
from src.test.UI_test.page.BasePage import BasePage
from src.test.UI_test.page.Manage.DealRecord.DealDetailPage import DealDetailPage
from src.test.UI_test.page.Manage.DealRecord.DepositRecordPage import DepositRecordPage
from src.test.UI_test.page.Manage.DealRecord.WithdrawRecordPage import WithdrawRecordPage


class DealRecordNavigator(BasePage):

    tup_bet = ("css", "#top_lab>div:nth-child(1)")
    tup_reposit = ("css", "#top_lab>div:nth-child(2)")
    tup_withdraw = ("css", "#top_lab>div:nth-child(3)")
    tup_consume = ("css", "#top_lab>div:nth-child(4)")
    tup_Bonus = ("css", "#top_lab>div:nth-child(5)")
    tup_deal = ("css", "#top_lab>div:nth-child(6)")
    
    def gotoBetRecord(self):
        pass

    def gotoRepositRecord(self):
        self.click(self.tup_reposit)
        return DepositRecordPage(self.getDriver())

    def gotoWithdraw(self):
        """
        跳转到用户管理中心-->交易记录-->提款记录页面。
        :return: 
        """
        self.click(self.tup_withdraw)
        return WithdrawRecordPage(self.getDriver())

    def gotoBetConsume(self):
        pass

    def gotoBonusRecord(self):
        pass

    def gotoDealDetail(self):
        self.click(self.tup_deal)
        return DealDetailPage(self.getDriver())
