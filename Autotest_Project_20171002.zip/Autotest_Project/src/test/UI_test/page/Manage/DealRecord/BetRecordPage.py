#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/6/1 11:53
# @Author  : Terry
from src.test.UI_test.common.common import TestResult
from src.test.UI_test.page.Manage.DealRecord.DealRecordBase import DealRecordBase


class BetRecordPage(DealRecordBase):

    lis_lottery = {
        u"所有彩种",
        u"三分时时彩",
        u"重庆时时彩",
        u"北京PK拾",
        u"幸运28",
        u"福彩3D",
        u"排列三",
        u"上海时时乐",
        u"天津时时彩",
        u"新疆时时彩",
        u"江苏快三",
        u"安徽快三",
        u"山东11选5",
        u"上海11选5",
        u"江西11选5",
        u"广东11选5",
        u"广西快三"
    }
    lis_bet_type = [u"全部投注", u"普通投注", u"追号投注"]
    lis_date_scope = [u"今天", u"昨天", u"前天", u"最近"]

    tup_search_button = ("css", "#bet_div .btn_search")

    tup_lottery = ("css", ".game_select")
    tup_bet_type = ("css", ".type_select")
    tup_date_scope = ("css", "#bet_div .datatype_select")
    tup_table = ("css", "#bet_div .content>table>tbody")
    tup_popup_table = ("css", ".data.data-order>table>tbody")
    tup_close_popup = ("css", "#block_close")

    tup_revert_bet = ("css", "#clearNum")  # 撤单按钮
    tup_confirm_btn = ("css", ".btn_ok")
    tup_alert_btn = ("css", "#_alert_ .btn_ok")

    def setLottery(self, str_lottery):
        if str_lottery in self.lis_lottery:
            self.selectByVisibleText(self.tup_lottery, str_lottery)
        else:
            raise KeyError("\nInvalid lottery: %s.\nLottery should be one of %s."
                           % (str_lottery, ", ".join(self.lis_lottery)))

    def setBetType(self, str_bet_type):
        if str_bet_type in self.lis_bet_type:
            self.selectByVisibleText(self.tup_bet_type, str_bet_type)
        else:
            raise KeyError("\nInvalid bet type: %s.\nBet type should be one of %s."
                           % (str_bet_type, ", ".join(self.lis_bet_type)))

    def search(self, str_bet_time=None, str_record_num="5", str_lottery=u"所有彩种", str_bet_type=u"全部投注", str_date_scope=u"今天"):
        """
        筛选出符合条件的条目，返回该条目的玩法、单注金额和投注总额。
        :param str_bet_time: 投注时间。
        :param str_record_num: 每页表格展示条目的数量，例如，10。
        :param str_lottery: 彩种，例如，北京PK拾。
        :param str_bet_type: 投注类型，例如，普通投注。
        :param str_date_scope: 日期范围，例如，今天。
        :return: 返回玩法、单注金额和投注总额
        """
        result = TestResult()
        # 依据条件进行搜索
        self.setRecordNum(str_record_num)
        self.setLottery(str_lottery)
        self.setBetType(str_bet_type)
        self.setDateScope(str_date_scope)
        self.click(self.tup_search_button)

        # 依据str_bet_time在表格中找出对应的投注记录，
        # 若str_bet_time==None,则取表格中第一条数据。
        if str_bet_time is None:
            lis_row = [0]
        else:
            lis_row = self.getTargetRow(str_bet_time, self.tup_table, 1)
        if 0 < len(lis_row):
            # 点击符合投注时间的第一条数据。
            self.clickCell(self.tup_table, lis_row[0], 4)
            self.waitElementVisible(self.tup_popup_table)
        else:
            raise Exception("\nCan not find any item in the table according to the given bet time: %s" % str_bet_time)
        result.bet_item = len(lis_row)
        result.method = self.getCellText(self.tup_popup_table, 4, 1)
        result.each_money = self.getCellText(self.tup_popup_table, 0, 3)
        result.bet_money = self.getCellText(self.tup_popup_table, 2, 3)
        result.status = self.getCellText(self.tup_popup_table, 6, 1)
        self.waitElementVisible(self.tup_close_popup)
        # 点击时等待一秒
        self.click(self.tup_close_popup)
        return result

    def revertBet(self):
        """
        投注记录页面撤单。
        选取页面表格中第一条数据，撤单。
        :return: 
        """
        self.clickCell(self.tup_table, 0, 7)  # 选取表格中第一条数据
        self.click(self.tup_revert_bet)  # 点击撤单按钮
        self.waitElementVisible(self.tup_confirm_btn)
        self.click(self.tup_confirm_btn)  # 点击第一个弹窗中的确定按钮
        self.waitElementVisible(self.tup_alert_btn)
        self.click(self.tup_alert_btn)  # 点击第二个弹窗中的确定按钮

