#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/8/29 9:48
# @Author  : Terry
import time

from src.test.UI_test.common.common import TestResult
from src.test.UI_test.page.Widget import Widget


class LHCBase(Widget):
    # 六合彩彩种对应的玩法和投注号码
    dic_bet_num = {}
    dic_model = {
        u"特码": {
            "locator": ("css", "[data-href='tm']"),
            "model2": {
                u"特码A": ("css", "[data-type='a']"),
                u"特码B": ("css", "[data-type='b']")
            }
        },
        u"两面":{
            "locator": ("css", "[data-href='lm']"),
            "model2": {}
        },
        u"色波": {
            "locator": ("css", "[data-href='sb']"),
            "model2": {}
        },
        u"特肖": {
            "locator": ("css", "[data-href='12sx']"),
            "model2": {}
        },
        u"合肖":{
            "locator": ("css", "[data-href='hx']"),
            "model2": {}
        },
        u"头尾数":{
            "locator": ("css", "[data-href='tws']"),
            "model2": {}
        },
        u"正码": {
            "locator": ("css", "[data-href='zm']"),
            "model2": {}
        },
        u"正码特": {
            "locator": ("css", "[data-href='zmt']"),
            "model2": {
                u"正一特": ("css", "[index='1']"),
                u"正二特": ("css", "[index='2']"),
                u"正三特": ("css", "[index='3']"),
                u"正四特": ("css", "[index='4']"),
                u"正五特": ("css", "[index='5']"),
                u"正六特": ("css", "[index='6']"),
            }
        },
        u"正码1-6":{
            "locator": ("css", "[data-href='zm16']"),
            "model2": {}
        },
        u"五行":{
            "locator": ("css", "[data-href='wx']"),
            "model2": {}
        },
        u"平特一肖尾数": {
            "locator": ("css", "[data-href='yx']"),
            "model2": {
                u"平特一肖": ("css", "[index='1']"),
                u"平特尾数": ("css", "[index='2']")
            }
        },
        u"正肖":{
            "locator": ("css", "[data-href='zx']"),
            "model2": {}
        },
        u"7色波":{
            "locator": ("css", "[data-href='7sb']"),
            "model2": {}
        },
        u"总肖":{
            "locator": ("css", "[data-href='zxs']"),
            "model2": {}
        },
        u"自选不中": {
            "locator": ("css", "[data-href='zxbz']"),
            "model2": {}
        },
        u"连肖连尾":{
            "locator": ("css", "[data-href='dpelx']"),
            "model2": {
                u"二连肖": ("css", "[title='二连肖']"),
                u"三连肖": ("css", "[title='三连肖']"),
                u"四连肖": ("css", "[title='四连肖']"),
                u"五连肖": ("css", "[title='五连肖']"),
                u"二连尾": ("css", "[title='二连尾']"),
                u"三连尾": ("css", "[title='三连尾']"),
                u"四连尾": ("css", "[title='四连尾']"),
                u"五连尾": ("css", "[title='五连尾']"),
            }
        },
        u"连码":{
            "locator": ("css", "[data-href='mp']"),
            "model2": {
                u"三中二": ("css", "[types='三中二']"),
                u"三全中": ("css", "[types='三全中']"),
                u"二全中": ("css", "[types='二全中']"),
                u"二中特": ("css", "[types='二中特']"),
                u"特串": ("css", "[types='特串']"),
                u"四全中": ("css", "[types='四全中']"),
            }
        }
    }

    # 页面元素
    tup_model2_iframe = ("css", "#frame")  # 六合彩的小玩法所在的内层frame

    tup_money = ("css", ".quickmoney")  # 预设金额
    tup_confirm_bet_btn = ("css", "[value='确定']")  # 确定按钮
    tup_reset_btn = ("css", "[value='重置']")  # 重置按钮
    tup_quick_bet = ("css", "#bntquick")  # 快捷投注

    # 弹窗1：下注明细(请确认注单)
    tup_popup_message1 = ("css", "#ui-id-1")
    tup_total_money = ("css", "#btotal")
    tup_confirm_btn = ("css", "#confirmbtn")
    tup_cancel_btn = ("css", "[onclick='closeConfirm()']")

    # 弹窗2：提示成功信息
    tup_popup_message2 = ("css", "#content")
    tup_close_btn = ("css", "#moveheader>p>button")

    def giveCodesMoney(self, testdata):
        """
        选择投注号码，设置投注金额。
        :return: 
        """
        if testdata.has_pre_money:  # 设置预设金额
            self.jsType(self.tup_money, testdata.pre_money)
        if testdata.has_individual_money:  # 为每个投注号码分别设置金额
            if len(testdata.codes[0]) == len(testdata.individual_money):  # 投注号码与金额一一对应
                for i in range(len(testdata.individual_money)):
                    code = testdata.codes[0][i]
                    self.waitElementPresent(self.dic_bet_num[code])
                    self.jsClick(self.dic_bet_num[code])  # 点击一次，选中该号码
                    self.jsType(self.dic_bet_num[code], testdata.individual_money[i])  # 输入投注金额
            else:
                raise Exception("\nCodes can't match money.\ncodes: %s.\nmoney: %s."
                                % (str(testdata.codes[0]), str(testdata.individual_money)))
        else:
            for i in range(len(testdata.codes[0])):
                code = testdata.codes[0][i]
                self.jsClick(self.dic_bet_num[code])  # 点击一次，选中该号码

    def _gotomodel2(self, str_model1, str_model2):
        """
        跳转到小玩法，例如直选复式，直选单式。
        :param str_model1: 
        :param str_model2: 
        :return: 
        """
        if self.dic_model[str_model1]["model2"]:
            if str_model2 in self.dic_model[str_model1]["model2"].keys():
                self.waitElementVisible(self.tup_model2_iframe)
                self.switch_to_frame(self.tup_model2_iframe)
                str_model2_locator = self.dic_model[str_model1]["model2"][str_model2]
                self.waitElementVisible(str_model2_locator)
                self.jsClick(str_model2_locator)
        else:
            self.waitElementVisible(self.tup_model2_iframe)  # 切入到投注号码所在的frame
            self.switch_to_frame(self.tup_model2_iframe)
    def gotoGameMethod(self, str_model1, str_model2):
        """
        跳转到指定玩法。
        :param str_model1: 大玩法，例如前一，前二。
        :param str_model2: 小玩法，例如直选复式。
        :return: 
        """
        self._gotomodel1(str_model1)
        time.sleep(2)  # 若不加延时，则无法进入特码A
        self._gotomodel2(str_model1, str_model2)

    # 以下为业务流程
    def bet_normal(self, testdata):
        """
        六合彩正常投注流程。
        :param testdata: 
        :return: 
        """
        result = TestResult()
        if testdata.has_quick_bet:
            self.jsClick(self.tup_quick_bet)
        self.giveCodesMoney(testdata)
        self.jsClick(self.tup_confirm_bet_btn)
        self.switch_to_parent_frame()  # 弹窗在投注号码的上层iframe中
        self.waitElementVisible(self.tup_popup_message1)
        result.message_confirm_bet = self.getText(self.tup_popup_message1)
        result.deal_money = self.getText(self.tup_total_money)
        self.click(self.tup_confirm_btn)
        self.waitElementVisible(self.tup_popup_message2)

        # 显示投注成功与否的弹窗，其内容会变化。
        # 首先，显示“请稍等正在投注。。。。。。”
        # 然后，显示“恭喜，下注成功！！！”
        message_bet_success = None
        for i in range(100):
            try:
                result.message_bet_success = message_bet_success
                message_bet_success = self.getText(self.tup_popup_message2)
            except:
                break  # 若获取文本失败时，则认为弹窗已经消失，不再继续获取文本。
            if result.message_bet_success is not None and result.message_bet_success != message_bet_success:
                # 若本次获取的文本与上次获取的文本不一致，则认为获取到了“恭喜，下注成功！！！”文本。
                result.message_bet_success = message_bet_success
                break
        return result

    def insufficient(self, testdata):
        """
        玩家投注时，余额不足的流程。
        :param testdata: 
        :return: 
        """
        result = TestResult()
        if testdata.has_quick_bet:
            self.jsClick(self.tup_quick_bet)
        self.giveCodesMoney(testdata)
        self.jsClick(self.tup_confirm_bet_btn)
        self.switch_to_parent_frame()  # 弹窗在投注号码的上层iframe中
        self.waitElementVisible(self.tup_popup_message1)
        result.message_confirm_bet = self.getText(self.tup_popup_message1)
        self.click(self.tup_confirm_btn)
        self.waitElementVisible(self.tup_popup_message2)
        result.message_bet_insufficient = self.getText(self.tup_popup_message2)
        self.click(self.tup_close_btn)
        return result

    def no_codes(self, testdata):
        """
        玩家投注时，不选择投注号码，就点击确定按钮。
        :param testdata: 
        :return: 
        """
        result = TestResult()
        self.jsClick(self.tup_confirm_bet_btn)
        self.switch_to_parent_frame()  # 弹窗在投注号码的上层iframe中
        self.waitElementVisible(self.tup_popup_message2)
        result.message_wrong_codes = self.getText(self.tup_popup_message2)
        self.click(self.tup_close_btn)
        return result

    def reset(self, testdata):
        """
        玩家输入投注号码和金额后，点击“重置”按钮。
        :param testdata: 
        :return: 
        """
        result = TestResult()
        if testdata.has_quick_bet:
            self.jsClick(self.tup_quick_bet)
        self.giveCodesMoney(testdata)
        self.jsClick(self.tup_reset_btn)  # 点击重置按钮
        self.jsClick(self.tup_confirm_bet_btn)  # 点击确认按钮
        self.switch_to_parent_frame()  # 弹窗在投注号码的上层iframe中
        self.waitElementVisible(self.tup_popup_message2)
        result.message_wrong_codes = self.getText(self.tup_popup_message2)
        self.click(self.tup_close_btn)
        return result

    def invalid_money(self, testdata):
        """
        玩家输入无效的投注金额。
        :param testdata: 
        :return: 
        """
        result = TestResult()
        if testdata.has_quick_bet:
            self.jsClick(self.tup_quick_bet)
        self.giveCodesMoney(testdata)
        self.jsClick(self.tup_confirm_bet_btn)
        self.switch_to_parent_frame()  # 弹窗在投注号码的上层iframe中
        self.waitElementVisible(self.tup_popup_message1)
        result.message_confirm_bet = self.getText(self.tup_popup_message1)
        result.deal_money = self.getText(self.tup_total_money)
        self.click(self.tup_confirm_btn)
        self.waitAlertPresent()
        result.message_invalid_money = self.getAlertText()
        self.acceptAlert()
        self.click(self.tup_cancel_btn)
        return result
