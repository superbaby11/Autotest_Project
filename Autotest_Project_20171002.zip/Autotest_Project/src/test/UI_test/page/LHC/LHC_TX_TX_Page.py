#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/9/4 9:27
# @Author  : Terry
from src.test.UI_test.page.LHC.LHCBase import LHCBase


class LHC_TX_TX_Page(LHCBase):
    # 六合彩特肖玩法的投注号码
    dic_bet_num = {
        u"鼠": ("css", "[name='鼠']"),
        u"牛": ("css", "[name='牛']"),
        u"虎": ("css", "[name='虎']"),
        u"兔": ("css", "[name='兔']"),
        u"龙": ("css", "[name='龙']"),
        u"蛇": ("css", "[name='蛇']"),
        u"马": ("css", "[name='马']"),
        u"羊": ("css", "[name='羊']"),
        u"猴": ("css", "[name='猴']"),
        u"鸡": ("css", "[name='鸡']"),
        u"狗": ("css", "[name='狗']"),
        u"猪": ("css", "[name='猪']"),
    }
