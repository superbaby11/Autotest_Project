#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/9/4 9:27
# @Author  : Terry
from src.test.UI_test.page.LHC.LHCBase import LHCBase


class LHC_SB_SB_Page(LHCBase):
    # 六合彩色波玩法的投注号码
    dic_bet_num = {
        u"红波": ("css", "#k_SB_R"),
        u"蓝波": ("css", "#k_SB_B"),
        u"绿波": ("css", "#k_SB_G"),
        u"红单": ("css", "[name='红单']"),
        u"红双": ("css", "[name='红双']"),
        u"红大": ("css", "[name='红大']"),
        u"红小": ("css", "[name='红小']"),
        u"蓝单": ("css", "[name='蓝单']"),
        u"蓝双": ("css", "[name='蓝双']"),
        u"蓝大": ("css", "[name='蓝大']"),
        u"蓝小": ("css", "[name='蓝小']"),
        u"绿单": ("css", "[name='绿单']"),
        u"绿双": ("css", "[name='绿双']"),
        u"绿大": ("css", "[name='绿大']"),
        u"绿小": ("css", "[name='绿小']"),
        u"红大单": ("css", "[name='红大单']"),
        u"红大双": ("css", "[name='红大双']"),
        u"红小单": ("css", "[name='红小单']"),
        u"红小双": ("css", "[name='红小双']"),
        u"蓝大单": ("css", "[name='蓝大单']"),
        u"蓝大双": ("css", "[name='蓝大双']"),
        u"蓝小单": ("css", "[name='蓝小单']"),
        u"蓝小双": ("css", "[name='蓝小双']"),
        u"绿大单": ("css", "[name='绿大单']"),
        u"绿大双": ("css", "[name='绿大双']"),
        u"绿小单": ("css", "[name='绿小单']"),
        u"绿小双": ("css", "[name='绿小双']"),
    }