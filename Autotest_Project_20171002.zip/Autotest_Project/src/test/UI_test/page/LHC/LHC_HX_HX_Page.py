#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/9/4 9:27
# @Author  : Terry
from src.test.UI_test.page.LHC.LHCBase import LHCBase


class LHC_HX_HX_Page(LHCBase):
    # 六合彩合肖玩法的投注号码
    dic_bet_num = {
        u"鼠": ("css", "[value='0']"),
        u"牛": ("css", "[value='1']"),
        u"虎": ("css", "[value='2']"),
        u"兔": ("css", "[value='3']"),
        u"龙": ("css", "[value='4']"),
        u"蛇": ("css", "[value='5']"),
        u"马": ("css", "[value='6']"),
        u"羊": ("css", "[value='7']"),
        u"猴": ("css", "[value='8']"),
        u"鸡": ("css", "[value='9']"),
        u"狗": ("css", "[value='10']"),
        u"猪": ("css", "[value='11']"),
    }
