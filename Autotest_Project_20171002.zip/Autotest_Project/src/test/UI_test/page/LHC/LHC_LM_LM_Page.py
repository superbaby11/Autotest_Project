#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/9/4 9:27
# @Author  : Terry
from src.test.UI_test.page.LHC.LHCBase import LHCBase


class LHC_LM_LM_Page(LHCBase):
    # 六合彩两面玩法的投注号码
    dic_bet_num = {
        u"特大": ("css", "[name='特大']"),
        u"特小": ("css", "[name='特小']"),
        u"特尾大": ("css", "[name='特尾大']"),
        u"特尾小": ("css", "[name='特尾小']"),
        u"特单": ("css", "[name='特单']"),
        u"特双": ("css", "[name='特双']"),
        u"特合大": ("css", "[name='特合大']"),
        u"特合小": ("css", "[name='特合小']"),
        u"特合单": ("css", "[name='特合单']"),
        u"特合双": ("css", "[name='特合双']"),
        u"特天肖": ("css", "[name='特天肖']"),
        u"特地肖": ("css", "[name='特地肖']"),
        u"特前肖": ("css", "[name='特前肖']"),
        u"特后肖": ("css", "[name='特后肖']"),
        u"特家肖": ("css", "[name='特家肖']"),
        u"特野肖": ("css", "[name='特野肖']"),
        u"总大": ("css", "[name='总大']"),
        u"总小": ("css", "[name='总小']"),
        u"总单": ("css", "[name='总单']"),
        u"总双": ("css", "[name='总双']"),
    }