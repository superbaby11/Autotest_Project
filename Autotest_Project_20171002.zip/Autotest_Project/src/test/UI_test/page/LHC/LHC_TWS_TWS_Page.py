#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/9/4 9:27
# @Author  : Terry
from src.test.UI_test.page.LHC.LHCBase import LHCBase


class LHC_TWS_TWS_Page(LHCBase):
    # 六合彩头尾数玩法的投注号码
    dic_bet_num = {
        u"0头": ("css", "[name='0头']"),
        u"1头": ("css", "[name='1头']"),
        u"2头": ("css", "[name='2头']"),
        u"3头": ("css", "[name='3头']"),
        u"4头": ("css", "[name='4头']"),
        u"1尾": ("css", "[name='1尾']"),
        u"2尾": ("css", "[name='2尾']"),
        u"3尾": ("css", "[name='3尾']"),
        u"4尾": ("css", "[name='4尾']"),
        u"5尾": ("css", "[name='5尾']"),
        u"6尾": ("css", "[name='6尾']"),
        u"7尾": ("css", "[name='7尾']"),
        u"8尾": ("css", "[name='8尾']"),
        u"9尾": ("css", "[name='9尾']"),
        u"0尾": ("css", "[name='0尾']"),
    }
