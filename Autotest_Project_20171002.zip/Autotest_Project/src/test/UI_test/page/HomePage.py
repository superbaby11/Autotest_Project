#!/usr/bin/env python
# coding:utf-8
# Created on 2017年3月23日
# __author__ = 'Jason'
import time

from src.test.UI_test.page.GLHT.GlhtLoginPage import GlhtLoginPage
from src.test.UI_test.page.GcdtPage import GcdtPage
from src.test.UI_test.page.Manage.DealRecord.DealRecordNavigator import DealRecordNavigator
from src.test.UI_test.page.Manage.Deposit.DepositNavigator import DepositNavigator
from src.test.UI_test.page.Manage.Withdraw.WithdrawPage import WithdrawPage
from src.test.UI_test.page.RegistPage import RegistPage

from BasePage import BasePage
from src.utils.config import DefaultConfig_Project


class HomePage(BasePage):
    """description of class"""

    # 正常登录后，页面顶部的用户中心、充值、提现、交易记录等按钮
    tup_username = ('name', 'user_name')  # 用户名称
    tup_usercenter = ('css', '.top_login>span:nth-child(5)>a:nth-child(1)')  # 用户中心
    tup_deposit = ('css', '.top_login>span>a:nth-child(2)')  # 充值
    tup_withdraw = ('css', '.top_login>span>a:nth-child(3)')  # 提现
    tup_deal_record = ('css', '.top_login>span>a:nth-child(4)')  # 交易记录
    tup_logout = ('css', '.top_login>span>a:nth-child(6)')  # 退出

    # 购彩大厅按钮
    tup_gcdt = ('xpath', '//*[@id="header_box"]/ul/li[2]/a')
    # 首页的注册按钮
    tup_regist = ('xpath', '//*[@id="logxinxi"]/div/div/div[2]/input[2]')
    # login
    username = ('name', 'username')
    password = ('name', 'passwd')
    authnum = ('name', 'authnum')
    loginButton = ('name', 'login')

    # logout
    logout_link = ('link_text', u'退出')
    logout_url = DefaultConfig_Project().base_url + 'index/logOut.html'
        
    # 异常登录弹出页面
    popMessage = ("xpath", "//*[@id='_alert_']/div/p")
    abnormalSubmit = ('xpath', "//div[@id='_alert_']/div/button")
    
    def gotoGcdtPage(self):
        """
        跳转到购彩大厅页面
        :return: 返回购彩大厅页面实例。
        """
        self.open()
        self.waitElementVisible(self.tup_gcdt)
        self.click(self.tup_gcdt)
        self.switch_to_window(1)  # 跳转到第一个弹出页面：购彩大厅页面。
        self.maximizeWindow()
        time.sleep(1)
        return GcdtPage(self.getDriver())

    def gotoRegistPage(self):
        """
        跳转到注册页面。
        :return: 返回注册页面实例。
        """
        self.open()
        self.waitElementVisible(self.tup_regist)
        self.click(self.tup_regist)
        return RegistPage(self.getDriver())

    def gotoDepositPage(self):
        """
        跳转到充值页面。
        :return: 返回充值页面实例。
        """
        self.open()
        self.waitElementVisible(self.tup_deposit)
        self.click(self.tup_deposit)
        self.switch_to_window(self.getWindowHandles()[-1])  # 跳转到最后1个弹出页面：在线存款页面。
        self.maximizeWindow()
        time.sleep(1)
        return DepositNavigator(self.getDriver())

    def gotoWithdrawPage(self):
        """
        跳转到在线提款页面。
        :return: 
        """
        self.open()
        self.waitElementVisible(self.tup_withdraw)
        self.click(self.tup_withdraw)
        self.switch_to_window(self.getWindowHandles()[-1])  # 跳转到最后1个弹出页面：在线提款页面。
        self.maximizeWindow()
        time.sleep(1)
        return WithdrawPage(self.getDriver())

    def gotoDealRecordPage(self):
        """
        跳转到交易记录页面。
        :return: 
        """
        self.open()
        self.waitElementVisible(self.tup_deal_record)
        self.click(self.tup_deal_record)
        self.switch_to_window(self.getWindowHandles()[-1])  # 跳转到最后1个弹出页面：在线存款页面。
        self.maximizeWindow()
        time.sleep(1)
        return DealRecordNavigator(self.getDriver())

    def gotoGlhtPage(self):
        """
        在新的页面打开管理后台。
        :return: 
        """
        self.scrollToTop()
        self.click(self.tup_gcdt)
        self.switch_to_window(self.getWindowHandles()[-1])  # 跳转到最后1个弹出页面：购彩大厅页面。
        self.maximizeWindow()
        str_back_url = DefaultConfig_Project().get("url", "back_url")
        self.open(str_back_url)  # 跳转到管理后台页面
        return GlhtLoginPage(self.getDriver())

    def loginNormal(self, user_name, pass_word, acc=None, auth_num=1111):
        result = -1
        self.type(self.username, user_name)
        self.click(self.password)
        self.type(self.password, pass_word)
        self.type(self.authnum, auth_num)
        if acc is None:
            acc = user_name
        self.click(self.loginButton)
        self.waitElementText(self.tup_username, acc, secs=5)
        result = 0
        return result

    def loginAbnormal(self, user_name, pass_word, auth_num=1111):
        self.type(self.username, user_name)
        self.click(self.password)
        self.type(self.password, pass_word)
        self.type(self.authnum, auth_num)
        self.click(self.loginButton)
        time.sleep(1)
        pop_message = self.getText(self.popMessage)
        if self.getDisplay(self.abnormalSubmit):
            self.click(self.abnormalSubmit)
        time.sleep(1)
        return pop_message

    def logout(self):
        self.open(self.logout_url)
        time.sleep(1)


if __name__ == "__main__":
    a = HomePage()
    a.open()
    a.loginNormal('jtest', 'j12345')
    print 'okkkkk'
    time.sleep(4)
    a.logout()
    time.sleep(4)
    print 'nooooo'
    a.quit()
    print 'ok'
