#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/6/24 10:22
# @Author  : Terry
from src.test.UI_test.page.Widget import Widget


class PLSBase(Widget):
    # PLS彩种对应的玩法
    dic_model = {
        u"三星": {
            "locator": ("css", "#tabbar-div-s2 > span:nth-child(1) > span.content"),
            "model2": {
                u"直选复式": ("css", "#smalllabel_0_0"),
                u"直选单式": ("css", "#smalllabel_0_1"),
                u"直选和值": ("css", "#smalllabel_0_2"),
                u"组三复式": ("css", "#smalllabel_1_0"),
                u"组六复式": ("css", "#smalllabel_1_1"),
                u"组三和值": ("css", "#smalllabel_1_2"),
                u"组六和值": ("css", "#smalllabel_1_3")
            }
        },
        u"二星":{
            "locator": ("css", "#tabbar-div-s2 > span:nth-child(2) > span.content"),
            "model2": {}
        },
        u"定位胆": {
            "locator": ("css", "#tabbar-div-s2 > span:nth-child(3) > span.content"),
            "model2": {}
        },
        u"不定位": {
            "locator": ("css", "#tabbar-div-s2 > span:nth-child(4) > span.content"),
            "model2": {}
        },
        u"大小单双": {
            "locator": ("css", "#tabbar-div-s2 > span:nth-child(5) > span.content"),
            "model2": {}
        }
    }
