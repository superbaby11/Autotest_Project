#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/6/24 13:27
# @Author  : Terry
from src.test.UI_test.page.PLS.PLSBase import PLSBase


class PLS_SX_ZXDS_Page(PLSBase):
    pass
