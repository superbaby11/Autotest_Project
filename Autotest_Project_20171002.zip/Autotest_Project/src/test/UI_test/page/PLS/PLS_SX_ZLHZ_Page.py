#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/6/26 13:51
# @Author  : Terry
from src.test.UI_test.page.PLS.PLSBase import PLSBase


class PLS_SX_ZLHZ_Page(PLSBase):
    # 排列三 三星 组六和值 对应的号码
    dic_bet_num = {
        1: {
            u"3": "#wei__3",
            u"4": "#wei__4",
            u"5": "#wei__5",
            u"6": "#wei__6",
            u"7": "#wei__7",
            u"8": "#wei__8",
            u"9": "#wei__9",
            u"10": "#wei__10",
            u"11": "#wei__11",
            u"12": "#wei__12",
            u"13": "#wei__13"
        },
        2: {
            u"14": "#wei__14",
            u"15": "#wei__15",
            u"16": "#wei__16",
            u"17": "#wei__17",
            u"18": "#wei__18",
            u"19": "#wei__19",
            u"20": "#wei__20",
            u"21": "#wei__21",
            u"22": "#wei__22",
            u"23": "#wei__23",
            u"24": "#wei__24"
        }
    }