#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/9/18 9:40
# @Author  : Terry
from src.test.UI_test.page.KLPK.KLPKBase import KLPKBase


class KLPK_RXFS_RX1_Page(KLPKBase):
    # 快乐扑克任选复式/任选一玩法的投注号码
    dic_bet_num = {
        1: {
            u"A": ".gd>span>div:nth-child(1)",
            u"2": ".gd>span>div:nth-child(2)",
            u"3": ".gd>span>div:nth-child(3)",
            u"4": ".gd>span>div:nth-child(4)",
            u"5": ".gd>span>div:nth-child(5)",
            u"6": ".gd>span>div:nth-child(6)",
            u"7": ".gd>span>div:nth-child(7)",
            u"8": ".gd>span>div:nth-child(8)",
            u"9": ".gd>span>div:nth-child(9)",
            u"10": ".gd>span>div:nth-child(10)",
            u"J": ".gd>span>div:nth-child(11)",
            u"Q": ".gd>span>div:nth-child(12)",
            u"K": ".gd>span>div:nth-child(13)",
        }
    }
