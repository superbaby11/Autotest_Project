#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/9/18 9:16
# @Author  : Terry
from src.test.UI_test.page.Widget import Widget


class KLPKBase(Widget):
    # 快乐扑克彩种对应的玩法
    dic_model = {
        u"同花": {
            "locator": ("css", "#tabbar-div-s2 > span:nth-child(1) > span.content"),
            "model2": {
                u"包选": ("css", "#smalllabel_0_0"),
                u"单选": ("css", "#smalllabel_0_1")
            }
        },
        u"顺子": {
            "locator": ("css", "#tabbar-div-s2 > span:nth-child(2) > span.content"),
            "model2": {
                u"包选": ("css", "#smalllabel_0_0"),
                u"单选": ("css", "#smalllabel_0_1")
            }
        },
        u"同花顺": {
            "locator": ("css", "#tabbar-div-s2 > span:nth-child(3) > span.content"),
            "model2": {
                u"包选": ("css", "#smalllabel_0_0"),
                u"单选": ("css", "#smalllabel_0_1")
            }
        },
        u"同号": {
            "locator": ("css", "#tabbar-div-s2 > span:nth-child(4) > span.content"),
            "model2": {
                u"豹子包选": ("css", "#smalllabel_0_0"),
                u"豹子单选": ("css", "#smalllabel_0_1"),
                u"对子包选": ("css", "#smalllabel_1_0"),
                u"对子单选": ("css", "#smalllabel_1_1")
            }
        },
        u"任选复式":{
            "locator": ("css", "#tabbar-div-s2 > span:nth-child(5) > span.content"),
            "model2": {
                u"任选一": ("css", "#smalllabel_0_0"),
                u"任选二": ("css", "#smalllabel_0_1"),
                u"任选三": ("css", "#smalllabel_0_2"),
                u"任选四": ("css", "#smalllabel_0_3"),
                u"任选五": ("css", "#smalllabel_0_4"),
                u"任选六": ("css", "#smalllabel_0_5"),
            }
        },
        u"任选胆拖":{
            "locator": ("css", "#tabbar-div-s2 > span:nth-child(6) > span.content"),
            "model2": {
                u"任选二": ("css", "#smalllabel_0_0"),
                u"任选三": ("css", "#smalllabel_0_1"),
                u"任选四": ("css", "#smalllabel_0_2"),
                u"任选五": ("css", "#smalllabel_0_3"),
                u"任选六": ("css", "#smalllabel_0_4"),
            }
        }
    }
