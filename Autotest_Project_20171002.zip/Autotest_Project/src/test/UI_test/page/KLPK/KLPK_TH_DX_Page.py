#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/9/18 9:40
# @Author  : Terry
from src.test.UI_test.page.KLPK.KLPKBase import KLPKBase


class KLPK_TH_DX_Page(KLPKBase):
    # 快乐扑克同花单选玩法的投注号码
    dic_bet_num = {
        1: {
            u"黑桃": ".gdts>div:nth-child(1)",
            u"红桃": ".gdts>div:nth-child(2)",
            u"梅花": ".gdts>div:nth-child(3)",
            u"方块": ".gdts>div:nth-child(4)",
        }
    }
