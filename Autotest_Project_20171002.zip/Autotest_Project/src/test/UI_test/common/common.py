#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/6/1 9:27
# @Author  : Terry
import re

from src.utils.getdb import unicode_dict, sql_update, db_sqlserver_connect, sql_query


def update(str_message, str_current_issue, str_splitor="X"):
    """
    将当前期数插入到期待消息中。
    当投注成功时，会弹出“您确定加入 620927 期？”消息。
    测试数据中，【期待消息】为“您确定加入 X 期？”，无法与实际消息匹配。
    所以，该方法使用实际的当前期数替换【期待消息】中的字符X。
    :param str_message: 测试数据中的【期待消息】，例如“您确定加入 X 期？”。
    :param str_current_issue: 实际的当前期数，例如620927。
    :param str_splitor: 待替换的字符。
    :return: 返回更新后的【期待消息】
    """
    if len(str_message):
        pattern = re.compile(str_splitor)
        match = pattern.search(str_message)
        if match:
            lis_messsage = str_message.split(str_splitor)
            for i in range(len(lis_messsage)):
                lis_messsage[i] = lis_messsage[i].strip(' \t\n\r')
            return (" %s " % str_current_issue).join(lis_messsage)
        else:
            raise Exception("\nInvalid splitor.\nCan not find splitor:%s in message:%s." % (str_splitor, str_message))
    else:
        raise Exception("\nPop up message can not be empty!")


class DataBase(object):
    """
    数据库操作，比如删除用户，用户错误登录的次数归零。
    """
    @staticmethod
    def delete_user(str_acc):
        """
        删除用户。
        :param str_acc: 用户名。
        :return: 
        """
        str_sql_clean = u"DELETE from tuser WHERE sUserid = '%s'" % str_acc
        sql_update(db_sqlserver_connect(), str_sql_clean)

    @staticmethod
    def reset_wrong_count(str_acc):
        """
        将用户错误登录次数归零。
        :param str_acc: 用户名。
        :return: 
        """
        str_sql_reset = u"UPDATE tuser SET iWrongCount=0 WHERE sUserid = '%s'" % str_acc
        sql_update(db_sqlserver_connect(), str_sql_reset)

    @staticmethod
    def turn_on_turnpoint(str_acc):
        """
        允许用户进行转点。
        :param str_acc: 
        :return: 
        """
        str_sql = u"UPDATE [tuser]  SET iAllowTrans = 1 WHERE sUserid = '%s'" % str_acc
        sql_update(db_sqlserver_connect(), str_sql)

    @staticmethod
    def turn_off_turnpoint(str_acc):
        """
        禁止用户进行转点。
        :param str_acc: 
        :return: 
        """
        str_sql = u"UPDATE [tuser]  SET iAllowTrans = 0 WHERE sUserid = '%s'" % str_acc
        sql_update(db_sqlserver_connect(), str_sql)

    @staticmethod
    def zero_bet_need(str_acc):
        """
        将玩家出款的'所需投注量'置零。
        1)在sUserid表中查询玩家用户名对应的iUserKey;
        2)在tuserstatistics表中，将iUserKey对应的fBetNeed字段值置零。
        :param str_acc: 
        :return: 
        """
        str_sql = u"SELECT iUserKey from tuser WHERE sUserid='%s'" % str_acc
        lis_result = sql_query(db_sqlserver_connect(), str_sql)
        str_userkey = str(lis_result[0][0])
        str_sql = u"UPDATE [tuserstatistics] SET fBetNeed=0 WHERE iUserKey=%s" % str_userkey
        sql_update(db_sqlserver_connect(), str_sql)

    @staticmethod
    def delete_deposit_data(str_acc):
        """
        删除玩家的存款信息，下一次存款就可以获得首次存款优惠。
        1)在sUserid表中查询玩家用户名对应的iUserKey;
        2)在tuserstatistics、tdeposit、ttransactions表中，将iUserKey对应的数据删除。
        :param str_acc: 
        :return: 
        """
        str_sql = u"SELECT iUserKey from tuser WHERE sUserid='%s'" % str_acc
        lis_result = sql_query(db_sqlserver_connect(), str_sql)
        str_userkey = str(lis_result[0][0])
        str_sql = u"DELETE FROM tdeposit WHERE iUserKey=%s" % str_userkey
        sql_update(db_sqlserver_connect(), str_sql)
        str_sql = u"DELETE FROM tuserstatistics WHERE iUserKey=%s" % str_userkey
        sql_update(db_sqlserver_connect(), str_sql)
        str_sql = u"DELETE FROM ttransactions WHERE iUserKey=%s" % str_userkey
        sql_update(db_sqlserver_connect(), str_sql)


class TestData(object):
    """
    将测试数据存起来。使用哪个参数，就解析哪个参数。
    """
    def __init__(self, dic_input):
        self._dic_input = dic_input
        self._codes = None
        self._popupwindow1 = None
        self._username = None  # 前台账户
        self._password = None
        self._username_agent = None  # 前台代理会员
        self._password_withdraw = None  # 玩家取款密码

    @staticmethod
    def _unicode(str_data):
        """
        将str转为unicode，使用utf-8编码。
        :param str_data: 
        :return: 
        """
        if isinstance(str_data, unicode):
            return str_data
        elif isinstance(str_data, str):
            return unicode(str_data, "utf-8")
        else:
            raise Exception("\nParameter should be type of unicode or str.")

    @staticmethod
    def _encode(str_data):
        """
        将unicode转为str，使用utf-8编码。
        :param str_data: 
        :return: 
        """
        if isinstance(str_data, str):
            return str_data
        elif isinstance(str_data, unicode):
            return str_data.encode("utf-8")
        else:
            raise Exception("\nParameter should be type of unicode or str.")

    @property
    def username(self):
        """
        前台页面用户名。
        :return: 
        """
        if self._username is None:
            dic_case_data = self._get_case_data()
            try:
                self._username = self._unicode(dic_case_data["username"])
            except KeyError:
                raise KeyError("\nThere is no key: username, in case data.")
        return self._username

    @username.setter
    def username(self, account):
        """
        前台页面用户名。
        :return: 
        """
        self._username = account

    @property
    def password(self):
        """
        前台页面用户密码。
        :return: 
        """
        if self._password is None:
            dic_case_data = self._get_case_data()
            try:
                self._password = self._unicode(dic_case_data["password"])
            except KeyError:
                raise KeyError("\nThere is no key: password, in case data.")
        return self._password

    @password.setter
    def password(self, pwd):
        """
        前台页面用户密码。
        :return: 
        """
        self._password = pwd

    @property
    def username_agent(self):
        """
        前台页面代理会员。
        :return: 
        """
        if self._username_agent is None:
            dic_case_data = self._get_case_data()
            try:
                self._username_agent = self._unicode(dic_case_data["username_agent"])
            except KeyError:
                raise KeyError("\nThere is no key: username_agent, in case data.")
        return self._username_agent

    @username_agent.setter
    def username_agent(self, acc):
        """
        前台页面代理会员。
        """
        self._username_agent = acc

    # 玩家投注

    @property
    def model(self):
        """
        彩种，例如，北京PK拾。
        :return: 
        """
        try:
            str_model = self._unicode(self._dic_input["model"])
        except KeyError:
            raise KeyError("\nThere is no key: model.")
        return str_model

    @property
    def model1(self):
        """
        大玩法，例如，前一。
        :return: 
        """
        try:
            str_model1 = self._unicode(self._dic_input["model1"])
        except KeyError:
            raise KeyError("\nThere is no key: model1.")
        return str_model1

    @property
    def model2(self):
        """
        小玩法，例如，直选复式。
        :return: 
        """
        try:
            str_model2 = self._unicode(self._dic_input["model2"])
        except KeyError:
            raise KeyError("\nThere is no key: model2.")
        return str_model2

    def _get_case_data(self):
        """
        返回字典形式的测试数据。
        :return: 
        """
        try:
            dic_case_data = unicode_dict(self._dic_input["caseData"])
        except KeyError:
            raise KeyError("\nThere is no key caseData.")
        return dic_case_data

    @property
    def _bet_num(self):
        """
        复式投注号码。
        :return: 
        """
        dic_case_data = self._get_case_data()
        lis_codes = []
        try:
            str_codes = self._unicode(dic_case_data["codes"])
            for str_code in str_codes.split("+"):  # "+"符号分隔不同区域的号码，例如PK10中的前二的两个号码。
                lis_codes.append(str_code.split("|"))  # "|"符号分隔相同区域的不同投注，例如前一投注两个号码。
        except KeyError:
            raise KeyError("\nThere is no key: codes, in case data.")
        return lis_codes

    @property
    def _bet_num_basic(self):
        """
        单式投注号码。
        :return: 
        """
        dic_case_data = self._get_case_data()
        try:
            str_codes = self._unicode(dic_case_data["codes"])
        except KeyError:
            raise KeyError("\nThere is no key: codes, in case data.")
        return str_codes

    @property
    def codes(self):
        """
        返回投注号码。
        1）如果model2是ZXFS，那么返回列表类型投注号码；
        2）如果model2是ZXDS，并且codes字段存在，那么返回字符串类型的codes字段值； 
        3）如果model2是ZXDS，并且upload字段存在，那么返回字符串类型的upload字段值；
        4）其它情况报错。
        :return: 
        """
        # lis_type_1指需要在号码盘上选择投注号码的玩法
        lis_type_1 = [
            u"直选复式",
            u"后三组合",
            u"直选和值",
            u"直选跨度",
            u"组三复式",
            u"组六复式",
            u"组选和值",
            u"组选包胆",
            u"和值尾数",
            u"特殊号",
            u"和值",
            u"通选",
            u"单选",
            u"标准",
            u"胆拖",
            u"组三和值",
            u"组六和值",
            u"前三组合",
            u"组选复式",
            u"定位胆",
            u"前三一码",
            u"前三二码",
            u"后三一码",
            u"后三二码",
            u"前四一码",
            u"前四二码",
            u"后四一码",
            u"后四二码",
            u"五星一码",
            u"五星二码",
            u"五星三码",
            u"前二大小单双",
            u"后二大小单双",
            u"前三大小单双",
            u"后三大小单双",
            u"数投",
            u"红投",
            u"任选二",
            u"任选胆拖",
            u"连组",
            u"连组胆拖",
            u"连直",
            u"任选",
            u"前组",
            u"前组胆拖",
            u"前直",
            u"组选24",
            u"组选12",
            u"组选6",
            u"组选4",
            u"特码A",
            u"特码B",
            u"两面",
            u"色波",
            u"特肖",
            u"合肖",
            u"头尾数",
            u"正码",
            u"正一特",
            u"正二特",
            u"包选",
            u"单选",
            u"任选一",
        ]

        # lis_type_2指没有号码盘，但有文本框的玩法
        lis_type_2 = [
            u"直选单式",
            u"组三单式",
            u"组六单式",
            u"混合组选",
            u"组选单式"
        ]
        if self._codes is None:
            if self.model2 in lis_type_1:
                self._codes = self._bet_num
            elif self.model2 in lis_type_2:
                try:
                    self._codes = self._bet_num_basic
                except KeyError:
                    self._codes = self._upload
            else:
                raise Exception("\nCan not find codes or upload file with method: %s." % self.model2)
        return self._codes

    @codes.setter
    def codes(self, code):
        self._codes = code

    @property
    def has_codes(self):
        """
        若测试数据中包含codes，则返回True；否则，返回False。
        :return: 
        """
        if "codes" in self._get_case_data().keys():
            return True
        else:
            return False

    @property
    def point(self):
        """
        返水百分比。
        :return: 
        """
        dic_case_data = self._get_case_data()
        try:
            str_point = self._unicode(dic_case_data["point"])
            flo_point = float(str_point.split("%")[0])
        except KeyError:
            raise KeyError("\nThere is no key: point, in case data.")
        return flo_point

    @property
    def has_point(self):
        """
        若测试数据中包含point字段，则返回True；否则，返回False。
        :return: 
        """
        if "point" in self._get_case_data().keys():
            return True
        else:
            return False

    @property
    def _upload(self):
        """
        直选单式中，上传文件的路径。
        :return: 
        """
        dic_case_data = self._get_case_data()
        try:
            str_upload = self._encode(dic_case_data["upload"])
        except KeyError:
            raise KeyError("\nThere is no key: upload, in case data.")
        return str_upload

    @property
    def has_upload(self):
        """
        若测试数据中包含upload字段，则返回True；否则，返回False。
        :return: 
        """
        if "upload" in self._get_case_data().keys():
            return True
        else:
            return False

    @property
    def popupwindow1(self):
        """
        投注后，第一个弹窗的内容。
        :return: 
        """
        if self._popupwindow1 is None:
            dic_case_data = self._get_case_data()
            try:
                self._popupwindow1 = self._unicode(dic_case_data["popupwindow1"])
            except KeyError:
                raise KeyError("\nThere is no key: popupwindow1, in case data.")
        return self._popupwindow1

    @popupwindow1.setter
    def popupwindow1(self, message):
        self._popupwindow1 = message

    @property
    def popupwindow2(self):
        """
        投注后，第二个弹窗的内容。
        :return: 
        """
        dic_case_data = self._get_case_data()
        try:
            str_popupwindow2 = self._unicode(dic_case_data["popupwindow2"])
        except KeyError:
            raise KeyError("\nThere is no key: popupwindow2, in case data.")
        return str_popupwindow2

    @property
    def popupwindow3(self):
        """
        第三个弹窗的内容。
        :return: 
        """
        dic_case_data = self._get_case_data()
        try:
            str_popupwindow3 = self._unicode(dic_case_data["popupwindow3"])
        except KeyError:
            raise KeyError("\nThere is no key: popupwindow3, in case data.")
        return str_popupwindow3

    @property
    def popupwindow4(self):
        """
        第四个弹窗的内容。
        :return: 
        """
        dic_case_data = self._get_case_data()
        try:
            str_popupwindow4 = self._unicode(dic_case_data["popupwindow4"])
        except KeyError:
            raise KeyError("\nThere is no key: popupwindow4, in case data.")
        return str_popupwindow4

    @property
    def income_and_expenses(self):
        """
        收支情况，例如，支出。
        :return: 
        """
        dic_case_data = self._get_case_data()
        try:
            str_income_and_expenses = self._unicode(dic_case_data["收支情况"])
        except KeyError:
            raise KeyError("\nThere is no key: '收支情况', in case data.")
        return str_income_and_expenses

    @property
    def income_and_expenses2(self):
        """
        收支情况，例如，支出。
        :return: 
        """
        dic_case_data = self._get_case_data()
        try:
            str_income_and_expenses = self._unicode(dic_case_data["收支情况2"])
        except KeyError:
            raise KeyError("\nThere is no key: '收支情况2', in case data.")
        return str_income_and_expenses

    @property
    def deal_type(self):
        """
        交易类型，例如，投注。
        :return: 
        """
        dic_case_data = self._get_case_data()
        try:
            str_deal_type = self._unicode(dic_case_data["交易类型"])
        except KeyError:
            raise KeyError("\nThere is no key: '交易类型', in case data.")
        return str_deal_type

    @property
    def deal_type2(self):
        """
        交易类型，例如，投注。
        :return: 
        """
        dic_case_data = self._get_case_data()
        try:
            str_deal_type = self._unicode(dic_case_data["交易类型2"])
        except KeyError:
            raise KeyError("\nThere is no key: '交易类型2', in case data.")
        return str_deal_type

    @property
    def deal_money(self):
        """
        交易金额，例如，30元。
        :return: 
        """
        dic_case_data = self._get_case_data()
        try:
            str_deal_money = self._unicode(dic_case_data["交易金额"])
        except KeyError:
            raise KeyError("\nThere is no key: '交易金额', in case data.")
        return str_deal_money

    @property
    def deal_money2(self):
        """
        交易金额，例如，30元。
        :return: 
        """
        dic_case_data = self._get_case_data()
        try:
            str_deal_money = self._unicode(dic_case_data["交易金额2"])
        except KeyError:
            raise KeyError("\nThere is no key: '交易金额2', in case data.")
        return str_deal_money

    @property
    def each_money(self):
        """
        投注记录页面的单注金额，例如，2元。
        :return: 
        """
        dic_case_data = self._get_case_data()
        try:
            str_each_money = self._unicode(dic_case_data["单注额"])
        except KeyError:
            raise KeyError("\nThere is no key: '单注额', in case data.")
        return str_each_money

    @property
    def money(self):
        """
        玩法页面的单注金额，例如，2元。
        :return: 
        """
        dic_case_data = self._get_case_data()
        try:
            str_money = self._unicode(dic_case_data["money"])
        except KeyError:
            raise KeyError("\nThere is no key: 'money', in case data.")
        return str_money

    @property
    def has_money(self):
        """
        若测试数据中包含money字段，则返回True；否则，返回False。
        :return: 
        """
        if "money" in self._get_case_data().keys():
            return True
        else:
            return False

    @property
    def pre_money(self):
        """
        六合彩的玩法页面的预设金额，例如，2元。
        :return: 
        """
        dic_case_data = self._get_case_data()
        try:
            str_pre_money = self._unicode(dic_case_data["pre_money"])
        except KeyError:
            raise KeyError("\nThere is no key: 'pre_money', in case data.")
        return str_pre_money

    @property
    def has_pre_money(self):
        """
        若测试数据中包含pre_money字段，则返回True；否则，返回False。
        :return: 
        """
        if "pre_money" in self._get_case_data().keys():
            return True
        else:
            return False

    @property
    def individual_money(self):
        """
        六合彩的玩法页面的单个号码的金额，例如，2元。
        :return: 
        """
        dic_case_data = self._get_case_data()
        try:
            lis_individual_money = []
            str_individual_money = self._unicode(dic_case_data["individual_money"])
            pattern = re.compile('^\d+$')
            if pattern.search(str_individual_money):
                lis_individual_money.append(str_individual_money)
            elif "|" in str_individual_money:
                # 若str_individual_money是2|3|4形式，则转成列表。适用于六合彩，每次投注多注。
                lis_individual_money = str_individual_money.split("|")
            else:
                raise Exception("\nBad value of individual_money: %s" % str_individual_money)
        except KeyError:
            raise KeyError("\nThere is no key: 'individual_money', in case data.")
        return lis_individual_money

    @property
    def has_individual_money(self):
        """
        若测试数据中包含individual_money字段，则返回True；否则，返回False。
        :return: 
        """
        if "individual_money" in self._get_case_data().keys():
            return True
        else:
            return False

    @property
    def has_quick_bet(self):
        """
        若测试数据中包含"快捷投注"字段，则返回True；否则，返回False。适用于六合彩。
        :return: 
        """
        if "快捷投注" in self._get_case_data().keys():
            return True
        else:
            return False

    @property
    def bet_money(self):
        """
        下注总额，例如，30元。
        :return: 
        """
        dic_case_data = self._get_case_data()
        try:
            str_each_money = self._unicode(dic_case_data["下注总额"])
        except KeyError:
            raise KeyError("\nThere is no key: '下注总额', in case data.")
        return str_each_money

    @property
    def methodid(self):
        """
        玩法，例如，前一直选/复式。
        :return: 
        """
        dic_case_data = self._get_case_data()
        try:
            str_methodid = self._unicode(dic_case_data["methodid"])
        except KeyError:
            raise KeyError("\nThere is no key: methodid, in case data.")
        return str_methodid

    @property
    def status(self):
        """
        订单状态，例如，退码。
        :return: 
        """
        dic_case_data = self._get_case_data()
        try:
            str_status = self._unicode(dic_case_data["状态"])
        except KeyError:
            raise KeyError("\nThere is no key: '状态', in case data.")
        return str_status

    @property
    def has_status(self):
        """
        若测试数据中包含'状态'字段，则返回True；否则，返回False。
        :return: 
        """
        if "状态" in self._get_case_data().keys():
            return True
        else:
            return False

    @property
    def times(self):
        """
        同倍追号的倍数，或者翻倍追号的起始倍数。
        :return: 
        """
        dic_case_data = self._get_case_data()
        try:
            str_times = self._unicode(dic_case_data["times"])
        except KeyError:
            raise KeyError("\nThere is no key: times, in case data.")
        return str_times

    @property
    def has_times(self):
        """
        若测试数据中包含times字段，则返回True；否则，返回False。
        :return: 
        """
        if "times" in self._get_case_data().keys():
            return True
        else:
            return False

    @property
    def term(self):
        """
        追号期数。
        :return: 
        """
        dic_case_data = self._get_case_data()
        try:
            str_term = self._unicode(dic_case_data["term"])
        except KeyError:
            raise KeyError("\nThere is no key: term, in case data.")
        return str_term

    @property
    def has_term(self):
        """
        若测试数据中包含term字段，则返回True；否则，返回False。
        :return: 
        """
        if "term" in self._get_case_data().keys():
            return True
        else:
            return False

    @property
    def skip(self):
        """
        翻倍追号时的间隔期数。
        :return: 
        """
        dic_case_data = self._get_case_data()
        try:
            str_skip = self._unicode(dic_case_data["skip"])
        except KeyError:
            raise KeyError("\nThere is no key: skip, in case data.")
        return str_skip

    @property
    def has_skip(self):
        """
        若测试数据中包含skip字段，则返回True；否则，返回False。
        :return: 
        """
        if "skip" in self._get_case_data().keys():
            return True
        else:
            return False

    @property
    def random(self):
        """
        随机投注的数量，随机1注或者随机5注。
        :return: 
        """
        dic_case_data = self._get_case_data()
        try:
            self._random = self._unicode(dic_case_data["random"])
        except KeyError:
            raise KeyError("\nThere is no key: random, in case data.")
        return self._random

    @property
    def has_random(self):
        """
        若测试数据中包含random字段，则返回True；否则，返回False。
        :return: 
        """
        if "random" in self._get_case_data().keys():
            return True
        else:
            return False

    @property
    def currentunit(self):
        """
        投注时的货币单位，例如元、角、分。
        :return: 
        """
        dic_case_data = self._get_case_data()
        try:
            str_currentunit = self._unicode(dic_case_data["currentunit"])
        except KeyError:
            raise KeyError("\nThere is no key: currentunit, in case data.")
        return str_currentunit

    @property
    def has_currentunit(self):
        """
        若测试数据中包含currentunit字段，则返回True；否则，返回False。
        :return: 
        """
        if "currentunit" in self._get_case_data().keys():
            return True
        else:
            return False

    # 玩家充值

    @property
    def dname(self):
        """
        充值时，需要填写充值人的名称。
        :return: 
        """
        dic_case_data = self._get_case_data()
        try:
            str_dname = self._unicode(dic_case_data["dname"])
        except KeyError:
            raise KeyError("\nThere is no key: dname, in case data.")
        return str_dname

    @property
    def from_bank(self):
        """
        充值时，需要填写充值人的银行卡的开户行
        :return: 
        """
        dic_case_data = self._get_case_data()
        try:
            str_from_bank = self._unicode(dic_case_data["frombank"])
        except KeyError:
            raise KeyError("\nThere is no key: frombank, in case data.")
        return str_from_bank

    @property
    def dmoney(self):
        """
        充值时，需要填写充值金额。
        :return: 
        """
        dic_case_data = self._get_case_data()
        try:
            str_dmoney = self._unicode(dic_case_data["dmoney"])
        except KeyError:
            raise KeyError("\nThere is no key: dmoney, in case data.")
        return str_dmoney

    @property
    def has_dmoney(self):
        """
        若测试数据中包含dmoney字段，则返回True；否则，返回False。
        :return: 
        """
        if "dmoney" in self._get_case_data().keys():
            return True
        else:
            return False

    @property
    def to_account(self):
        """
        充值时，需要填写收款账号。
        :return: 
        """
        dic_case_data = self._get_case_data()
        try:
            str_to_account = self._unicode(dic_case_data["toaccount"])
        except KeyError:
            raise KeyError("\nThere is no key: toaccount, in case data.")
        return str_to_account

    @property
    def dtype(self):
        """
        充值时，需要选择充值类型。
        :return: 
        """
        dic_case_data = self._get_case_data()
        try:
            str_dtype = self._unicode(dic_case_data["dtype"])
        except KeyError:
            raise KeyError("\nThere is no key: dtype, in case data.")
        return str_dtype

    @property
    def message1(self):
        """
        页面的提示信息，例如充值后的提示信息。
        :return: 
        """
        dic_case_data = self._get_case_data()
        try:
            str_message1 = self._unicode(dic_case_data["message1"])
        except KeyError:
            raise KeyError("\nThere is no key: message1, in case data.")
        return str_message1

    @property
    def reward(self):
        """
        充值时，赠送的金额。
        :return: 
        """
        dic_case_data = self._get_case_data()
        try:
            str_reward = self._unicode(dic_case_data["优惠金额"])
        except KeyError:
            raise KeyError("\nThere is no key: 优惠金额, in case data.")
        return str_reward

    @property
    def has_reward(self):
        """
        若测试数据中包含'优惠金额'字段，则返回True；否则，返回False。
        :return: 
        """
        if "优惠金额" in self._get_case_data().keys():
            return True
        else:
            return False

    @property
    def title(self):
        """
        通过网银转账时，会提供银行的网页链接，点击链接跳转到银行首页。title是银行网页的title。
        :return: 
        """
        dic_case_data = self._get_case_data()
        try:
            str_title = self._unicode(dic_case_data["title"])
        except KeyError:
            raise KeyError("\nThere is no key: title, in case data.")
        return str_title

    @property
    def has_title(self):
        """
        若测试数据中包含title字段，则返回True；否则，返回False。
        :return: 
        """
        if "title" in self._get_case_data().keys():
            return True
        else:
            return False

    @property
    def deposit_status(self):
        """
        充值时，订单的状态。
        :return: 
        """
        dic_case_data = self._get_case_data()
        try:
            str_deposit_status = self._unicode(dic_case_data["充值状态"])
        except KeyError:
            raise KeyError("\nThere is no key: 充值状态, in case data.")
        return str_deposit_status

    # 玩家提现

    @property
    def password_withdraw(self):
        """
        玩家的提现密码。
        :return: 
        """
        if self._password_withdraw is None:
            dic_case_data = self._get_case_data()
            try:
                str_withdraw_pwd = self._unicode(dic_case_data["取款密码"])
            except KeyError:
                raise KeyError("\nThere is no key: 取款密码, in case data.")
        else:
            str_withdraw_pwd = self._password_withdraw
        return str_withdraw_pwd

    @password_withdraw.setter
    def password_withdraw(self, str_pwd):
        """
        玩家的提现密码。
        :return: 
        """
        self._password_withdraw = str_pwd

    # 管理后台，人工线上存提

    @property
    def bet_amount(self):
        """
        充值时所需投注量或者提款时的扣除投注量。
        :return: 
        """
        dic_case_data = self._get_case_data()
        try:
            str_betamount = self._unicode(dic_case_data["betamount"])
        except KeyError:
            raise KeyError("\nThere is no key: betamount, in case data.")
        return str_betamount

    @property
    def remark(self):
        """
        人工线上存提的备注信息。
        :return: 
        """
        dic_case_data = self._get_case_data()
        try:
            str_remark = self._unicode(dic_case_data["remark"])
        except KeyError:
            raise KeyError("\nThere is no key: remark, in case data.")
        return str_remark

    @property
    def sysbalance(self):
        """
        人工线上存提页面的会员的系统余额。
        :return: 
        """
        dic_case_data = self._get_case_data()
        try:
            str_sysbalance = self._unicode(dic_case_data["sysbalance"])
        except KeyError:
            raise KeyError("\nThere is no key: sysbalance, in case data.")
        return str_sysbalance

    @property
    def current_amount(self):
        """
        人工线上存提页面的会员的投注量。
        :return: 
        """
        dic_case_data = self._get_case_data()
        try:
            str_currentamount = self._unicode(dic_case_data["currentamount"])
        except KeyError:
            raise KeyError("\nThere is no key: currentamount, in case data.")
        return str_currentamount

    @property
    def require_amount(self):
        """
        人工线上存提页面的会员的有效出款打码量。
        :return: 
        """
        dic_case_data = self._get_case_data()
        try:
            str_requireamount = self._unicode(dic_case_data["requireamount"])
        except KeyError:
            raise KeyError("\nThere is no key: requireamount, in case data.")
        return str_requireamount

    @property
    def wmoney(self):
        """
        人工线上存提-->人工提出页面的提出金额。
        :return: 
        """
        dic_case_data = self._get_case_data()
        try:
            str_wmoney = self._unicode(dic_case_data["wmoney"])
        except KeyError:
            raise KeyError("\nThere is no key: wmoney, in case data.")
        return str_wmoney

    @property
    def wtype(self):
        """
        人工线上存提-->人工提出页面的提出类型。
        :return: 
        """
        dic_case_data = self._get_case_data()
        try:
            str_wtype = self._unicode(dic_case_data["wtype"])
        except KeyError:
            raise KeyError("\nThere is no key: wtype, in case data.")
        return str_wtype

    @property
    def withdraw_status(self):
        """
        提款时，订单的状态。
        :return: 
        """
        dic_case_data = self._get_case_data()
        try:
            str_withdraw_status = self._unicode(dic_case_data["提款状态"])
        except KeyError:
            raise KeyError("\nThere is no key: 提款状态, in case data.")
        return str_withdraw_status

    @property
    def tmoney(self):
        """
        人工线上存提-->人工转点页面的转点金额。
        :return: 
        """
        dic_case_data = self._get_case_data()
        try:
            str_tmoney = self._unicode(dic_case_data["tmoney"])
        except KeyError:
            raise KeyError("\nThere is no key: tmoney, in case data.")
        return str_tmoney

    # 管理后台，出入款设定
    @property
    def min_reload(self):
        """
        出入款设定-->优惠标准，(入款时必须达到此额才会获取优惠)
        :return: 
        """
        dic_case_data = self._get_case_data()
        try:
            str_min_reload = self._unicode(dic_case_data["min_reload"])
        except KeyError:
            raise KeyError("\nThere is no key: min_reload, in case data.")
        return str_min_reload

    @property
    def bonus_pct(self):
        """
        出入款设定-->优惠百分比，(入款时获取优惠的百分比)
        :return: 
        """
        dic_case_data = self._get_case_data()
        try:
            str_bonus_pct = self._unicode(dic_case_data["bonus_pct"])
        except KeyError:
            raise KeyError("\nThere is no key: bonus_pct, in case data.")
        return str_bonus_pct

    @property
    def bonus_max(self):
        """
        出入款设定-->优惠上限金额，(获取优惠的最高额度)
        :return: 
        """
        dic_case_data = self._get_case_data()
        try:
            str_bonus_max = self._unicode(dic_case_data["bonus_max"])
        except KeyError:
            raise KeyError("\nThere is no key: bonus_max, in case data.")
        return str_bonus_max

    @property
    def damabeishu(self):
        """
        出入款设定-->打码倍数。
        :return: 
        """
        dic_case_data = self._get_case_data()
        try:
            str_damabeishu = self._unicode(dic_case_data["damabeishu"])
        except KeyError:
            raise KeyError("\nThere is no key: damabeishu, in case data.")
        return str_damabeishu

    @property
    def first_dbonus(self):
        """
        出入款设定-->是否开启首存优惠。
        :return: 
        """
        dic_case_data = self._get_case_data()
        try:
            str_first_dbonus = self._unicode(dic_case_data["first_dbonus"])
        except KeyError:
            raise KeyError("\nThere is no key: first_dbonus, in case data.")
        return str_first_dbonus

    @property
    def has_first_dbonus(self):
        """
        若测试数据中包含first_bonux字段，则返回True；否则，返回False。
        :return: 
        """
        if "first_dbonus" in self._get_case_data().keys():
            return True
        else:
            return False


class TestResult(object):
    """
    将测试结果存起来。
    """
    def __init__(self):
        # 玩法页面
        self.message_wrong_codes = None  # 输入不完整号码或者全角字符或者错误分隔符的弹窗信息
        self.message_invalid_money = None  # 输入无效投注金额时的弹窗信息
        self.message_remove_duplication = None  # 删除重复号码的弹窗信息
        self.message_clean_all = None  # 删除全部注单的弹窗信息
        self.message_auto_filer = None  # 自动过滤重复号码的弹窗信息
        self.message_wrong_term = None  # 追号时超大期数的弹窗信息
        self.message_confirm_bet = None  # 确认下注的弹窗信息
        self.message_bet_success = None  # 下注成功的弹窗信息
        self.message_bet_insufficient = None  # 下注时余额不足的弹窗信息
        self.bet_time = None  # 下注成功的时间
        self.total_money = None  # 追号总额

        # 充值记录页面
        self.deposit_status = None

        # 提款记录页面
        self.withdraw_status = None

        # 投注记录页面
        self.bet_item = None  # 符合投注时间的数据行数
        self.method = None  # 玩法
        self.each_money = None  # 单注金额
        self._bet_money = None  # 投注总额
        self.status = None  # 订单状态

        # 交易明细页面
        self.deal_item = None  # 符合投注时间的数据行数
        self.income_and_expense = None  # 收支情况
        self.deal_type = None  # 交易类型
        self._deal_money = None  # 交易金额

        # 在线存款页面
        self.message_deposit_no_name = None  # 充值时，不输入用户名的弹窗信息
        self.message_deposit_wrong_money = None  # 充值时，输入错误金额的弹窗信息
        self.order_number = None  # 银行入款的订单号
        self.title = None  # 银行首页的title
        self.message_deposit_info = None  # 银行入款成功时的提示信息

        # 在线取款页面
        self.message_withdraw_commit = None  # 提现申请提交的弹窗信息

        # 管理后台，入款管理页面
        self._dmoney = None  # 存款金额
        self.reward = None  # 存款优惠
        self.first_reward = None  # 首存优惠
        self.deposit_time = None  # 系统提交时间，对应玩家充值记录页面的充值时间
        self.deal_time = None  # 系统操作时间，对应玩家交易记录页面的交易时间
        self.message_deposit_lock = None  # 锁定存款订单时的提示信息
        self.message_deposit_confirm = None  # 确认存款订单时的提示信息

        # 管理后台，人工线上存提页面
        self.message_rgct_commit = None  # 提交充值信息后的弹窗
        self.message_rgct_confirm = None  # 确认充值信息后的弹窗
        self.message_rgct_no_search = None  # 未查询会员就提交充值信息的弹窗
        self.message_rgct_no_username = None  # 未输入会员名就查询的弹窗
        self.sysbalance = None  # 系统余额
        self.require_amount = None  # 有效出款打码量
        self.current_amount = None  # 目前投注量
        self.message_rgct_no_money = None  # 输入金额为空
        self.message_rgct_no_bet_amount = None  # 所需投注量为空
        self.message_rgct_wrong_money = None  # 提款金额格式错误信息
        self.message_rgct_wrong_bet_amount = None  # '去除投注量'格式错误信息
        self.message_rgct_insufficient_money = None  # 人工提出时，余额不足的信息
        self.message_rgct_insufficient_bet_amount = None  # 人工提出时，'所需投注量'小于'扣除投注量'

        # 管理后台，出款管理页面
        self.message_withdraw_lock = None  # 锁定时的弹窗信息
        self.message_withdraw_confirm = None  # 确认时的弹窗信息
        self.message_withdraw_cancel = None  # 点击‘取消’按钮时的弹窗信息

        # 管理后台，出入款设定
        self.message_funds_setting_commit = None  # 提交出入款设定的弹窗信息

    @property
    def bet_money(self):
        """
        返回投注记录页面的详情子页面的投注总额。
        :return: 
        """
        return self._bet_money

    @bet_money.setter
    def bet_money(self, str_bet_money):
        """
        设置投注记录页面的详情子页面的投注总额。
        :return: 
        """
        if type(str_bet_money) is str or type(str_bet_money) is unicode:
            self._bet_money = "".join(str_bet_money.split(","))
        elif type(str_bet_money) is float:
            self._bet_money = str_bet_money
        else:
            raise Exception("\nInvalid type of str_bet_money: %s."
                            " \nShould be str, unicode or float." % str(type(str_bet_money)))

    @property
    def deal_money(self):
        """
        返回交易明细页面的交易金额。
        :return: 
        """
        return self._deal_money

    @deal_money.setter
    def deal_money(self, str_deal_money):
        """
        设置交易明细页面的交易金额。
        :return: 
        """
        if type(str_deal_money) is str or type(str_deal_money) is unicode:
            if "," in str_deal_money:
                self._deal_money = "".join(str_deal_money.split(","))  # 若是"1,234.00"形式，则去掉逗号
            elif u"：" in str_deal_money:
                self._deal_money = str_deal_money.split(u"：")[1]  # 若是"总金额：50"形式，则取出数字
            else:
                self._deal_money = str_deal_money
        elif type(str_deal_money) is float:
            self._deal_money = str_deal_money
        else:
            raise Exception("\nInvalid type of str_deal_money: %s."
                            " \nShould be str, unicode or float." % str(type(str_deal_money)))

    @property
    def dmoney(self):
        """
        返回管理后台的入款管理页面的充值总额。
        :return: 
        """
        return self._dmoney

    @dmoney.setter
    def dmoney(self, str_dmoney):
        """
        设置管理后台的入款管理页面的充值总额。
        :return: 
        """
        if type(str_dmoney) is str or type(str_dmoney) is unicode:
            self._dmoney = "".join(str_dmoney.split(","))
        elif type(str_dmoney) is float:
            self._dmoney = str_dmoney
        else:
            raise Exception("\nInvalid type of str_deal_money: %s."
                            " \nShould be str, unicode or float." % str(type(str_dmoney)))

if __name__ == '__main__':
    DataBase().zero_bet_need('terry001')