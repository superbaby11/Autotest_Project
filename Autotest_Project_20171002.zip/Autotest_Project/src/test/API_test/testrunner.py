#!/usr/bin/env python
#coding:utf-8

#Created on 2017年4月24日
__author__ = 'Jason'


import time
import pytest
from src.utils.config import DefaultConfig
from src.utils.mail import Email


if __name__ == '__main__':
    now_time = time.strftime("%Y%m%d", time.localtime(time.time()))
    file_name = DefaultConfig().report_path+"interface_autotest_report_%s.html" % now_time
    test_dir = DefaultConfig().interface_test_dir
    args = ['--html=%s' % file_name, test_dir]
    pytest.main(args)
    # Email(title=u"接口自动化测试报告_%s" % file_name.split(".html")[0].split("interface_autotest_report_")[1], path=file_name).send()