#!/usr/bin/env python
# -*- coding:utf-8 -*-

#__author__ = 'Jason'

import time

import json
import ast
import pytest
from src.utils.getdb import db_mysql_connect, db_sqlserver_connect, sql_query_dict, sql_query, sql_update
from src.utils.interface.http_client import HTTPClient
from src.utils.assert_extra import assertDictContainsSubset


sql = "select preRequisite, interfaceID, caseData, remarks, expResult from interface_case where caseID='User_UpdateUserInfo_6';"

# 封装HTTP POST请求方法
@pytest.mark.parametrize("preRequisite, interfaceID,data,remarks,expResult",sql_query(db_mysql_connect(),sql))
# @pytest.fixture(params=bb)
def test_post(preRequisite,interfaceID, data, remarks, expResult):
    # 如果preRequisite中有需要执行的SQL语句，会先执行语句，初始化环境；
    if preRequisite:  # 判断preRequisite 是否为空
        print type(preRequisite),'pre-----type'
        if 'SQL' in preRequisite:
            try:
                preRequisite = ast.literal_eval(preRequisite)
                print type(preRequisite),'pre ---re'
                if 'SQL' in preRequisite and isinstance(preRequisite, dict):
                    for i in range(len(preRequisite["SQL"])):
                        sql_update(db_sqlserver_connect(), preRequisite["SQL"][i])
            except Exception :
                pass

    if 'SQL' in data:
        try:
            data = ast.literal_eval(data)
            if 'SQL' in data and isinstance(data, dict):
                data = sql_query_dict(db_sqlserver_connect(), data["SQL"])[0]
                data = json.dumps(data)  # 转化为string
                data = ast.literal_eval(data)  # 转化为dict
        except Exception:
            pass


    response = HTTPClient().send(interfaceID, data=data)
    # print 'response',response

    #断言
    assert {} != json.loads(response.decode('raw_unicode_escape'))
    expResult = ast.literal_eval(expResult)
    if 'SQL' in expResult:
        expResult_list = sql_query_dict(db_sqlserver_connect(), expResult['SQL'])
        if "Records" in json.loads(response.decode('raw_unicode_escape')):
            if "Disorder".decode("utf-8") == remarks:  # string 与 unicode 比较
                expResult_list.sort()
                # print 'exp-->',expResult_list
                response = json.loads(response.decode('raw_unicode_escape'))["Records"]
                response.sort()
                # print 'response-->',response

                for i in range(len(expResult_list)):

                    # print 'expResult-->', expResult_list[i]
                    # print 'response-->',response[i]
                    # print i

                    # print 'act_result:', json.loads(response.decode('raw_unicode_escape'))['Records'][i]
                    # assert set(expResult_list[i].items()).issubset(set(json.loads(response.decode('raw_unicode_escape'))['Records'][i].items()))
                    assertDictContainsSubset(expResult_list[i], response[i], 'haha1两者不匹配1：')
            else:
                for i in range(len(expResult_list)):
                    assertDictContainsSubset(expResult_list[i], json.loads(response.decode('raw_unicode_escape'))["Records"][i], '两者不匹配')
                # assert expResult_list[i].viewitems() <= json.loads(response.decode('raw_unicode_escape'))['Records'][i].viewitems()
        else:
            for i in range(len(expResult_list)):
                # assert set(expResult_list[i].items()).issubset(set(json.loads(response.decode('raw_unicode_escape')).items()))
                assertDictContainsSubset(expResult_list[i], json.loads(response.decode('raw_unicode_escape')),'haha2两者不匹配2：')
#                 assert expResult_list[i].viewitems() <= json.loads(response.decode('raw_unicode_escape')).viewitems()
    else:
        # 断言
#         TestCase().assertDictContainsSubset(expResult, json.loads(response.decode('raw_unicode_escape')))
        assertDictContainsSubset(expResult, json.loads(response.decode('raw_unicode_escape')), 'haha3两者不匹配3：')
#         assert expResult.viewitems() <= json.loads(response.decode('raw_unicode_escape')).viewitems()


if __name__ == '__main__':
    now_time = time.strftime("%Y%m%d", time.localtime(time.time()))
    args = ['-q', '-s', '--html=../../../../report/interface_autotest_report_%s.html' % now_time]
    pytest.main(args)